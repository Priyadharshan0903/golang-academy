# 11.7 Exercise: shrink a struct

Apply what you learned about alignment and padding: reorder a struct's fields to save 25% of its memory, checked by unsafe.Sizeof.

## The task



## Exercise: 11.7 Exercise: shrink a struct

`Event` is 64 bytes on a 64-bit platform. Reorder its fields so that `unsafe.Sizeof(Event{})` is 48 bytes. You may not add, remove, rename or change the type of any field; `TestFieldsUnchanged` checks that with reflection.

### Starter

```go
//go:build !solution

// Package layout practices struct field ordering.
package layout

// Event is kept in memory by the million, so every byte counts.
//
// TODO: reorder the fields so that unsafe.Sizeof(Event{}) is as small
// as possible. Do not add, remove, rename or change the type of any
// field. Hint: work out each field's size and alignment first.
type Event struct {
	Active   bool
	ID       int64
	Kind     uint8
	Score    float64
	Retries  int16
	Name     string
	Priority int32
	Deleted  bool
}
```

```sh
cd exercises
go test ./m11/layout/
```

### Reference solution — try the exercise first

```go
//go:build solution

// Package layout practices struct field ordering.
package layout

// Event is kept in memory by the million, so every byte counts.
//
// Fields are ordered by alignment, largest first: the 8-byte-aligned
// fields (string, int64, float64), then int32, int16 and the 1-byte
// fields. The data adds up to 41 bytes, and the struct's size must be
// a multiple of its alignment (8), so 48 bytes is the minimum.
type Event struct {
	Name     string  // 16 bytes, offset 0
	ID       int64   // 8 bytes, offset 16
	Score    float64 // 8 bytes, offset 24
	Priority int32   // 4 bytes, offset 32
	Retries  int16   // 2 bytes, offset 36
	Active   bool    // 1 byte, offset 38
	Kind     uint8   // 1 byte, offset 39
	Deleted  bool    // 1 byte, offset 40, then 7 bytes of padding
}
```

```sh
go test -tags solution ./m11/layout/
```



```bash
cd exercises
go test ./m11/layout     # TestSize fails: 64 bytes
```

## Work it out on paper first

Before moving any field, write down each field's size and alignment (the table in lesson 11.4), then answer:

1. How many bytes of data does `Event` hold, ignoring padding?
2. What is the struct's alignment? (The largest alignment of any field.)
3. The size must be a multiple of the alignment. What is the smallest possible size?



### Check your answers

1. 16 (string) + 8 + 8 + 4 + 2 + 1 + 1 + 1 = 41 bytes.
2. 8 bytes.
3. 41 rounded up to a multiple of 8 is **48**. So 48 is not just a target; it is the minimum.





### Hint: where do the 64 bytes come from?

Use `unsafe.Offsetof` on each field of the starter, or reason it through: `Active` (1 byte) is followed by 7 bytes of padding so `ID` starts at offset 8; `Kind` by 7 more before `Score`; `Retries` by 6 before `Name`. That is 20 bytes of padding inside, plus 3 at the end.



The reference solution, with offsets in comments, is in `exercises/m11/layout/solution.go`.

## Going further

- Run the `fieldalignment` analyzer from lesson 11.4 on the starter and compare its suggestion with yours.
- Write a benchmark that allocates a `[]Event` of one million elements with each layout, and compare `B/op`.

## Part 3, second half: recap

You now know what happens underneath your code: how goroutines are scheduled onto threads and why `GOMAXPROCS` matters in containers, how stacks grow and move, how the garbage collector works and how `GOGC` and `GOMEMLIMIT` steer it, how values are laid out in memory, what interface and generic calls cost, and how slices and maps grow and hold on to memory.

Next is **Part 4: Production Go**, starting with **[Module 12: Building HTTP services](../12-http-services/README.md)**, where all of this comes together in real services.
