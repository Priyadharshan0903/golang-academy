# 11. Runtime internals

Module 10 taught you to measure. This module explains **why** the measurements come out the way they do. You do not need any of this to write correct Go, but it is what lets you predict performance, read profiles with understanding, and configure services well, especially in containers.

Every claim in this module is backed by a small experiment in `examples/m11`. Run them: several give different answers on different Go versions, and those differences are part of the lesson.

**Time:** about 3 to 4 hours, plus the exercise.

- [11.1 How the scheduler works: G, M and P](01-scheduler.md)
- [11.2 Stacks and goroutine growth](02-stacks.md)
- [11.3 The garbage collector, GOGC and GOMEMLIMIT](03-gc.md)
- [11.4 Memory layout, alignment and unsafe](04-memory-layout.md)
- [11.5 Interfaces and method dispatch under the hood](05-interfaces.md)
- [11.6 Slices and maps under the hood](06-slices-and-maps.md)
- [11.7 Exercise: shrink a struct](07-exercise.md)
