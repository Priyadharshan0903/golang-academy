# 5.7 Project milestone: URL shortener core

Milestone 1 of the URL shortener: a domain package with sentinel errors, validation, a Store interface, an in-memory store and a fully tested Service.

## The project

Over the rest of the course you will build a URL shortener in milestones, each one using the module you just finished:

| Milestone | After module | Adds |
|---|---|---|
| **1. Core** (this lesson) | 5. Errors | Domain types, errors, validation, `Service`, in-memory store |
| 2. HTTP API | 12. HTTP services | JSON API, redirects, middleware |
| 3. Postgres | 13. Working with data | A database-backed `Store`, migrations |
| 4. Deploy | 15. Cloud native | Container image and Kubernetes manifests |

The code lives in [`projects/shortener`](https://github.com/Priyadharshan0903/gopath-academy/tree/main/projects/shortener).

## The design

The core is a package called `link` with **no** knowledge of HTTP or databases:

- A `Link` struct.
- **Sentinel errors** callers can check: `ErrNotFound`, `ErrCodeTaken`, `ErrInvalidURL`, `ErrInvalidCode`.
- A small `Store` interface (two methods in this milestone; milestone 4 adds a third, `Delete`), defined in the package that uses it (lesson 4.8).
- A `Service` holding the rules: validate input, generate codes, retry on collisions.



Source: `projects/shortener/internal/link/link.go`

```go
// Package link is the core of the URL shortener: the Link type, the
// errors callers can check for, and the Service that creates and
// resolves short links on top of any Store.
//
// It has no knowledge of HTTP or databases. Those live in other
// packages and are added in later milestones of the project.
package link

import (
	"context"
	"crypto/rand"
	"errors"
	"fmt"
	"net/url"
	"time"
)

// Errors that callers can check with errors.Is. The HTTP layer
// (Module 12) maps each of them to a status code.
var (
	ErrNotFound    = errors.New("link not found")
	ErrCodeTaken   = errors.New("code already in use")
	ErrInvalidURL  = errors.New("invalid url")
	ErrInvalidCode = errors.New("invalid code")
)

// Link is a short code pointing at a target URL.
type Link struct {
	Code      string
	URL       string
	CreatedAt time.Time
}

// Store persists links. Implementations must return an error wrapping
// ErrCodeTaken from Create when the code exists, and ErrNotFound from
// Get when it does not.
//
// The context parameter carries cancellation and deadlines; it is
// covered in Module 7. Until then, context.Background() is fine.
type Store interface {
	Create(ctx context.Context, l Link) error
	Get(ctx context.Context, code string) (Link, error)
	// Delete was added in milestone 4, for the Kubernetes operator.
	// It returns an error wrapping ErrNotFound if the code does not exist.
	Delete(ctx context.Context, code string) error
}

// Service implements the shortener's rules on top of a Store.
type Service struct {
	store Store
	now   func() time.Time
	rand  func(n int) string
}

// NewService returns a Service backed by store.
func NewService(store Store) *Service {
	return &Service{store: store, now: time.Now, rand: randomCode}
}

const (
	generatedLength = 7
	maxAttempts     = 5
)

// Shorten creates a link for rawURL. If code is empty, a random code
// is generated; otherwise the requested custom code is used.
func (s *Service) Shorten(ctx context.Context, rawURL, code string) (Link, error) {
	if err := validateURL(rawURL); err != nil {
		return Link{}, err
	}
	if code != "" {
		if err := validateCode(code); err != nil {
			return Link{}, err
		}
		return s.create(ctx, code, rawURL)
	}

	// Random codes can collide. Collisions are rare, so retry a few
	// times and only then give up.
	var err error
	for range maxAttempts {
		var l Link
		l, err = s.create(ctx, s.rand(generatedLength), rawURL)
		if !errors.Is(err, ErrCodeTaken) {
			return l, err
		}
	}
	return Link{}, fmt.Errorf("generate code after %d attempts: %w", maxAttempts, err)
}

func (s *Service) create(ctx context.Context, code, rawURL string) (Link, error) {
	l := Link{Code: code, URL: rawURL, CreatedAt: s.now().UTC()}
	if err := s.store.Create(ctx, l); err != nil {
		return Link{}, fmt.Errorf("create %q: %w", code, err)
	}
	return l, nil
}

// Resolve returns the link for code.
func (s *Service) Resolve(ctx context.Context, code string) (Link, error) {
	if err := validateCode(code); err != nil {
		return Link{}, err
	}
	l, err := s.store.Get(ctx, code)
	if err != nil {
		return Link{}, fmt.Errorf("resolve %q: %w", code, err)
	}
	return l, nil
}

// Delete removes the link for code.
func (s *Service) Delete(ctx context.Context, code string) error {
	if err := validateCode(code); err != nil {
		return err
	}
	if err := s.store.Delete(ctx, code); err != nil {
		return fmt.Errorf("delete %q: %w", code, err)
	}
	return nil
}

func validateURL(raw string) error {
	u, err := url.Parse(raw)
	if err != nil {
		return fmt.Errorf("%w: %v", ErrInvalidURL, err)
	}
	if u.Scheme != "http" && u.Scheme != "https" {
		return fmt.Errorf("%w: scheme must be http or https, got %q", ErrInvalidURL, u.Scheme)
	}
	if u.Host == "" {
		return fmt.Errorf("%w: missing host", ErrInvalidURL)
	}
	return nil
}

func validateCode(code string) error {
	if len(code) < 3 || len(code) > 32 {
		return fmt.Errorf("%w: length must be 3 to 32, got %d", ErrInvalidCode, len(code))
	}
	for _, r := range code {
		ok := r >= 'a' && r <= 'z' || r >= 'A' && r <= 'Z' || r >= '0' && r <= '9' || r == '-' || r == '_'
		if !ok {
			return fmt.Errorf("%w: unexpected character %q", ErrInvalidCode, r)
		}
	}
	return nil
}

const alphabet = "abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789"

// randomCode returns n characters from an alphabet without look-alike
// characters (no 0/O, 1/l/I), using a cryptographically secure source
// so codes cannot be guessed from earlier ones.
func randomCode(n int) string {
	// Bytes at or above limit are discarded. Without this, the first
	// 256 % len(alphabet) characters would be slightly more likely
	// than the others ("modulo bias").
	const limit = 256 - 256%len(alphabet)
	out := make([]byte, 0, n)
	buf := make([]byte, n*2)
	for len(out) < n {
		rand.Read(buf) // since Go 1.24, Read never returns an error; it crashes the program instead
		for _, b := range buf {
			if int(b) < limit && len(out) < n {
				out = append(out, alphabet[int(b)%len(alphabet)])
			}
		}
	}
	return string(out)
}
```



### Things to notice

- **Wrapping with context, keeping causes inspectable.** Errors look like `create "my-link": code already in use`, and `errors.Is(err, ErrCodeTaken)` still works through the wrapper.
- **Validation errors carry detail.** `ErrInvalidURL` is wrapped with `%w` alongside the specific reason, so the HTTP layer can return a helpful message and a 400 status.
- **Retry only the retryable error.** A random code collision (`ErrCodeTaken`) is retried; any other store error is returned immediately. After five collisions, the final error says so and still wraps `ErrCodeTaken`.
- **Dependencies are fields.** `now` and `rand` are function fields, set to real implementations by `NewService`. Tests replace them to get fixed timestamps and to force collisions, without any mocking library.
- **Unbiased random codes.** `randomCode` uses `crypto/rand` (unguessable) and rejects bytes that would cause modulo bias. The alphabet leaves out characters that look alike.
- **The context parameter** is part of the `Store` interface from the start, because the database store in milestone 3 will need it. Module 7 explains it.

## The in-memory store



Source: `projects/shortener/internal/link/memstore.go`

```go
package link

import (
	"context"
	"sync"
)

// MemoryStore is an in-memory Store, safe for concurrent use.
// It is used in tests and for local development.
type MemoryStore struct {
	mu    sync.RWMutex // locking is covered in Module 6
	links map[string]Link
}

// NewMemoryStore returns an empty MemoryStore.
func NewMemoryStore() *MemoryStore {
	return &MemoryStore{links: make(map[string]Link)}
}

// Create stores l, or returns ErrCodeTaken if its code exists.
func (m *MemoryStore) Create(_ context.Context, l Link) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	if _, exists := m.links[l.Code]; exists {
		return ErrCodeTaken
	}
	m.links[l.Code] = l
	return nil
}

// Get returns the link for code, or ErrNotFound.
func (m *MemoryStore) Get(_ context.Context, code string) (Link, error) {
	m.mu.RLock()
	defer m.mu.RUnlock()
	l, ok := m.links[code]
	if !ok {
		return Link{}, ErrNotFound
	}
	return l, nil
}

// Compile-time check that MemoryStore satisfies Store.
var _ Store = (*MemoryStore)(nil)

// Delete removes the link for code, or returns ErrNotFound.
func (m *MemoryStore) Delete(_ context.Context, code string) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	if _, ok := m.links[code]; !ok {
		return ErrNotFound
	}
	delete(m.links, code)
	return nil
}
```



The `sync.RWMutex` makes the store safe for concurrent use, which matters once the HTTP server handles requests in parallel. Module 6 explains mutexes; for now, note that every method locks before touching the map.

## The tests



Source: `projects/shortener/internal/link/link_test.go`

```go
package link

import (
	"context"
	"errors"
	"strings"
	"testing"
	"time"
)

func newTestService() *Service {
	s := NewService(NewMemoryStore())
	s.now = func() time.Time { return time.Date(2026, 10, 16, 9, 0, 0, 0, time.UTC) }
	return s
}

func TestShortenAndResolve(t *testing.T) {
	ctx := context.Background()
	s := newTestService()

	l, err := s.Shorten(ctx, "https://go.dev/doc/", "")
	if err != nil {
		t.Fatal(err)
	}
	if len(l.Code) != generatedLength {
		t.Errorf("generated code %q has length %d", l.Code, len(l.Code))
	}
	if !l.CreatedAt.Equal(s.now()) {
		t.Errorf("CreatedAt = %v", l.CreatedAt)
	}

	got, err := s.Resolve(ctx, l.Code)
	if err != nil || got.URL != "https://go.dev/doc/" {
		t.Errorf("Resolve = %+v, %v", got, err)
	}
}

func TestCustomCode(t *testing.T) {
	ctx := context.Background()
	s := newTestService()

	if _, err := s.Shorten(ctx, "https://example.com", "my-link"); err != nil {
		t.Fatal(err)
	}
	_, err := s.Shorten(ctx, "https://other.example", "my-link")
	if !errors.Is(err, ErrCodeTaken) {
		t.Errorf("second Shorten with same code: %v, want ErrCodeTaken", err)
	}
	if !strings.Contains(err.Error(), "my-link") {
		t.Errorf("error should mention the code: %v", err)
	}
}

func TestValidation(t *testing.T) {
	ctx := context.Background()
	s := newTestService()

	badURLs := []string{"", "ftp://example.com", "example.com", "https://", "http://bad host"}
	for _, u := range badURLs {
		if _, err := s.Shorten(ctx, u, ""); !errors.Is(err, ErrInvalidURL) {
			t.Errorf("Shorten(%q) error = %v, want ErrInvalidURL", u, err)
		}
	}
	badCodes := []string{"ab", strings.Repeat("x", 33), "has space", "emoji🙂"}
	for _, c := range badCodes {
		if _, err := s.Shorten(ctx, "https://example.com", c); !errors.Is(err, ErrInvalidCode) {
			t.Errorf("Shorten(code %q) error = %v, want ErrInvalidCode", c, err)
		}
	}
}

func TestResolveMissing(t *testing.T) {
	_, err := newTestService().Resolve(context.Background(), "nope123")
	if !errors.Is(err, ErrNotFound) {
		t.Errorf("Resolve missing = %v, want ErrNotFound", err)
	}
}

func TestRetriesOnCollision(t *testing.T) {
	ctx := context.Background()
	s := newTestService()
	codes := []string{"taken01", "taken01", "fresh01"}
	s.rand = func(int) string {
		c := codes[0]
		codes = codes[1:]
		return c
	}
	if _, err := s.Shorten(ctx, "https://a.example", ""); err != nil {
		t.Fatal(err)
	}
	l, err := s.Shorten(ctx, "https://b.example", "")
	if err != nil || l.Code != "fresh01" {
		t.Errorf("after a collision got %+v, %v; want code fresh01", l, err)
	}
}

func TestGivesUpAfterTooManyCollisions(t *testing.T) {
	ctx := context.Background()
	s := newTestService()
	s.rand = func(int) string { return "always1" }
	s.Shorten(ctx, "https://a.example", "")

	_, err := s.Shorten(ctx, "https://b.example", "")
	if !errors.Is(err, ErrCodeTaken) || !strings.Contains(err.Error(), "attempts") {
		t.Errorf("got %v, want an error mentioning attempts and wrapping ErrCodeTaken", err)
	}
}

func TestRandomCodeAlphabet(t *testing.T) {
	for range 100 {
		c := randomCode(16)
		if strings.ContainsAny(c, "0O1lI") || len(c) != 16 {
			t.Fatalf("bad code %q", c)
		}
	}
}
```



Every error path is tested with `errors.Is`, including the collision retry logic, which would be very hard to trigger with real randomness.

```bash
go test -race ./projects/shortener/...
```

## Stretch goals

1. Add an `ErrReservedCode` for codes like `api`, `admin` and `health`, which the HTTP layer will need for its own routes. Return it from `validateCode`.
2. Add an optional expiry time to `Link`, and make `Resolve` return a new `ErrExpired` for expired links.
3. Write a `CountingStore` decorator (like the `kv` exercise in lesson 4.2) that counts resolves per code.

## Module 5 recap

You can now:

- Create, return and handle errors idiomatically
- Wrap errors with context and inspect them with `errors.Is`, `errors.As` and `errors.AsType`
- Choose between sentinels, error types and behavior checks
- Report several errors at once with `errors.Join`
- Use `panic` and `recover` only where they belong
- Structure error handling across the layers of a real service

That completes **Part 1: Fundamentals**. Next is **[Module 6: Concurrency fundamentals](../06-concurrency-fundamentals/README.md)**.
