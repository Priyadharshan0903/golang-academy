# 5. Errors

Go has no exceptions. Functions return errors as ordinary values, and callers decide what to do with them. This module shows how to do that **well**: errors that carry useful context, that callers can inspect reliably, and that are handled in the right place.

**Time:** about 2 to 3 hours, plus exercises and the project milestone.

- [5.1 Errors are values](01-errors-are-values.md)
- [5.2 Wrapping with %w, errors.Is and errors.As](02-wrapping.md)
- [5.3 Sentinel errors vs custom error types](03-sentinels-and-types.md)
- [5.4 errors.Join and multi-errors](04-joining-errors.md)
- [5.5 panic and recover: when, and mostly when not](05-panic-and-recover.md)
- [5.6 Error handling patterns in real codebases](06-patterns.md)
- [5.7 Project milestone: URL shortener core](07-checkpoint-project.md)
