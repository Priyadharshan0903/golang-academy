# 5.4 errors.Join and multi-errors

Return several errors at once with errors.Join and multiple %w verbs, and inspect them with errors.Is, errors.As and Unwrap() []error.

## What you will learn

- When reporting several errors at once is better than stopping at the first
- How `errors.Join` combines errors, and how it formats them
- How to wrap several errors with multiple `%w` verbs
- How `errors.Is` and `errors.As` search joined errors
- How to iterate over the individual errors

## The idea

Most functions stop at the first error. Some should not:

- **Validation**: tell the user about every invalid field in one response, not one per submission.
- **Cleanup**: when closing five resources, try all five and report every failure.
- **Fan-out work**: several independent operations ran; some failed.

Since Go 1.20 the standard library supports errors that wrap **more than one** error.

## `errors.Join`



Source: `examples/m05/join/join_test.go`

```go
var (
	ErrNameRequired = errors.New("name is required")
	ErrBadEmail     = errors.New("email is invalid")
)

type Signup struct{ Name, Email string }

// Validate reports every problem at once instead of stopping at the first.
func (s Signup) Validate() error {
	var errs []error
	if s.Name == "" {
		errs = append(errs, ErrNameRequired)
	}
	if !strings.Contains(s.Email, "@") {
		errs = append(errs, fmt.Errorf("%w: %q", ErrBadEmail, s.Email))
	}
	return errors.Join(errs...) // nil if errs is empty
}

func Example_join() {
	err := Signup{Email: "nope"}.Validate()
	fmt.Println(err) // one error per line
	fmt.Println(errors.Is(err, ErrNameRequired), errors.Is(err, ErrBadEmail))

	fmt.Println(Signup{Name: "Ana", Email: "a@b.c"}.Validate() == nil)

	// Output:
	// name is required
	// email is invalid: "nope"
	// true true
	// true
}
```

Local command:

```sh
go test -run Example_join -v ./examples/m05/join
```



- `errors.Join(errs...)` returns an error wrapping all non-nil arguments.
- It returns **`nil`** if every argument is `nil` (or there are none), so you can always `return errors.Join(errs...)`.
- Its message is the messages of the joined errors, separated by newlines.
- `errors.Is` and `errors.As` find any of the joined errors.

## Multiple `%w` verbs

`fmt.Errorf` can wrap several errors at once:



Source: `examples/m05/join/join_test.go`

```go
func Example_multipleW() {
	errA := errors.New("cache miss")
	errB := errors.New("db timeout")

	// fmt.Errorf accepts several %w verbs (Go 1.20+).
	err := fmt.Errorf("load user: %w, then %w", errA, errB)
	fmt.Println(err)
	fmt.Println(errors.Is(err, errA), errors.Is(err, errB))

	// errors.Unwrap only follows single-error wrappers, so it returns nil here.
	fmt.Println(errors.Unwrap(err) == nil)

	// Output:
	// load user: cache miss, then db timeout
	// true true
	// true
}
```

Local command:

```sh
go test -run Example_multipleW -v ./examples/m05/join
```



Use this when you want a custom one-line message rather than the newline-separated format of `Join`.

## Getting the individual errors

An error that wraps several errors implements `Unwrap() []error` (plural). `errors.Unwrap` only understands the single-error form, which is why it returned `nil` above. To list the errors, assert to the interface:

```go
if multi, ok := err.(interface{ Unwrap() []error }); ok {
	for _, e := range multi.Unwrap() {
		fmt.Println("-", e)
	}
}
```

You will do exactly this in the exercise to collect the names of failed form fields.

## Joining errors from cleanup

A pattern for functions that must release several resources:

```go
func (s *Server) Close() error {
	return errors.Join(
		s.listener.Close(),
		s.db.Close(),
		s.cache.Close(),
	)
}
```

Every `Close` runs (Go evaluates all arguments), nil results are dropped, and the caller learns about every failure.

## Common mistakes

### Returning a slice of errors

`func Validate() []error` forces every caller to check `len(errs) > 0` and does not compose with `error`-returning code. Return `errors.Join(errs...)`.

### Expecting one-line messages from `Join`

The newline-separated output can look odd in a single-line log. Format it yourself with multiple `%w`, or log the joined error as a structured field.

### Calling `errors.Unwrap` on a joined error

It returns `nil`. Use `errors.Is`, `errors.As`, or the `Unwrap() []error` interface.

## Exercise



## Exercise: 5.4 errors.Join and multi-errors

Implement `FieldError`, a `Validate` function that reports every problem in a signup form with `errors.Join`, and a `Fields` helper that lists the failed fields by unwrapping the joined error. The tests check both the exact message and that `errors.Is` finds every sentinel.

### Starter

```go
//go:build !solution

// Package form validates user input and reports every problem at once
// with errors.Join, instead of stopping at the first one.
package form

import "errors"

// Sentinel errors for each kind of problem.
var (
	ErrRequired = errors.New("is required")
	ErrTooShort = errors.New("is too short")
	ErrInvalid  = errors.New("is invalid")
)

// FieldError reports a problem with one field.
type FieldError struct {
	Field string
	Err   error // one of the sentinel errors above
}

// Error formats the error as "<field> <reason>", for example
// "password is too short".
func (e *FieldError) Error() string {
	// TODO: implement me.
	return ""
}

// Unwrap returns the sentinel error.
func (e *FieldError) Unwrap() error {
	// TODO: implement me.
	return nil
}

// Signup is the input of a signup form.
type Signup struct {
	Username string
	Email    string
	Password string
}

// Validate checks every field and returns nil when the form is valid.
// Otherwise it returns errors.Join of one *FieldError per problem, in
// this order:
//
//   - username: ErrRequired if empty
//   - email:    ErrRequired if empty, otherwise ErrInvalid if it has no "@"
//   - password: ErrRequired if empty, otherwise ErrTooShort if shorter than 8 bytes
func Validate(s Signup) error {
	// TODO: implement me.
	return nil
}

// Fields returns the names of the fields that failed, in order, or
// nil when err is nil. Use errors.As on each joined error.
//
// Hint: an error made by errors.Join has a method
// Unwrap() []error. Assert to an interface with that method.
func Fields(err error) []string {
	// TODO: implement me.
	return nil
}
```

```sh
cd exercises
go test ./m05/form/
```

### Reference solution — try the exercise first

```go
//go:build solution

// Package form validates user input and reports every problem at once
// with errors.Join, instead of stopping at the first one.
package form

import (
	"errors"
	"strings"
)

// Sentinel errors for each kind of problem.
var (
	ErrRequired = errors.New("is required")
	ErrTooShort = errors.New("is too short")
	ErrInvalid  = errors.New("is invalid")
)

// FieldError reports a problem with one field.
type FieldError struct {
	Field string
	Err   error
}

// Error formats the error as "<field> <reason>".
func (e *FieldError) Error() string { return e.Field + " " + e.Err.Error() }

// Unwrap returns the sentinel error.
func (e *FieldError) Unwrap() error { return e.Err }

// Signup is the input of a signup form.
type Signup struct {
	Username string
	Email    string
	Password string
}

// Validate checks every field and joins all problems.
func Validate(s Signup) error {
	var errs []error
	add := func(field string, err error) {
		errs = append(errs, &FieldError{Field: field, Err: err})
	}

	if s.Username == "" {
		add("username", ErrRequired)
	}
	switch {
	case s.Email == "":
		add("email", ErrRequired)
	case !strings.Contains(s.Email, "@"):
		add("email", ErrInvalid)
	}
	switch {
	case s.Password == "":
		add("password", ErrRequired)
	case len(s.Password) < 8:
		add("password", ErrTooShort)
	}
	return errors.Join(errs...)
}

// Fields returns the names of the fields that failed, in order.
func Fields(err error) []string {
	if err == nil {
		return nil
	}
	var list []error
	if joined, ok := err.(interface{ Unwrap() []error }); ok {
		list = joined.Unwrap()
	} else {
		list = []error{err}
	}
	var names []string
	for _, e := range list {
		var fe *FieldError
		if errors.As(e, &fe) {
			names = append(names, fe.Field)
		}
	}
	return names
}
```

```sh
go test -tags solution ./m05/form/
```



## Key takeaways

- Report several errors at once for validation, cleanup and fan-out work.
- `errors.Join` returns nil for no errors, joins messages with newlines, and works with `errors.Is` and `errors.As`.
- `fmt.Errorf` accepts several `%w` verbs.
- Errors wrapping several errors implement `Unwrap() []error`, which `errors.Unwrap` does not follow.

## Further reading

- [Go 1.20 release notes: wrapping multiple errors](https://go.dev/doc/go1.20#errors)
- [Package errors: Join](https://pkg.go.dev/errors#Join)
