# 5.2 Wrapping with %w, errors.Is and errors.As

Add context to errors without losing the original, inspect wrapped errors with errors.Is, errors.As and errors.AsType, and make your own types unwrappable.

## What you will learn

- How `%w` wraps an error and builds an error chain
- The difference between `%w` and `%v` in `fmt.Errorf`
- How `errors.Is` and `errors.As` search the chain
- The generic `errors.AsType` (Go 1.26+)
- How to make your own error types participate with `Unwrap`

## The idea

Each layer of a program should add context to an error ("load profile", "find user 42") so the final message explains what happened. But callers also need to recognize the **original** cause ("not found") to decide what to do.

Wrapping gives you both. `fmt.Errorf("context: %w", err)` produces a new error whose message includes the context **and** which remembers `err` underneath. The result is a chain you can search.

## Wrapping and `errors.Is`



Source: `examples/m05/wrapping/wrapping_test.go`

```go
var ErrNotFound = errors.New("not found")

func findUser(id int) error {
	return fmt.Errorf("find user %d: %w", id, ErrNotFound)
}

func loadProfile(id int) error {
	if err := findUser(id); err != nil {
		return fmt.Errorf("load profile: %w", err)
	}
	return nil
}

func Example_wrapping() {
	err := loadProfile(42)
	fmt.Println(err)

	fmt.Println(err == ErrNotFound)          // false: err is a wrapper
	fmt.Println(errors.Is(err, ErrNotFound)) // true: Is walks the chain

	fmt.Println(errors.Unwrap(err)) // one layer down

	// Output:
	// load profile: find user 42: not found
	// false
	// true
	// find user 42: not found
}
```

Local command:

```sh
go test -run Example_wrapping -v ./examples/m05/wrapping
```



After two layers of wrapping, `err == ErrNotFound` is false: `err` is a wrapper, not the sentinel itself. `errors.Is(err, ErrNotFound)` walks down the chain, comparing each error, and finds it.

**Always use `errors.Is` instead of `==` for errors**, even if you think nothing wraps them today. Someone will add context later.

## `%w` vs `%v`



Source: `examples/m05/wrapping/wrapping_test.go`

```go
func Example_wrapVsFormat() {
	base := errors.New("disk full")

	wrapped := fmt.Errorf("save: %w", base)   // keeps the chain
	flattened := fmt.Errorf("save: %v", base) // only copies the text

	fmt.Println(wrapped, "|", errors.Is(wrapped, base))
	fmt.Println(flattened, "|", errors.Is(flattened, base))

	// Output:
	// save: disk full | true
	// save: disk full | false
}
```

Local command:

```sh
go test -run Example_wrapVsFormat -v ./examples/m05/wrapping
```



The messages are identical, but only `%w` keeps the original error inspectable. When to use which:

- **`%w`** when callers may reasonably want to check the cause. This is the common case.
- **`%v`** when you deliberately want to **hide** the underlying error, so it does not become part of your API. For example, a storage package might not want callers to depend on the specific database driver errors it happens to use today.

## `errors.As`: finding a type in the chain



Source: `examples/m05/wrapping/wrapping_test.go`

```go
func Example_errorsAs() {
	_, err := os.Open("/definitely/not/here.txt")
	err = fmt.Errorf("read config: %w", err)

	var pathErr *fs.PathError
	if errors.As(err, &pathErr) {
		fmt.Println("op:", pathErr.Op)
		fmt.Println("path:", pathErr.Path)
	}
	fmt.Println(errors.Is(err, fs.ErrNotExist))

	// Output:
	// op: open
	// path: /definitely/not/here.txt
	// true
}
```

Local command:

```sh
go test -run Example_errorsAs -v ./examples/m05/wrapping
```



`errors.As(err, &target)` looks for the first error in the chain that can be assigned to `target`'s type, and if found, stores it in `target` and returns true. You pass a **pointer to a variable** of the type you are looking for, here a `*fs.PathError`, so the argument is a `**fs.PathError`. `go vet` checks that you get this right.

Notice also that `errors.Is(err, fs.ErrNotExist)` works on the wrapped `os.Open` error. The standard library's file errors are designed to be checked this way, on every operating system.

### `errors.AsType` (Go 1.26+)

Go 1.26 added a generic version that needs no target variable:



Source: `examples/m05/wrapping/astype_test.go`

```go
func Example_asType() {
	_, err := os.Open("/definitely/not/here.txt")
	err = fmt.Errorf("read config: %w", err)

	// errors.AsType (Go 1.26+) is a generic, type-safe form of errors.As:
	// no target variable, no pointer-to-pointer.
	if pathErr, ok := errors.AsType[*fs.PathError](err); ok {
		fmt.Println("path:", pathErr.Path)
	}

	// Output:
	// path: /definitely/not/here.txt
}
```

Local command:

```sh
go test -run Example_asType -v ./examples/m05/wrapping
```



It is type safe at compile time (you cannot pass the wrong kind of pointer) and faster than `errors.As`. Prefer it in modules whose `go` line is 1.26 or later.

## Your own wrapping types

A custom error type can wrap another error by implementing `Unwrap() error`:



Source: `examples/m05/wrapping/wrapping_test.go`

```go
// QueryError wraps a lower-level error and adds the query.
type QueryError struct {
	Query string
	Err   error
}

func (e *QueryError) Error() string { return e.Query + ": " + e.Err.Error() }

// Unwrap lets errors.Is and errors.As see the wrapped error.
func (e *QueryError) Unwrap() error { return e.Err }

var ErrTimeout = errors.New("timeout")

func Example_customWrapper() {
	err := fmt.Errorf("list users: %w", &QueryError{Query: "SELECT * FROM users", Err: ErrTimeout})

	fmt.Println(err)
	fmt.Println(errors.Is(err, ErrTimeout))

	var qe *QueryError
	fmt.Println(errors.As(err, &qe), qe.Query)

	// Output:
	// list users: SELECT * FROM users: timeout
	// true
	// true SELECT * FROM users
}
```

Local command:

```sh
go test -run Example_customWrapper -v ./examples/m05/wrapping
```



With `Unwrap`, both `errors.Is(err, ErrTimeout)` and `errors.As(err, &qe)` see through the type. Without it, the chain stops at `QueryError`.

`errors.Unwrap(err)` returns one level down, or `nil` if `err` does not wrap anything. You rarely call it directly; `Is` and `As` do the walking.

## How the chain is searched

For each error in the chain, starting with `err` itself:

- `errors.Is` reports true if the error `==` target, **or** the error has a method `Is(error) bool` that returns true for target.
- `errors.As` succeeds if the error is assignable to the target type, **or** has a method `As(any) bool` that returns true.
- Then it moves on to `Unwrap()`. If an error has `Unwrap() []error` (lesson 5.4), the search goes depth-first through each wrapped error.

Custom `Is` methods let one error match a category; lesson 5.3 shows an example.

## Common mistakes

### Wrapping with `%v` and then calling `errors.Is`

`%v` flattens to a string. If callers must check the cause, use `%w`.

### Passing a non-pointer to `errors.As`

`errors.As(err, pathErr)` instead of `errors.As(err, &pathErr)` panics. `go vet` catches it.

### Wrapping the same context at every layer

`read config: read config: open config.yaml: ...` happens when both caller and callee add the same words. Each layer should add only what **it** knows: the function name, the ID it was working on.

### Wrapping errors from your dependencies into your public API without thinking

Everything you wrap with `%w` becomes something callers might check. Be intentional about it, especially in libraries.

## Exercise



## Exercise: 5.2 Wrapping with %w, errors.Is and errors.As

Build a small config parser. `ParseLine` returns errors wrapping `ErrSyntax`. `Load` returns a `*ParseError` with the line number, whose `Unwrap` method exposes the cause, so callers can use both `errors.As` (to get the line) and `errors.Is` (to check `ErrSyntax` or `ErrDuplicateKey`).

### Starter

```go
//go:build !solution

// Package config parses simple "key = value" configuration files and
// practices wrapping errors with context that callers can inspect.
package config

import (
	"errors"
	"io"
)

// ErrSyntax is wrapped by every error caused by a malformed line.
var ErrSyntax = errors.New("syntax error")

// ErrDuplicateKey is wrapped when a key appears twice.
var ErrDuplicateKey = errors.New("duplicate key")

// ParseError says which line of the input failed, and why.
type ParseError struct {
	Line int   // 1-based line number
	Err  error // the underlying cause
}

// Error formats the error as "line N: cause".
func (e *ParseError) Error() string {
	// TODO: implement me.
	return ""
}

// Unwrap returns the underlying cause, so errors.Is and errors.As
// can look through a ParseError.
func (e *ParseError) Unwrap() error {
	// TODO: implement me.
	return nil
}

// ParseLine parses one "key = value" line. Spaces around the key and
// value are trimmed. A line without "=" or with an empty key returns
// an error that wraps ErrSyntax and mentions the line's text.
func ParseLine(line string) (key, value string, err error) {
	// TODO: implement me.
	return "", "", nil
}

// Load reads every line of r. Blank lines and lines starting with "#"
// (after trimming spaces) are ignored. The first bad line stops
// parsing and is returned as a *ParseError whose Err wraps either
// ErrSyntax or ErrDuplicateKey.
func Load(r io.Reader) (map[string]string, error) {
	// TODO: implement me.
	return nil, nil
}
```

```sh
cd exercises
go test ./m05/config/
```

### Reference solution — try the exercise first

```go
//go:build solution

// Package config parses simple "key = value" configuration files and
// practices wrapping errors with context that callers can inspect.
package config

import (
	"bufio"
	"errors"
	"fmt"
	"io"
	"strings"
)

// ErrSyntax is wrapped by every error caused by a malformed line.
var ErrSyntax = errors.New("syntax error")

// ErrDuplicateKey is wrapped when a key appears twice.
var ErrDuplicateKey = errors.New("duplicate key")

// ParseError says which line of the input failed, and why.
type ParseError struct {
	Line int
	Err  error
}

// Error formats the error as "line N: cause".
func (e *ParseError) Error() string { return fmt.Sprintf("line %d: %v", e.Line, e.Err) }

// Unwrap returns the underlying cause.
func (e *ParseError) Unwrap() error { return e.Err }

// ParseLine parses one "key = value" line.
func ParseLine(line string) (key, value string, err error) {
	k, v, ok := strings.Cut(line, "=")
	k = strings.TrimSpace(k)
	if !ok || k == "" {
		return "", "", fmt.Errorf("%w: expected key = value, got %q", ErrSyntax, line)
	}
	return k, strings.TrimSpace(v), nil
}

// Load reads every line of r into a map.
func Load(r io.Reader) (map[string]string, error) {
	cfg := make(map[string]string)
	sc := bufio.NewScanner(r)
	for n := 1; sc.Scan(); n++ {
		line := strings.TrimSpace(sc.Text())
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		k, v, err := ParseLine(line)
		if err != nil {
			return nil, &ParseError{Line: n, Err: err}
		}
		if _, dup := cfg[k]; dup {
			return nil, &ParseError{Line: n, Err: fmt.Errorf("%w: %q", ErrDuplicateKey, k)}
		}
		cfg[k] = v
	}
	if err := sc.Err(); err != nil {
		return nil, fmt.Errorf("read config: %w", err)
	}
	return cfg, nil
}
```

```sh
go test -tags solution ./m05/config/
```



## Key takeaways

- `fmt.Errorf("context: %w", err)` adds context and keeps the original error in a chain.
- Compare errors with `errors.Is`, never `==`.
- Extract typed errors with `errors.As(err, &target)`, or `errors.AsType[T](err)` in Go 1.26+.
- Use `%v` to hide an underlying error on purpose.
- Implement `Unwrap() error` on wrapping error types.

## Further reading

- [Working with Errors in Go 1.13](https://go.dev/blog/go1.13-errors) on the Go blog
- [Package errors](https://pkg.go.dev/errors)
- [Go 1.26 release notes](https://go.dev/doc/go1.26) for `errors.AsType`
