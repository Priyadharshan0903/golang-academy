# 7.6 Goroutine leaks: finding and preventing them

Why goroutines leak, the patterns that cause most leaks, how to detect them in tests and production, and the goroutineleak profile in Go 1.27.

## What you will learn

- What a goroutine leak is and why it matters
- The handful of patterns that cause almost every leak
- How to test for leaks
- How to find leaks in a running service with `pprof`
- The `goroutineleak` profile, new in Go 1.27

## The idea

A goroutine **leaks** when it can never finish: it is blocked forever on a channel, a lock or I/O that will never complete. The garbage collector does not free goroutines that are blocked, nor anything they reference. Each leak is small, but leaks usually happen **per request**, so memory and goroutine counts grow steadily until the service is restarted or killed.

## The usual causes

Almost every leak is one of these:

1. **A send nobody receives.** The receiver returned early (timeout, error, first result won).
2. **A receive nobody sends to, or a `range` over a channel nobody closes.**
3. **A goroutine waiting on a context nobody cancels**, or not watching any context at all.
4. **A lock that is never unlocked.**
5. **Blocking I/O without a timeout**, such as an HTTP request with no deadline.

Here is cause 1 in its most common form, "ask several, take the fastest":



Source: `examples/m07/leaks/leaks_test.go`

```go
// firstResultLeaky asks several replicas and returns the fastest answer.
// The slower goroutines block forever on the unbuffered send: a leak.
func firstResultLeaky(replicas int) string {
	ch := make(chan string)
	for i := range replicas {
		go func() {
			time.Sleep(time.Duration(i) * time.Millisecond)
			ch <- fmt.Sprintf("replica %d", i) // only one send is ever received
		}()
	}
	return <-ch
}

// firstResult fixes it with a buffer big enough for every send.
func firstResult(replicas int) string {
	ch := make(chan string, replicas)
	for i := range replicas {
		go func() {
			time.Sleep(time.Duration(i) * time.Millisecond)
			ch <- fmt.Sprintf("replica %d", i)
		}()
	}
	return <-ch
}
```



After the first value is received, every other replica blocks on its send forever. The fix gives the channel enough buffer for every send, so all goroutines can finish. The other standard fix is to make the sender `select` on `ctx.Done()`.

## Prevent leaks by design



Source: `examples/m07/leaks/leaks_test.go`

```go
// fetch respects ctx: when the caller gives up, the goroutine
// selects on Done and exits instead of blocking forever.
func fetch(ctx context.Context, delay time.Duration) (string, error) {
	ch := make(chan string, 1)
	go func() {
		time.Sleep(delay) // stands in for slow I/O
		ch <- "data"
	}()
	select {
	case v := <-ch:
		return v, nil
	case <-ctx.Done():
		return "", ctx.Err()
	}
}

func Example_contextPreventsLeak() {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Millisecond)
	defer cancel()

	_, err := fetch(ctx, 50*time.Millisecond)
	fmt.Println(errors.Is(err, context.DeadlineExceeded))

	// Output:
	// true
}
```

Local command:

```sh
go test -run Example_contextPreventsLeak -v ./examples/m07/leaks
```



Rules that make leaks rare:

- **Every goroutine has an owner** who knows how it stops.
- **Every blocking operation has a way out**: a `ctx.Done()` case, a closed channel, a timeout.
- **Result channels that may be abandoned have a buffer** big enough for all senders.
- **`defer cancel()`** right after creating a context.

## Detecting leaks in tests

The simplest check counts goroutines before and after:



Source: `examples/m07/leaks/leaks_test.go`

```go
// waitForGoroutines polls until the goroutine count drops back to
// baseline, or gives up after a timeout. Libraries like go.uber.org/goleak
// do the same thing more thoroughly.
func waitForGoroutines(baseline int, timeout time.Duration) int {
	deadline := time.Now().Add(timeout)
	for {
		n := runtime.NumGoroutine()
		if n <= baseline || time.Now().After(deadline) {
			return n
		}
		time.Sleep(5 * time.Millisecond)
	}
}

func TestLeakyVersionLeaks(t *testing.T) {
	base := runtime.NumGoroutine()
	firstResultLeaky(5)
	if n := waitForGoroutines(base, 100*time.Millisecond); n <= base {
		t.Skip("leak not observed this time") // it should leak 4 goroutines
	} else {
		t.Logf("%d goroutines leaked", n-base)
	}
}

func TestFixedVersionDoesNotLeak(t *testing.T) {
	base := runtime.NumGoroutine()
	for range 20 {
		firstResult(5)
	}
	if n := waitForGoroutines(base, time.Second); n > base {
		t.Fatalf("%d goroutines leaked", n-base)
	}
}
```

Local command:

```sh
go test -v -run Version ./examples/m07/leaks
```



Because goroutines take a moment to exit, poll for a short time rather than checking once. The exercises in Modules 6 and 7 use exactly this technique. For larger projects, `go.uber.org/goleak` does it more thoroughly: it lists the leaked goroutines' stacks and ignores known background goroutines.

## Finding leaks in production

Import `net/http/pprof` in your service (on an internal port only), and you get:

```bash
# How many goroutines, grouped by stack:
curl -s http://localhost:6060/debug/pprof/goroutine?debug=1 | head -40

# Or explore interactively:
go tool pprof http://localhost:6060/debug/pprof/goroutine
```

A leak shows up as a stack with an ever-growing count, all blocked at the same line (`chan send`, `chan receive`, `select`). The `runtime/metrics` value `/sched/goroutines` (Go 1.26+) is a good thing to graph and alert on.

## The `goroutineleak` profile (Go 1.27)

The goroutine profile shows **every** blocked goroutine, and many of them are blocked legitimately (waiting for the next request, say). Go 1.26 introduced, as an experiment, and Go 1.27 made generally available, a profile that reports only goroutines the runtime can **prove** are leaked: goroutines blocked on a channel, mutex or condition that no running goroutine can reach anymore. The garbage collector finds them during its reachability analysis.



Source: `examples/m07/leaks/leakprofile_test.go`

```go
// The goroutineleak profile (Go 1.27+, experimental in 1.26) reports
// goroutines blocked on something no other goroutine can ever reach,
// found by the garbage collector. It is also served by net/http/pprof
// at /debug/pprof/goroutineleak.
func TestGoroutineLeakProfile(t *testing.T) {
	firstResultLeaky(3)
	time.Sleep(20 * time.Millisecond) // let the slow replicas block
	runtime.GC()

	var buf bytes.Buffer
	if err := pprof.Lookup("goroutineleak").WriteTo(&buf, 1); err != nil {
		t.Fatal(err)
	}
	if !strings.Contains(buf.String(), "firstResultLeaky") {
		t.Errorf("expected the leaked goroutines in the profile, got:\n%s", buf.String())
	}
}
```

Local command:

```sh
go test -v -run Profile ./examples/m07/leaks
```



In a service it is served at `/debug/pprof/goroutineleak` by `net/http/pprof`. It cannot find every leak (a goroutine blocked on a channel that is still referenced somewhere is not provably leaked), but what it reports is almost certainly a bug.

## Common mistakes

### Assuming the garbage collector will clean up

It does not free blocked goroutines. A leaked goroutine lives until the process exits.

### Timeouts on the caller side only

`select` with `time.After` protects the caller, but if the worker's send is unbuffered, the worker leaks. Fix both sides.

### HTTP clients without timeouts

`http.Get` with the default client has **no** timeout. A hung server leaks the goroutine (and the connection) forever. Use a client with `Timeout`, or a request context with a deadline (lesson 8.7).

## Key takeaways

- A leaked goroutine is blocked forever and is never freed, along with everything it references.
- Most leaks are unreceived sends, unclosed channels, uncancelled contexts or I/O without timeouts.
- Give every goroutine an owner and every blocking operation an exit.
- Test for leaks by comparing goroutine counts, or with `goleak`.
- In production, watch the goroutine profile and metrics; on Go 1.27, check `/debug/pprof/goroutineleak`.

## Further reading

- [Go 1.27 release notes: goroutineleak profile](https://go.dev/doc/go1.27)
- [Package runtime/pprof](https://pkg.go.dev/runtime/pprof) and [net/http/pprof](https://pkg.go.dev/net/http/pprof)
- [go.uber.org/goleak](https://pkg.go.dev/go.uber.org/goleak)
