# 7.4 errgroup and bounded concurrency

Run a group of goroutines where the first error cancels the rest, limit how many run at once, and see how golang.org/x/sync/errgroup works by building a small version of it.

## What you will learn

- The "first error cancels everything" pattern
- How `golang.org/x/sync/errgroup` implements it, by building a version yourself
- How `SetLimit` bounds concurrency with a semaphore
- How to use the real `errgroup` package
- Its limits, and when to choose something else

## The idea

A very common shape of concurrent work: start N tasks, wait for all of them, and if **any** fails, stop the others and report the error. Writing it by hand each time means a `WaitGroup`, a `sync.Once` for the first error, a cancellable context and a semaphore. The `errgroup` package, maintained by the Go team in `golang.org/x/sync`, wraps all of that.

## Building it from the standard library

Here is a compact version with the same API, so you can see exactly what happens inside:



Source: `examples/m07/boundedgroup/group.go`

```go
// Group runs functions in goroutines, cancels the shared context on
// the first error, and returns that error from Wait. It is a small
// version of golang.org/x/sync/errgroup, built only on the standard
// library, to show how that package works.
type Group struct {
	cancel  context.CancelCauseFunc
	wg      sync.WaitGroup
	sem     chan struct{} // nil means "no limit"
	errOnce sync.Once
	err     error
}

// WithContext returns a Group and a context that is cancelled when
// any function returns an error, or when Wait returns.
func WithContext(ctx context.Context) (*Group, context.Context) {
	ctx, cancel := context.WithCancelCause(ctx)
	return &Group{cancel: cancel}, ctx
}

// SetLimit allows at most n functions to run at once.
func (g *Group) SetLimit(n int) { g.sem = make(chan struct{}, n) }

// Go runs f in a new goroutine, blocking first if the limit is reached.
func (g *Group) Go(f func() error) {
	if g.sem != nil {
		g.sem <- struct{}{} // acquire a slot (blocks when full)
	}
	g.wg.Add(1)
	go func() {
		defer func() {
			if g.sem != nil {
				<-g.sem // release the slot
			}
			g.wg.Done()
		}()
		if err := f(); err != nil {
			g.errOnce.Do(func() { // keep only the FIRST error
				g.err = err
				if g.cancel != nil {
					g.cancel(err)
				}
			})
		}
	}()
}

// Wait blocks until all functions return, then returns the first error.
func (g *Group) Wait() error {
	g.wg.Wait()
	if g.cancel != nil {
		g.cancel(g.err)
	}
	return g.err
}
```



- `WithContext` derives a cancellable context. The group cancels it, with the first error as the cause, as soon as any function fails.
- `sync.Once` keeps only the **first** error.
- `SetLimit` creates a buffered channel used as a **semaphore**: `Go` must put a token in before starting a goroutine, so when `n` are running, the next `Go` call blocks.
- `Wait` waits for everything, then cancels the context to release resources.

Using it:



Source: `examples/m07/boundedgroup/group_test.go`

```go
func Example_firstErrorCancelsOthers() {
	g, ctx := WithContext(context.Background())
	var cancelled atomic.Int32

	for i := range 5 {
		g.Go(func() error {
			if i == 2 {
				return fmt.Errorf("task %d failed", i)
			}
			select {
			case <-ctx.Done(): // the failure cancels the rest
				cancelled.Add(1)
				return ctx.Err()
			case <-time.After(time.Second):
				return nil
			}
		})
	}

	fmt.Println(g.Wait())
	fmt.Println(cancelled.Load())

	// Output:
	// task 2 failed
	// 4
}
```

Local command:

```sh
go test -race -run Example_firstErrorCancelsOthers -v ./examples/m07/boundedgroup
```



One task fails, the other four see `ctx.Done()` and return early, and `Wait` returns the original failure.



Source: `examples/m07/boundedgroup/group_test.go`

```go
func Example_limit() {
	g, _ := WithContext(context.Background())
	g.SetLimit(3)

	var running, peak atomic.Int32
	for range 12 {
		g.Go(func() error {
			now := running.Add(1)
			for {
				p := peak.Load()
				if now <= p || peak.CompareAndSwap(p, now) {
					break
				}
			}
			time.Sleep(2 * time.Millisecond)
			running.Add(-1)
			return nil
		})
	}

	fmt.Println(g.Wait(), peak.Load() <= 3)

	// Output:
	// <nil> true
}
```

Local command:

```sh
go test -race -run Example_limit -v ./examples/m07/boundedgroup
```



## Using the real package

In real code, use `golang.org/x/sync/errgroup` rather than your own copy. It lives in this course's separate [`examples/thirdparty`](https://github.com/Priyadharshan0903/gopath-academy/tree/main/examples/thirdparty) module, so the main course module stays dependency-free:



Source: `examples/thirdparty/errgroupdemo/errgroupdemo_test.go`

```go
// fetchAll fetches every URL with at most 3 requests in flight, and
// stops all of them as soon as one fails.
func fetchAll(ctx context.Context, urls []string, fetch func(context.Context, string) (string, error)) ([]string, error) {
	g, ctx := errgroup.WithContext(ctx) // ctx is cancelled on the first error
	g.SetLimit(3)                       // bounded concurrency

	var mu sync.Mutex
	var bodies []string
	for _, u := range urls {
		g.Go(func() error { // blocks while 3 are already running
			body, err := fetch(ctx, u)
			if err != nil {
				return fmt.Errorf("fetch %s: %w", u, err)
			}
			mu.Lock()
			bodies = append(bodies, body)
			mu.Unlock()
			return nil
		})
	}
	if err := g.Wait(); err != nil { // waits for all, returns the first error
		return nil, err
	}
	sort.Strings(bodies)
	return bodies, nil
}
```

Local command:

```sh
cd examples/thirdparty && go mod tidy && go test ./errgroupdemo
```



The `x/sync/errgroup` API also has `TryGo`, which starts a goroutine only if the limit has room and reports whether it did, and the zero `errgroup.Group` (without `WithContext`) when you want first-error collection without cancellation.

## Limits of errgroup

- **Only the first error.** If you need every error, collect them yourself and join them (lesson 5.4).
- **Results are up to you.** `Go` takes `func() error`. Write results into an indexed slice or guard a shared structure with a mutex, as `fetchAll` does.
- **Panics are not converted to errors.** A panic in a group goroutine crashes the program like any other goroutine panic (lesson 5.5). Recover inside the function if the code might panic.
- **Cancellation is cooperative.** The context is cancelled, but each function must actually check it.

## Common mistakes

### Ignoring the derived context

Using the outer `ctx` instead of the one returned by `WithContext` means failures cannot cancel the other tasks.

### Shared results without synchronization

Appending to a shared slice from several `g.Go` functions without a mutex is a data race. Use indexes or a lock.

### No limit on huge inputs

`g.Go` for a million items without `SetLimit` starts a million goroutines. Set a limit.

## Key takeaways

- `errgroup` runs functions concurrently, waits for all, returns the first error and cancels the rest.
- It is built from a `WaitGroup`, a `sync.Once`, a cancellable context and an optional semaphore.
- `SetLimit` bounds concurrency; `TryGo` starts work only if there is room.
- Collect results with indexes or a mutex, recover panics yourself, and pass the derived context to every task.

## Further reading

- [Package golang.org/x/sync/errgroup](https://pkg.go.dev/golang.org/x/sync/errgroup)
- [Package golang.org/x/sync/semaphore](https://pkg.go.dev/golang.org/x/sync/semaphore) for weighted semaphores
