# 7. Concurrency patterns and context

Module 6 gave you the primitives. This module turns them into the patterns that real Go services are made of, all built around `context.Context`, the standard way to carry cancellation and deadlines through a program.

**Time:** about 4 to 5 hours, plus exercises and two projects. Keep using `-race`.

- [7.1 context.Context: cancellation, deadlines, values](01-context.md)
- [7.2 Worker pools](02-worker-pools.md)
- [7.3 Pipelines and fan-out / fan-in](03-pipelines.md)
- [7.4 errgroup and bounded concurrency](04-errgroup.md)
- [7.5 Rate limiting and backpressure](05-rate-limiting.md)
- [7.6 Goroutine leaks: finding and preventing them](06-goroutine-leaks.md)
- [7.7 Graceful shutdown](07-graceful-shutdown.md)
- [7.8 Projects: token bucket rate limiter and concurrent crawler](08-projects.md)
