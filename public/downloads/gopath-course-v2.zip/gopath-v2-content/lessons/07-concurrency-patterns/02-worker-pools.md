# 7.2 Worker pools

Process a stream of jobs with a fixed number of goroutines: the four parts of a worker pool, collecting results in order, cancellation, and sizing the pool.

## What you will learn

- Why bounding concurrency matters
- The four parts of a worker pool: workers, feeder, closer and collector
- How to keep results in input order
- How to make every part of the pool cancellable
- How to choose the number of workers

## The idea

"One goroutine per item" is fine for ten items. For a million it is not: you open a million connections, allocate a million stacks, and overwhelm whatever you are calling. A **worker pool** runs a **fixed number** of goroutines that pull jobs from a channel, so concurrency stays bounded no matter how much work arrives.

## The pattern



Source: `examples/m07/workerpool/workerpool_test.go`

```go
type job struct {
	id   int
	text string
}

type result struct {
	id    int
	words int
}

// countWords runs a fixed number of workers over a stream of jobs.
func countWords(ctx context.Context, texts []string, workers int) []int {
	jobs := make(chan job)
	results := make(chan result)

	// 1. Start the workers. Each reads jobs until the channel closes.
	var wg sync.WaitGroup
	for range workers {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for j := range jobs {
				r := result{id: j.id, words: len(strings.Fields(j.text))}
				select {
				case results <- r:
				case <-ctx.Done():
					return
				}
			}
		}()
	}

	// 2. Feed the jobs, then close the channel so workers stop.
	go func() {
		defer close(jobs)
		for i, t := range texts {
			select {
			case jobs <- job{id: i, text: t}:
			case <-ctx.Done():
				return
			}
		}
	}()

	// 3. Close results once every worker is done.
	go func() {
		wg.Wait()
		close(results)
	}()

	// 4. Collect. Results arrive in any order, so place them by id.
	counts := make([]int, len(texts))
	for r := range results {
		counts[r.id] = r.words
	}
	return counts
}

func Example_workerPool() {
	texts := []string{
		"go is fun",
		"channels connect goroutines",
		"",
		"a worker pool bounds concurrency to a fixed size",
	}
	fmt.Println(countWords(context.Background(), texts, 2))

	// Output:
	// [3 3 0 9]
}
```

Local command:

```sh
go test -race -run Example_workerPool -v ./examples/m07/workerpool
```



Four pieces, each with one job:

1. **Workers** (`workers` goroutines) loop over `jobs` until it is closed. They are the only goroutines doing real work.
2. **The feeder** sends every job, then **closes** `jobs`, which ends the workers' `range` loops.
3. **The closer** waits for all workers (`wg.Wait()`), then closes `results`. This must be a separate goroutine: if the collector called `Wait` itself, it would deadlock, because workers block on sending results that nobody is receiving yet.
4. **The collector** (here, the calling function) ranges over `results` until it is closed.

Every send selects on `ctx.Done()` too, so cancelling the context unblocks every goroutine and nothing leaks.

## Keeping results in order

Workers finish in any order. Carry the input's **index** with each job and result, and write results into a pre-sized slice by index, as `counts[r.id] = r.words` does. This is cheaper and simpler than sorting afterwards.

## Handling errors

The example has no errors. With real work you choose a policy:

- **Fail fast**: stop everything on the first error. Cancel a shared context and return the error. `errgroup` (lesson 7.4) packages exactly this.
- **Collect all**: keep going, put each error in its result, and report them together (for example with `errors.Join`, lesson 5.4).

The `pmap` exercise below implements fail fast.

## How many workers?

| Work type | Starting point |
|---|---|
| CPU-bound (hashing, parsing, compression) | `runtime.GOMAXPROCS(0)`, the number of usable CPUs |
| I/O-bound (HTTP calls, database queries) | Higher, limited by what the **other side** can handle: connection pool size, API rate limits |
| Mixed | Measure. Start small and increase while throughput improves |

More workers than useful only adds contention. For I/O, the downstream service's limits usually decide the number, which is why worker pools pair naturally with rate limiting (lesson 7.5).

## Common mistakes

### Calling `wg.Wait()` before reading results

Workers block sending results, `Wait` never returns: deadlock. Close `results` from a separate goroutine.

### Forgetting to close the jobs channel

Workers wait forever for the next job. The feeder must `close(jobs)` when done.

### A worker that returns early without draining

If one worker exits on error while the feeder keeps sending, the remaining workers handle the load, but if **all** exit, the feeder blocks forever. Make the feeder select on `ctx.Done()` and cancel the context when workers give up.

### Unbounded result buffering

Making `results` a channel with a huge buffer to "avoid blocking" hides backpressure and can use lots of memory. Let the collector set the pace.

## Exercise



## Exercise: 7.2 Worker pools

Write a generic `Map` that runs a function over a slice with a fixed number of workers, returns results **in input order**, cancels the remaining work on the first error, and never leaks goroutines. The tests check ordering, the concurrency limit, cancellation and leaks.

### Starter

```go
//go:build !solution

// Package pmap runs a function over a slice in parallel, with a
// concurrency limit, results in input order, and cancellation on the
// first error. It combines worker pools, context and generics.
package pmap

import "context"

// Map calls f for every input using at most workers goroutines and
// returns the results in the same order as inputs.
//
// If any call returns an error, Map cancels the context passed to the
// other calls, waits for every goroutine it started to finish, and
// returns the first error. If ctx itself is cancelled, Map returns an
// error wrapping ctx.Err().
//
// workers is at least 1. Map must not leak goroutines.
func Map[T, R any](ctx context.Context, inputs []T, workers int, f func(context.Context, T) (R, error)) ([]R, error) {
	// TODO: implement me.
	return nil, nil
}
```

```sh
cd exercises
go test ./m07/pmap/
```

### Reference solution — try the exercise first

```go
//go:build solution

// Package pmap runs a function over a slice in parallel, with a
// concurrency limit, results in input order, and cancellation on the
// first error. It combines worker pools, context and generics.
package pmap

import (
	"context"
	"sync"
)

// Map calls f for every input using at most workers goroutines.
func Map[T, R any](ctx context.Context, inputs []T, workers int, f func(context.Context, T) (R, error)) ([]R, error) {
	ctx, cancel := context.WithCancelCause(ctx)
	defer cancel(nil)

	results := make([]R, len(inputs)) // each index written by one goroutine
	indexes := make(chan int)

	var (
		wg       sync.WaitGroup
		once     sync.Once
		firstErr error
	)
	fail := func(err error) {
		once.Do(func() {
			firstErr = err
			cancel(err)
		})
	}

	for range max(1, workers) {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for i := range indexes {
				r, err := f(ctx, inputs[i])
				if err != nil {
					fail(err)
					return
				}
				results[i] = r
			}
		}()
	}

feed:
	for i := range inputs {
		select {
		case indexes <- i:
		case <-ctx.Done():
			break feed
		}
	}
	close(indexes)
	wg.Wait()

	if firstErr != nil {
		return nil, firstErr
	}
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	return results, nil
}
```

```sh
go test -tags solution ./m07/pmap/
```



## Key takeaways

- A worker pool bounds concurrency with a fixed number of goroutines reading from a jobs channel.
- Four roles: workers, a feeder that closes jobs, a closer that waits and closes results, and a collector.
- Carry indexes to keep results in order.
- Make every send cancellable with `select` on `ctx.Done()`.
- Size CPU-bound pools by CPUs, I/O-bound pools by downstream capacity.

## Further reading

- [Go Concurrency Patterns: Pipelines and cancellation](https://go.dev/blog/pipelines) on the Go blog
- [Package golang.org/x/sync/errgroup](https://pkg.go.dev/golang.org/x/sync/errgroup), the fail-fast pool in a box (lesson 7.4)
