# 7.8 Projects: token bucket rate limiter and concurrent crawler

Two complete concurrent programs: a token bucket rate limiter written from scratch, and a polite web crawler with a coordinator goroutine, a worker pool and cancellation.

These two projects put Modules 6 and 7 together. The crawler uses the rate limiter, so read them in order.

## Project 1: a token bucket rate limiter

Code: [`projects/ratelimit`](https://github.com/Priyadharshan0903/gopath-academy/tree/main/projects/ratelimit)

Lesson 7.5 introduced the token bucket and used `golang.org/x/time/rate`. This project implements the same algorithm with only the standard library, so you can see every detail.



Source: `projects/ratelimit/ratelimit.go`

```go
// Package ratelimit implements a token bucket rate limiter.
//
// A bucket holds up to Burst tokens and is refilled at Rate tokens per
// second. Each event takes one token. When the bucket is empty, events
// are rejected (Allow) or delayed (Wait) until a token is available.
//
// This is the same algorithm as golang.org/x/time/rate, written out
// with only the standard library so every step is visible.
package ratelimit

import (
	"context"
	"errors"
	"fmt"
	"math"
	"sync"
	"time"
)

// ErrExceedsBurst is returned by WaitN when n can never be satisfied.
var ErrExceedsBurst = errors.New("ratelimit: n exceeds burst")

// Bucket is a token bucket. It is safe for concurrent use.
type Bucket struct {
	mu     sync.Mutex
	rate   float64 // tokens added per second
	burst  float64 // capacity
	tokens float64 // tokens currently available
	last   time.Time
	now    func() time.Time
}

// New returns a full bucket that refills at rate tokens per second and
// holds at most burst tokens. It panics if rate <= 0 or burst < 1,
// because those are programming errors (lesson 5.5).
func New(rate float64, burst int) *Bucket {
	if rate <= 0 || burst < 1 {
		panic(fmt.Sprintf("ratelimit.New: invalid rate %v or burst %d", rate, burst))
	}
	b := &Bucket{rate: rate, burst: float64(burst), tokens: float64(burst), now: time.Now}
	b.last = b.now()
	return b
}

// refill adds the tokens earned since the last call. b.mu must be held.
// Refilling lazily, on demand, means no background goroutine or timer
// is needed: the bucket costs nothing while idle.
func (b *Bucket) refill(now time.Time) {
	elapsed := now.Sub(b.last).Seconds()
	if elapsed > 0 {
		b.tokens = math.Min(b.burst, b.tokens+elapsed*b.rate)
		b.last = now
	}
}

// Allow reports whether one event may happen now, and takes a token if so.
func (b *Bucket) Allow() bool { return b.AllowN(1) }

// AllowN reports whether n events may happen now, taking n tokens if so.
func (b *Bucket) AllowN(n int) bool {
	b.mu.Lock()
	defer b.mu.Unlock()
	b.refill(b.now())
	if b.tokens >= float64(n) {
		b.tokens -= float64(n)
		return true
	}
	return false
}

// Tokens returns the number of tokens currently available.
func (b *Bucket) Tokens() float64 {
	b.mu.Lock()
	defer b.mu.Unlock()
	b.refill(b.now())
	return b.tokens
}

// Wait blocks until one token is available or ctx is done.
func (b *Bucket) Wait(ctx context.Context) error { return b.WaitN(ctx, 1) }

// WaitN blocks until n tokens are available or ctx is done.
//
// It reserves the tokens up front (the balance may go negative) and
// then sleeps for the time needed to earn them back. Reserving first
// keeps waiters fair: each one is scheduled after the previous ones.
func (b *Bucket) WaitN(ctx context.Context, n int) error {
	if float64(n) > b.burst {
		return fmt.Errorf("%w: n=%d burst=%v", ErrExceedsBurst, n, b.burst)
	}

	b.mu.Lock()
	now := b.now()
	b.refill(now)
	b.tokens -= float64(n)
	var delay time.Duration
	if b.tokens < 0 {
		delay = time.Duration(-b.tokens / b.rate * float64(time.Second))
	}
	b.mu.Unlock()

	if delay == 0 {
		return nil
	}
	// Do not even start waiting if the deadline is too close.
	if deadline, ok := ctx.Deadline(); ok && deadline.Before(now.Add(delay)) {
		b.cancel(n)
		return fmt.Errorf("ratelimit: wait of %v would exceed context deadline: %w", delay, context.DeadlineExceeded)
	}

	timer := time.NewTimer(delay)
	defer timer.Stop()
	select {
	case <-timer.C:
		return nil
	case <-ctx.Done():
		b.cancel(n)
		return ctx.Err()
	}
}

// cancel returns n reserved tokens after a waiter gave up.
func (b *Bucket) cancel(n int) {
	b.mu.Lock()
	defer b.mu.Unlock()
	b.tokens = math.Min(b.burst, b.tokens+float64(n))
}
```



Design points:

- **Lazy refill.** There is no background goroutine adding tokens. Each call computes how many tokens accumulated since the last call (`elapsed * rate`, capped at `burst`). An idle bucket costs nothing.
- **One mutex** guards all fields. Every method locks, refills, and acts.
- **`WaitN` reserves before sleeping.** It subtracts the tokens immediately (the balance may go negative) and sleeps until they would be earned. That makes concurrent waiters fair: each is scheduled after the ones before it. If the context ends first, the reservation is returned.
- **Fail fast on impossible deadlines.** If the required wait is longer than the time left on the context, `WaitN` returns immediately instead of sleeping and failing later.
- **Injected clock.** The `now` field lets tests advance time manually and check exact token counts.

### Per-key limiting



Source: `projects/ratelimit/keyed.go`

```go
package ratelimit

import (
	"sync"
	"time"
)

// Keyed keeps one Bucket per key, for example per client IP or API key.
// It is safe for concurrent use.
type Keyed struct {
	mu      sync.Mutex
	rate    float64
	burst   int
	buckets map[string]*entry
	now     func() time.Time
}

type entry struct {
	bucket   *Bucket
	lastSeen time.Time
}

// NewKeyed returns a Keyed limiter whose buckets all use rate and burst.
func NewKeyed(rate float64, burst int) *Keyed {
	return &Keyed{rate: rate, burst: burst, buckets: make(map[string]*entry), now: time.Now}
}

// Allow reports whether one event for key may happen now.
func (k *Keyed) Allow(key string) bool {
	return k.bucket(key).Allow()
}

func (k *Keyed) bucket(key string) *Bucket {
	k.mu.Lock()
	defer k.mu.Unlock()
	e, ok := k.buckets[key]
	if !ok {
		b := New(k.rate, k.burst)
		b.now = k.now
		b.last = k.now()
		e = &entry{bucket: b}
		k.buckets[key] = e
	}
	e.lastSeen = k.now()
	return e.bucket
}

// Prune removes buckets not used for longer than idle, and returns how
// many it removed. Call it periodically, or memory grows with every
// key ever seen.
func (k *Keyed) Prune(idle time.Duration) int {
	k.mu.Lock()
	defer k.mu.Unlock()
	cutoff := k.now().Add(-idle)
	removed := 0
	for key, e := range k.buckets {
		if e.lastSeen.Before(cutoff) {
			delete(k.buckets, key)
			removed++
		}
	}
	return removed
}

// Len returns the number of keys currently tracked.
func (k *Keyed) Len() int {
	k.mu.Lock()
	defer k.mu.Unlock()
	return len(k.buckets)
}
```



`Keyed` gives every key (a client IP, an API key) its own bucket, created on first use. `Prune` deletes buckets that have been idle, so memory does not grow with every client ever seen. In Module 12 this becomes HTTP middleware that returns 429 Too Many Requests.

### Tests



Source: `projects/ratelimit/ratelimit_test.go`

```go
package ratelimit

import (
	"context"
	"errors"
	"sync"
	"sync/atomic"
	"testing"
	"time"
)

// fakeClock is a manually advanced clock for deterministic tests.
type fakeClock struct {
	mu sync.Mutex
	t  time.Time
}

func (c *fakeClock) Now() time.Time {
	c.mu.Lock()
	defer c.mu.Unlock()
	return c.t
}

func (c *fakeClock) Advance(d time.Duration) {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.t = c.t.Add(d)
}

func newTestBucket(rate float64, burst int) (*Bucket, *fakeClock) {
	clock := &fakeClock{t: time.Date(2026, 1, 1, 0, 0, 0, 0, time.UTC)}
	b := New(rate, burst)
	b.now = clock.Now
	b.last = clock.Now()
	return b, clock
}

func TestBurstThenEmpty(t *testing.T) {
	b, _ := newTestBucket(10, 3)
	for i := range 3 {
		if !b.Allow() {
			t.Fatalf("event %d should be allowed by the burst", i)
		}
	}
	if b.Allow() {
		t.Error("4th event should be rejected: bucket is empty")
	}
}

func TestRefill(t *testing.T) {
	b, clock := newTestBucket(10, 5) // one token every 100ms
	for b.Allow() {
	}
	clock.Advance(250 * time.Millisecond)
	if got := b.Tokens(); got < 2.49 || got > 2.51 {
		t.Errorf("after 250ms: %.2f tokens, want 2.5", got)
	}
	clock.Advance(time.Hour)
	if got := b.Tokens(); got != 5 {
		t.Errorf("tokens never exceed burst: got %v, want 5", got)
	}
}

func TestAllowN(t *testing.T) {
	b, _ := newTestBucket(1, 10)
	if !b.AllowN(7) || b.AllowN(4) || !b.AllowN(3) {
		t.Error("AllowN accounting is wrong")
	}
}

func TestWaitImmediate(t *testing.T) {
	b, _ := newTestBucket(1, 1)
	start := time.Now()
	if err := b.Wait(context.Background()); err != nil {
		t.Fatal(err)
	}
	if time.Since(start) > 50*time.Millisecond {
		t.Error("Wait should return immediately when a token is available")
	}
}

func TestWaitDelays(t *testing.T) {
	b := New(50, 1) // real clock: one token per 20ms
	b.Allow()
	start := time.Now()
	if err := b.Wait(context.Background()); err != nil {
		t.Fatal(err)
	}
	if d := time.Since(start); d < 15*time.Millisecond {
		t.Errorf("Wait returned after %v, want about 20ms", d)
	}
}

func TestWaitRespectsDeadline(t *testing.T) {
	b := New(1, 1) // a new token takes a full second
	b.Allow()
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Millisecond)
	defer cancel()
	start := time.Now()
	err := b.Wait(ctx)
	if !errors.Is(err, context.DeadlineExceeded) {
		t.Errorf("err = %v, want DeadlineExceeded", err)
	}
	if time.Since(start) > 100*time.Millisecond {
		t.Error("Wait should fail fast when the deadline is too close")
	}
	if got := b.Tokens(); got < -0.01 {
		t.Errorf("the failed waiter's reservation was not returned: %.2f tokens", got)
	}
}

func TestWaitNExceedsBurst(t *testing.T) {
	b := New(10, 2)
	if err := b.WaitN(context.Background(), 3); !errors.Is(err, ErrExceedsBurst) {
		t.Errorf("err = %v, want ErrExceedsBurst", err)
	}
}

func TestConcurrentAllow(t *testing.T) {
	b, _ := newTestBucket(1, 100) // frozen clock: exactly 100 tokens
	var allowed atomic.Int32
	var wg sync.WaitGroup
	for range 500 {
		wg.Add(1)
		go func() {
			defer wg.Done()
			if b.Allow() {
				allowed.Add(1)
			}
		}()
	}
	wg.Wait()
	if allowed.Load() != 100 {
		t.Errorf("allowed %d events, want exactly 100", allowed.Load())
	}
}

func TestNewPanicsOnBadConfig(t *testing.T) {
	defer func() {
		if recover() == nil {
			t.Error("New(0, 1) should panic")
		}
	}()
	New(0, 1)
}

func TestKeyed(t *testing.T) {
	clock := &fakeClock{t: time.Date(2026, 1, 1, 0, 0, 0, 0, time.UTC)}
	k := NewKeyed(1, 2)
	k.now = clock.Now

	if !k.Allow("a") || !k.Allow("a") || k.Allow("a") {
		t.Error("key a should get exactly its burst of 2")
	}
	if !k.Allow("b") {
		t.Error("key b has its own bucket")
	}
	clock.Advance(time.Minute)
	k.Allow("b")
	if removed := k.Prune(30 * time.Second); removed != 1 || k.Len() != 1 {
		t.Errorf("Prune removed %d, Len %d; want 1 and 1 (only a was idle)", removed, k.Len())
	}
}

func BenchmarkAllow(b *testing.B) {
	lim := New(1e9, 1<<30)
	for b.Loop() {
		lim.Allow()
	}
}

func BenchmarkAllowParallel(b *testing.B) {
	lim := New(1e9, 1<<30)
	b.RunParallel(func(pb *testing.PB) {
		for pb.Next() {
			lim.Allow()
		}
	})
}
```



With a fake clock, refill math can be checked exactly, and 500 concurrent goroutines get **exactly** 100 tokens. On Go 1.25 and later, [`synctest_test.go`](https://github.com/Priyadharshan0903/gopath-academy/blob/main/projects/ratelimit/synctest_test.go) also checks `Wait`'s real timer behavior on a virtual clock. The benchmarks are used again in Module 10.

## Project 2: a concurrent web crawler

Code: [`projects/crawler`](https://github.com/Priyadharshan0903/gopath-academy/tree/main/projects/crawler)

The crawler starts at a URL, follows links on the same host up to a depth limit, and reports every page's status.

### Architecture

```text
              tasks (unbuffered)
coordinator  ───────────────────▶  worker 1 ─┐
  owns:      ───────────────────▶  worker 2 ─┤  fetch (rate limited)
  - queue    ───────────────────▶  worker N ─┘
  - seen set ◀───────────────────  outcomes (unbuffered)
  - results
```

- **One coordinator goroutine owns all state**: the queue, the set of seen URLs and the results. Nothing is shared, so there are no mutexes at all; channels are the only synchronization.
- **A fixed pool of workers** only fetches pages and reports outcomes.
- **The coordinator's loop** selects between "send the next task" and "receive an outcome". The send case uses the **nil channel trick** from lesson 6.3: when the queue is empty, the send channel is `nil`, which disables that case.
- **Termination**: the crawl is done when the queue is empty **and** nothing is in flight. This is the classic subtle part of crawlers: an empty queue alone is not enough, because a running fetch may discover new links.



Source: `projects/crawler/internal/crawl/crawl.go`

```go
// Package crawl implements a concurrent, polite web crawler.
//
// One coordinator goroutine owns all crawl state (the queue and the set
// of seen URLs), and a fixed pool of workers does the fetching. Workers
// never touch shared state, so the only synchronization is channels.
package crawl

import (
	"context"
	"net/url"
)

// Limiter delays work to respect a rate limit. *ratelimit.Bucket from
// the ratelimit project satisfies it.
type Limiter interface {
	Wait(ctx context.Context) error
}

// Result describes one crawled URL.
type Result struct {
	URL    string
	Depth  int
	Status int
	Err    error
}

// Crawler crawls pages on the same host as the start URL.
type Crawler struct {
	Fetcher  Fetcher
	Workers  int     // concurrent fetches; values below 1 mean 1
	MaxDepth int     // 0 crawls only the start page
	MaxPages int     // stop after this many pages; 0 means no limit
	Limiter  Limiter // optional
}

type task struct {
	url   string
	depth int
}

type outcome struct {
	task
	page Page
	err  error
}

// Crawl visits start and the pages it links to, breadth first, until
// MaxDepth or MaxPages is reached or ctx is done. It returns one Result
// per visited URL, in the order they finished.
func (c *Crawler) Crawl(ctx context.Context, start string) ([]Result, error) {
	startURL, err := url.Parse(start)
	if err != nil {
		return nil, err
	}
	ctx, cancel := context.WithCancel(ctx)
	defer cancel() // stops the workers when Crawl returns

	tasks := make(chan task)
	outcomes := make(chan outcome)

	workers := max(1, c.Workers)
	for range workers {
		go c.worker(ctx, tasks, outcomes)
	}

	// Coordinator state: only this goroutine reads or writes it.
	seen := map[string]bool{normalize(startURL): true}
	queue := []task{{url: startURL.String(), depth: 0}}
	inFlight := 0
	var results []Result

	for len(queue) > 0 || inFlight > 0 {
		// The nil-channel trick (lesson 6.3): only enable the send case
		// when there is something to send.
		var send chan<- task
		var next task
		if len(queue) > 0 && (c.MaxPages == 0 || len(results)+inFlight < c.MaxPages) {
			send, next = tasks, queue[0]
		}

		select {
		case send <- next:
			queue = queue[1:]
			inFlight++
		case o := <-outcomes:
			inFlight--
			results = append(results, Result{URL: o.url, Depth: o.depth, Status: o.page.Status, Err: o.err})
			if o.err != nil || o.depth >= c.MaxDepth {
				continue
			}
			for _, link := range o.page.Links {
				u, err := url.Parse(link)
				if err != nil || u.Host != startURL.Host || (u.Scheme != "http" && u.Scheme != "https") {
					continue // stay on the same site
				}
				key := normalize(u)
				if !seen[key] {
					seen[key] = true
					queue = append(queue, task{url: u.String(), depth: o.depth + 1})
				}
			}
		case <-ctx.Done():
			return results, ctx.Err()
		}
		if c.MaxPages > 0 && len(results) >= c.MaxPages && inFlight == 0 {
			break
		}
	}
	return results, nil
}

func (c *Crawler) worker(ctx context.Context, tasks <-chan task, outcomes chan<- outcome) {
	for {
		var t task
		select {
		case t = <-tasks:
		case <-ctx.Done():
			return
		}
		o := outcome{task: t}
		if c.Limiter != nil {
			o.err = c.Limiter.Wait(ctx)
		}
		if o.err == nil {
			o.page, o.err = c.Fetcher.Fetch(ctx, t.url)
		}
		select {
		case outcomes <- o:
		case <-ctx.Done():
			return
		}
	}
}

// normalize removes parts of a URL that do not identify a different page.
func normalize(u *url.URL) string {
	n := *u
	n.Fragment = ""
	if n.Path == "" {
		n.Path = "/"
	}
	return n.String()
}
```



### Fetching



Source: `projects/crawler/internal/crawl/fetch.go`

```go
package crawl

import (
	"context"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"regexp"
	"time"
)

// Page is what a Fetcher returns for one URL.
type Page struct {
	Status int
	Links  []string // absolute URLs found on the page
}

// Fetcher downloads a page and extracts its links. The crawler only
// depends on this interface, so tests can use a fake (lesson 4.2).
type Fetcher interface {
	Fetch(ctx context.Context, rawURL string) (Page, error)
}

// HTTPFetcher fetches pages over HTTP.
type HTTPFetcher struct {
	Client  *http.Client
	MaxBody int64 // bytes to read per page; 0 means 1 MiB
}

// NewHTTPFetcher returns a fetcher with a sensible client timeout.
func NewHTTPFetcher() *HTTPFetcher {
	return &HTTPFetcher{Client: &http.Client{Timeout: 10 * time.Second}}
}

// hrefPattern finds href attributes. A regular expression is NOT a
// real HTML parser; production crawlers should use golang.org/x/net/html.
// It keeps this project dependency-free and is good enough for the tests.
var hrefPattern = regexp.MustCompile(`(?i)href\s*=\s*["']([^"'#]+)`)

// Fetch downloads rawURL and returns its status and links.
func (f *HTTPFetcher) Fetch(ctx context.Context, rawURL string) (Page, error) {
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, rawURL, nil)
	if err != nil {
		return Page{}, fmt.Errorf("build request: %w", err)
	}
	req.Header.Set("User-Agent", "gopath-academy-crawler/1.0")

	resp, err := f.Client.Do(req)
	if err != nil {
		return Page{}, err
	}
	defer resp.Body.Close()

	limit := f.MaxBody
	if limit == 0 {
		limit = 1 << 20
	}
	body, err := io.ReadAll(io.LimitReader(resp.Body, limit))
	if err != nil {
		return Page{Status: resp.StatusCode}, fmt.Errorf("read body: %w", err)
	}

	base := resp.Request.URL // after redirects
	var links []string
	for _, m := range hrefPattern.FindAllSubmatch(body, -1) {
		ref, err := url.Parse(string(m[1]))
		if err != nil {
			continue
		}
		links = append(links, base.ResolveReference(ref).String())
	}
	return Page{Status: resp.StatusCode, Links: links}, nil
}
```



- The `Fetcher` interface keeps the crawler testable.
- Every request carries the context, so cancelling the crawl aborts in-flight HTTP requests too.
- The body is read through `io.LimitReader`, so a huge page cannot exhaust memory.
- Links are found with a regular expression. That is **not** a correct HTML parser, and the code says so; a production crawler should use `golang.org/x/net/html`. It keeps the project dependency-free.

### Testing without the internet



Source: `projects/crawler/internal/crawl/crawl_test.go`

```go
package crawl

import (
	"context"
	"errors"
	"fmt"
	"net/http"
	"net/http/httptest"
	"runtime"
	"slices"
	"strings"
	"sync/atomic"
	"testing"
	"time"
)

// testSite serves a small website with a cycle, a broken link, an
// external link and a slow page.
func testSite(t *testing.T, hits *atomic.Int32) *httptest.Server {
	t.Helper()
	pages := map[string]string{
		"/":         `<a href="/a">a</a> <a href="/b">b</a> <a href="https://elsewhere.example/">ext</a>`,
		"/a":        `<a href="/">home</a> <a href="/a/deep">deep</a> <a href="/missing">broken</a>`,
		"/b":        `<a href="/a#section">a again</a> <a href='/slow'>slow</a>`,
		"/a/deep":   `<a href="/a/deeper">deeper</a>`,
		"/a/deeper": `the end`,
		"/slow":     `slow page`,
	}
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if hits != nil {
			hits.Add(1)
		}
		if r.URL.Path == "/slow" {
			time.Sleep(30 * time.Millisecond)
		}
		body, ok := pages[r.URL.Path]
		if !ok {
			http.NotFound(w, r)
			return
		}
		fmt.Fprint(w, body)
	}))
	t.Cleanup(srv.Close)
	return srv
}

func paths(results []Result, prefix string) []string {
	var out []string
	for _, r := range results {
		out = append(out, strings.TrimPrefix(r.URL, prefix))
	}
	slices.Sort(out)
	return out
}

func TestCrawlWholeSite(t *testing.T) {
	var hits atomic.Int32
	srv := testSite(t, &hits)
	c := &Crawler{Fetcher: NewHTTPFetcher(), Workers: 4, MaxDepth: 10}

	results, err := c.Crawl(context.Background(), srv.URL+"/")
	if err != nil {
		t.Fatal(err)
	}
	want := []string{"/", "/a", "/a/deep", "/a/deeper", "/b", "/missing", "/slow"}
	if got := paths(results, srv.URL); !slices.Equal(got, want) {
		t.Errorf("visited %v\nwant    %v", got, want)
	}
	if int(hits.Load()) != len(want) {
		t.Errorf("server got %d requests for %d pages: something was fetched twice", hits.Load(), len(want))
	}
	for _, r := range results {
		if strings.HasSuffix(r.URL, "/missing") && r.Status != http.StatusNotFound {
			t.Errorf("/missing status = %d, want 404", r.Status)
		}
	}
}

func TestMaxDepth(t *testing.T) {
	srv := testSite(t, nil)
	c := &Crawler{Fetcher: NewHTTPFetcher(), Workers: 2, MaxDepth: 1}
	results, err := c.Crawl(context.Background(), srv.URL+"/")
	if err != nil {
		t.Fatal(err)
	}
	if got := paths(results, srv.URL); !slices.Equal(got, []string{"/", "/a", "/b"}) {
		t.Errorf("depth 1 visited %v", got)
	}
}

func TestMaxPages(t *testing.T) {
	srv := testSite(t, nil)
	c := &Crawler{Fetcher: NewHTTPFetcher(), Workers: 3, MaxDepth: 10, MaxPages: 3}
	results, err := c.Crawl(context.Background(), srv.URL+"/")
	if err != nil {
		t.Fatal(err)
	}
	if len(results) != 3 {
		t.Errorf("got %d results, want exactly 3", len(results))
	}
}

func TestTimeout(t *testing.T) {
	srv := testSite(t, nil)
	c := &Crawler{Fetcher: NewHTTPFetcher(), Workers: 1, MaxDepth: 10, Limiter: slowLimiter{50 * time.Millisecond}}
	ctx, cancel := context.WithTimeout(context.Background(), 80*time.Millisecond)
	defer cancel()
	_, err := c.Crawl(ctx, srv.URL+"/")
	if !errors.Is(err, context.DeadlineExceeded) {
		t.Errorf("err = %v, want DeadlineExceeded", err)
	}
}

type slowLimiter struct{ d time.Duration }

func (s slowLimiter) Wait(ctx context.Context) error {
	select {
	case <-time.After(s.d):
		return nil
	case <-ctx.Done():
		return ctx.Err()
	}
}

func TestNoGoroutineLeaks(t *testing.T) {
	srv := testSite(t, nil)
	before := runtime.NumGoroutine()
	for range 5 {
		c := &Crawler{Fetcher: NewHTTPFetcher(), Workers: 8, MaxDepth: 10}
		if _, err := c.Crawl(context.Background(), srv.URL+"/"); err != nil {
			t.Fatal(err)
		}
	}
	// Idle HTTP keep-alive connections own goroutines too; close them.
	http.DefaultClient.CloseIdleConnections()
	deadline := time.Now().Add(2 * time.Second)
	for runtime.NumGoroutine() > before+2 && time.Now().Before(deadline) {
		time.Sleep(10 * time.Millisecond)
	}
	if n := runtime.NumGoroutine(); n > before+2 {
		t.Errorf("%d goroutines still running after crawls finished (before: %d)", n, before)
	}
}
```



`httptest.NewServer` serves a small fake site on localhost with a cycle (`/a` links back to `/`), a fragment link to an already seen page, a broken link, an external link and a slow page. The tests check that every page is fetched **exactly once** (the server counts hits), that depth and page limits work, that a timeout cancels the crawl, and that no goroutines leak.

### Running it

```bash
make serve                                                  # in one terminal: the course site
go run ./projects/crawler/cmd/crawler -url http://localhost:1313/ -depth 2 -rate 20
```

Only crawl sites you own or have permission to crawl, and keep the rate low. Being polite is part of the design.

## Stretch goals

1. Respect `robots.txt` before crawling a site.
2. Add per-host rate limiting with `ratelimit.Keyed` so a crawler following several hosts is polite to each.
3. Replace the regular expression with `golang.org/x/net/html` in the `examples/thirdparty` module style (a separate module with the dependency).
4. Stream results to the caller through an `iter.Seq[Result]` instead of returning a slice at the end.

## Part 2, first half: recap

You can now:

- Start, wait for and stop goroutines without leaking them
- Use channels, `select`, mutexes and atomics, and know when to pick each
- Find data races with `-race` and explain the memory model's guarantees
- Propagate cancellation with `context`
- Build worker pools, pipelines and error groups
- Rate limit and apply backpressure
- Shut a service down gracefully

Next is **[Module 8: Standard library deep dives](../08-standard-library/README.md)**.
