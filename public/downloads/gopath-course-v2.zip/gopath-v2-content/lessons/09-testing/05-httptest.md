# 9.5 httptest

Test HTTP handlers directly with httptest.NewRecorder, test clients and full stacks with httptest.NewServer, and use the in-memory NewTestServer from Go 1.27.

## What you will learn

- Unit testing handlers with `httptest.NewRequest` and `httptest.NewRecorder`
- End-to-end tests with `httptest.NewServer`
- Which style to use when
- Testing clients against fake servers
- `httptest.NewTestServer` (Go 1.27) for in-memory, synctest-friendly servers

## Handlers under test



Source: `examples/m09/httptesting/handler.go`

```go
// GreetHandler responds to GET /greet?name=Ana with JSON.
func GreetHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		w.Header().Set("Allow", http.MethodGet)
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}
	name := strings.TrimSpace(r.URL.Query().Get("name"))
	if name == "" {
		http.Error(w, `{"error":"name is required"}`, http.StatusBadRequest)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]string{"greeting": "Hello, " + name + "!"})
}
```



## Unit tests with `ResponseRecorder`



Source: `examples/m09/httptesting/handler_test.go`

```go
// Unit test: call the handler directly with a ResponseRecorder.
// No network, no server, very fast.
func TestGreetHandler(t *testing.T) {
	tests := []struct {
		name       string
		method     string
		target     string
		wantStatus int
		wantBody   string
	}{
		{"ok", http.MethodGet, "/greet?name=Ana", 200, `{"greeting":"Hello, Ana!"}` + "\n"},
		{"missing name", http.MethodGet, "/greet", 400, `{"error":"name is required"}` + "\n"},
		{"wrong method", http.MethodPost, "/greet?name=Ana", 405, "method not allowed\n"},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			req := httptest.NewRequest(tt.method, tt.target, nil)
			rec := httptest.NewRecorder()

			GreetHandler(rec, req)

			if rec.Code != tt.wantStatus {
				t.Errorf("status = %d, want %d", rec.Code, tt.wantStatus)
			}
			if rec.Body.String() != tt.wantBody {
				t.Errorf("body = %q, want %q", rec.Body.String(), tt.wantBody)
			}
		})
	}
}
```

Local command:

```sh
go test -v -run TestGreetHandler$ ./examples/m09/httptesting
```



- `httptest.NewRequest(method, target, body)` builds an incoming server request. Unlike `http.NewRequest`, it panics on errors (fine in tests) and fills in fields a server would set.
- `httptest.NewRecorder()` is an `http.ResponseWriter` that records the status code (`rec.Code`), headers (`rec.Header()`) and body (`rec.Body`).
- You call the handler directly: no network, no goroutines, microseconds per case. This is the right default for handler logic.

## End-to-end tests with `NewServer`



Source: `examples/m09/httptesting/handler_test.go`

```go
// Integration-style test: a real HTTP server on localhost, exercised
// with a real client, including routing and headers.
func TestGreetOverHTTP(t *testing.T) {
	mux := http.NewServeMux()
	mux.HandleFunc("/greet", GreetHandler)
	srv := httptest.NewServer(mux)
	defer srv.Close()

	resp, err := srv.Client().Get(srv.URL + "/greet?name=Bo")
	if err != nil {
		t.Fatal(err)
	}
	defer resp.Body.Close()

	if ct := resp.Header.Get("Content-Type"); ct != "application/json" {
		t.Errorf("Content-Type = %q", ct)
	}
	var body map[string]string
	if err := json.NewDecoder(resp.Body).Decode(&body); err != nil {
		t.Fatal(err)
	}
	if body["greeting"] != "Hello, Bo!" {
		t.Errorf("greeting = %q", body["greeting"])
	}
	io.Copy(io.Discard, resp.Body)
}
```

Local command:

```sh
go test -v -run TestGreetOverHTTP ./examples/m09/httptesting
```



`httptest.NewServer(handler)` starts a real HTTP server on a random localhost port. Use it to test:

- **routing, middleware and the full handler stack** (`ServeMux`, authentication, logging);
- **your HTTP clients** against a fake API (lesson 8.7 and its exercise);
- behavior that depends on real connections: timeouts, streaming, redirects, TLS (`httptest.NewTLSServer`).

`srv.Client()` returns a client configured for the server (it trusts the test TLS certificate). Always `defer srv.Close()` or register it with `t.Cleanup`.

## Which one?

| Test | Use |
|---|---|
| A handler's own logic: validation, status codes, body | `NewRecorder` |
| Routing, middleware chain, path parameters | `NewServer` (or call the mux with a recorder) |
| An HTTP client | `NewServer` with a fake handler |
| Timeouts and cancellation | `NewServer`, or `NewTestServer` with `synctest` |

## `httptest.NewTestServer` (Go 1.27)

Go 1.27 added `httptest.NewTestServer(t, handler)`, which runs the server over an **in-memory network** instead of a real socket. Combined with `testing/synctest` (lesson 9.9), timeouts in clients and servers become deterministic and instant: a test of a 30-second timeout runs on the virtual clock and finishes immediately. It also registers its own cleanup with `t`.

## Common mistakes

### Forgetting to check the status code

A handler test that only checks the body passes even when the status is wrong. Check both.

### Comparing JSON as strings

Encoders may change spacing or key order between versions. Decode the body and compare values, or compare against a canonical form.

### Not closing the test server

Leaks a listener and goroutines per test. Use `t.Cleanup(srv.Close)`.

## Exercise



## Exercise: 9.5 httptest

Implement an HTTP handler for `GET /fizzbuzz?n=N` that validates input, sets headers, returns JSON and rejects other methods with `405` and an `Allow` header. The tests use both `NewRecorder` and `NewServer`.

### Starter

```go
//go:build !solution

// Package fizzhttp practices writing an HTTP handler that is easy to
// test with net/http/httptest.
package fizzhttp

import "net/http"

// Handler serves GET /fizzbuzz?n=N and responds with JSON:
//
//	{"n": 5, "result": ["1","2","Fizz","4","Buzz"]}
//
// Rules:
//   - Only GET is allowed; other methods get 405 with an "Allow: GET" header.
//   - n must be an integer from 1 to 1000; otherwise respond 400 with a
//     JSON body {"error": "..."} (any message).
//   - Successful responses set "Content-Type: application/json".
//   - Each element is "FizzBuzz" for multiples of 15, "Fizz" for 3,
//     "Buzz" for 5, and the number itself otherwise.
func Handler(w http.ResponseWriter, r *http.Request) {
	// TODO: implement me.
	w.WriteHeader(http.StatusNotImplemented)
}
```

```sh
cd exercises
go test ./m09/fizzhttp/
```

### Reference solution — try the exercise first

```go
//go:build solution

// Package fizzhttp practices writing an HTTP handler that is easy to
// test with net/http/httptest.
package fizzhttp

import (
	"encoding/json"
	"net/http"
	"strconv"
)

// Handler serves GET /fizzbuzz?n=N with a JSON FizzBuzz sequence.
func Handler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		w.Header().Set("Allow", http.MethodGet)
		writeJSON(w, http.StatusMethodNotAllowed, map[string]string{"error": "method not allowed"})
		return
	}
	n, err := strconv.Atoi(r.URL.Query().Get("n"))
	if err != nil || n < 1 || n > 1000 {
		writeJSON(w, http.StatusBadRequest, map[string]string{"error": "n must be an integer from 1 to 1000"})
		return
	}
	result := make([]string, n)
	for i := 1; i <= n; i++ {
		switch {
		case i%15 == 0:
			result[i-1] = "FizzBuzz"
		case i%3 == 0:
			result[i-1] = "Fizz"
		case i%5 == 0:
			result[i-1] = "Buzz"
		default:
			result[i-1] = strconv.Itoa(i)
		}
	}
	writeJSON(w, http.StatusOK, map[string]any{"n": n, "result": result})
}

func writeJSON(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	json.NewEncoder(w).Encode(v)
}
```

```sh
go test -tags solution ./m09/fizzhttp/
```



## Key takeaways

- Test handler logic directly with `NewRequest` and `NewRecorder`.
- Use `NewServer` for routing, middleware, real connections and client tests.
- Check status, headers and body; decode JSON instead of comparing strings.
- Go 1.27's `NewTestServer` uses an in-memory network that works with `synctest`.

## Further reading

- [Package net/http/httptest](https://pkg.go.dev/net/http/httptest)
- [Go 1.27 release notes](https://go.dev/doc/go1.27)
