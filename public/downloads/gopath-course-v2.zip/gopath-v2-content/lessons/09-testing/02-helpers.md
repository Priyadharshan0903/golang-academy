# 9.2 Test helpers, t.Cleanup, t.Context and golden files

Write helpers with t.Helper, manage resources with t.Cleanup and t.TempDir, set environment safely with t.Setenv, use t.Context, keep fixtures in testdata, and compare large outputs with golden files.

## What you will learn

- Writing helpers that report failures at the caller's line, with `t.Helper()`
- `t.TempDir`, `t.Setenv` and `t.Chdir` for safe, self-cleaning setup
- `t.Cleanup`, and how it differs from `defer`
- `t.Context` (Go 1.24) for tests of context-aware code
- The `testdata` directory and **golden files** with an `-update` flag

## Helpers



Source: `examples/m09/helpers/config_test.go`

```go
// writeFile is a test helper. t.Helper() makes failures point at the
// caller's line instead of this function.
func writeFile(t *testing.T, name, content string) string {
	t.Helper()
	path := filepath.Join(t.TempDir(), name) // removed automatically after the test
	if err := os.WriteFile(path, []byte(content), 0o644); err != nil {
		t.Fatalf("write %s: %v", name, err)
	}
	return path
}

func TestLoadEnvFile(t *testing.T) {
	path := writeFile(t, ".env", "# comment\nDB_HOST = localhost\nDB_PORT=5432\n")
	got, err := LoadEnvFile(path)
	if err != nil {
		t.Fatal(err) // stop: nothing below makes sense without a result
	}
	if got["DB_HOST"] != "localhost" || got["DB_PORT"] != "5432" {
		t.Errorf("got %v", got)
	}
}

func TestLoadEnvFileError(t *testing.T) {
	path := writeFile(t, "bad.env", "OK=1\nbroken line\n")
	_, err := LoadEnvFile(path)
	if err == nil || err.Error() != "bad.env:2: missing '='" {
		t.Errorf("err = %v", err)
	}
}
```

Local command:

```sh
go test -v -run TestLoadEnv ./examples/m09/helpers
```



- `t.Helper()` marks a function as a helper. When a helper calls `t.Fatalf`, the failure is reported at the line in the **test** that called the helper, which is where you want to look.
- Helpers take `t` (or `testing.TB`, which works for tests and benchmarks) as their first argument and call `t.Fatal` themselves, so the test reads as a clean sequence of steps.
- `t.TempDir()` returns a fresh directory that is **deleted automatically** when the test ends. No cleanup code, no leftovers, and parallel tests never collide.

The `testing` package has more of these self-cleaning helpers:

| Helper | Effect, undone automatically at the end of the test |
|---|---|
| `t.TempDir()` | create a temporary directory |
| `t.Setenv(k, v)` | set an environment variable |
| `t.Chdir(dir)` (Go 1.24) | change the working directory |
| `t.Context()` (Go 1.24) | a context cancelled when the test ends |
| `t.ArtifactDir()` (Go 1.26) | a directory for files you want to keep after the test, written under `-outputdir` |

## `t.Cleanup`



Source: `examples/m09/helpers/config_test.go`

```go
func TestCleanupOrder(t *testing.T) {
	var log []string
	t.Run("inner", func(t *testing.T) {
		t.Cleanup(func() { log = append(log, "cleanup 1") })
		t.Cleanup(func() { log = append(log, "cleanup 2") }) // runs first: LIFO, like defer
		log = append(log, "test body")
	})
	want := "test body,cleanup 2,cleanup 1"
	if got := join(log); got != want {
		t.Errorf("order = %s, want %s", got, want)
	}
}

func join(s []string) string {
	out := ""
	for i, v := range s {
		if i > 0 {
			out += ","
		}
		out += v
	}
	return out
}
```

Local command:

```sh
go test -v -run TestCleanupOrder ./examples/m09/helpers
```



`t.Cleanup(f)` registers `f` to run when the test (and all its subtests) finish, in last-in, first-out order. Unlike `defer`, a **helper** can register cleanup on behalf of the test:

```go
func startServer(t *testing.T) *httptest.Server {
	t.Helper()
	srv := httptest.NewServer(newHandler())
	t.Cleanup(srv.Close) // the test does not need to remember to close it
	return srv
}
```

## `t.Context`



Source: `examples/m09/helpers/config_test.go`

```go
func TestContext(t *testing.T) {
	ctx := t.Context() // Go 1.24+: cancelled just before Cleanup functions run
	select {
	case <-ctx.Done():
		t.Fatal("context should be live during the test")
	default:
	}
	t.Cleanup(func() {
		if ctx.Err() == nil {
			t.Error("context should be cancelled by the time cleanups run")
		}
	})
}
```

Local command:

```sh
go test -v -run TestContext ./examples/m09/helpers
```



Pass `t.Context()` to the code under test instead of `context.Background()`. It is cancelled just before cleanup runs, so goroutines started by the test get a signal to stop, and cleanup code can then wait for them.

## `testdata` and golden files

The `go` tool ignores any directory named **`testdata`**, so it is the conventional home for fixture files. Tests run with the package directory as the working directory, so `filepath.Join("testdata", "input.json")` works.

When output is large (rendered templates, generated code, CLI output, JSON reports), writing the expected value inline is unwieldy. A **golden file** stores the expected output in `testdata`, and an `-update` flag rewrites it:



Source: `examples/m09/helpers/config_test.go`

```go
var update = flag.Bool("update", false, "rewrite golden files with current output")

func TestRenderGolden(t *testing.T) {
	t.Setenv("APP_ENV", "test") // restored automatically after the test

	got := Render(map[string]string{"DB_PORT": "5432", "DB_HOST": "localhost", "LOG_LEVEL": "debug"})

	golden := filepath.Join("testdata", "render.golden")
	if *update {
		os.WriteFile(golden, []byte(got), 0o644)
	}
	want, err := os.ReadFile(golden)
	if err != nil {
		t.Fatal(err)
	}
	if got != string(want) {
		t.Errorf("output does not match %s (run with -update to accept)\n got:\n%s\nwant:\n%s", golden, got, want)
	}
}
```

Local command:

```sh
go test -run TestRenderGolden ./examples/m09/helpers
```



```bash
go test ./examples/m09/helpers                 # compare with the golden file
go test ./examples/m09/helpers -update         # accept the current output
git diff examples/m09/helpers/testdata         # review the change before committing
```

The `git diff` step is the point of golden files: changes to output show up in code review as readable diffs.

## Common mistakes

### Helpers without `t.Helper()`

Every failure points to a line inside the helper, and you have to work out which caller it was.

### `os.Setenv` in tests

It changes the environment for every test in the process and is never restored. Use `t.Setenv`.

### Writing fixtures to the package directory

Tests that create files next to the source pollute the repository and break when run in parallel. Use `t.TempDir()`.

### Running `-update` without reviewing

Accepting golden files blindly turns tests into recorders of whatever the code currently does, bugs included.

## Key takeaways

- Call `t.Helper()` in helpers; let helpers call `t.Fatal`.
- Use `t.TempDir`, `t.Setenv`, `t.Chdir` and `t.Context`: they clean up after themselves.
- `t.Cleanup` runs registered functions after the test, and helpers can use it.
- Keep fixtures in `testdata`; use golden files with an `-update` flag for large outputs, and review the diffs.

## Further reading

- [Package testing: T](https://pkg.go.dev/testing#T)
- [Go 1.24 release notes: testing](https://go.dev/doc/go1.24#testing)
