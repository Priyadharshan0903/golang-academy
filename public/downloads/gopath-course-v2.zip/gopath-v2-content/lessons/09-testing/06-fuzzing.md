# 9.6 Fuzzing

Use Go's built-in fuzzer to find inputs that break your code: writing fuzz targets, choosing properties to check, seed corpora, saved failures and running fuzzing in CI.

## What you will learn

- What fuzzing is and what kinds of bugs it finds
- How to write a fuzz target with `testing.F`
- **Properties** worth checking: round trips, no panics, agreement with a reference
- The seed corpus and the `testdata/fuzz` directory
- How to run the fuzzer and use what it finds

## The idea

Unit tests check the cases **you** thought of. A fuzzer generates **millions** of inputs automatically, guided by code coverage: when an input reaches new code, the fuzzer mutates it further. It is very good at finding the cases nobody thought of: empty input, huge input, invalid UTF-8, a dangling backslash, a length prefix that lies.

Since Go 1.18, fuzzing is built into `go test`.

## A fuzz target

Code to fuzz:



Source: `examples/m09/fuzzing/escape.go`

```go
// Quote wraps s in double quotes, escaping backslashes and quotes.
func Quote(s string) string {
	var b strings.Builder
	b.WriteByte('"')
	for i := 0; i < len(s); i++ {
		switch s[i] {
		case '"', '\\':
			b.WriteByte('\\')
		}
		b.WriteByte(s[i])
	}
	b.WriteByte('"')
	return b.String()
}

var ErrSyntax = errors.New("invalid quoted string")

// Unquote reverses Quote.
func Unquote(q string) (string, error) {
	if len(q) < 2 || q[0] != '"' || q[len(q)-1] != '"' {
		return "", ErrSyntax
	}
	var b strings.Builder
	body := q[1 : len(q)-1]
	for i := 0; i < len(body); i++ {
		c := body[i]
		if c == '\\' {
			i++
			if i == len(body) {
				return "", ErrSyntax // dangling backslash
			}
			c = body[i]
		} else if c == '"' {
			return "", ErrSyntax // unescaped quote inside
		}
		b.WriteByte(c)
	}
	return b.String(), nil
}
```



Fuzz targets:



Source: `examples/m09/fuzzing/escape_test.go`

```go
// FuzzRoundTrip checks a property that must hold for EVERY input:
// unquoting a quoted string gives back the original.
//
//	go test -fuzz=FuzzRoundTrip -fuzztime=30s ./examples/m09/fuzzing
//
// Without -fuzz, plain `go test` runs only the seed corpus below (and
// any saved failures in testdata/fuzz), so it is fast enough for CI.
func FuzzRoundTrip(f *testing.F) {
	for _, seed := range []string{"", "plain", `with "quotes"`, `back\slash`, "unicode é 世界"} {
		f.Add(seed)
	}
	f.Fuzz(func(t *testing.T, s string) {
		q := Quote(s)
		got, err := Unquote(q)
		if err != nil {
			t.Fatalf("Unquote(Quote(%q)) error: %v", s, err)
		}
		if got != s {
			t.Fatalf("round trip changed %q into %q", s, got)
		}
	})
}

// FuzzUnquoteNoPanic only checks that arbitrary input never panics.
func FuzzUnquoteNoPanic(f *testing.F) {
	f.Add(`"ok"`)
	f.Add(`"\`)
	f.Fuzz(func(t *testing.T, q string) {
		Unquote(q) // errors are fine; panics are not
	})
}
```

Local command:

```sh
go test -run xxx -fuzz=FuzzRoundTrip -fuzztime=10s ./examples/m09/fuzzing
```



- A fuzz target is `func FuzzXxx(f *testing.F)` in a test file.
- `f.Add(...)` adds **seed** inputs. They should be representative valid inputs.
- `f.Fuzz(func(t *testing.T, args...))` is called with each generated input. Argument types can be `[]byte`, `string`, integers, floats, `bool` and `rune`.

## What to check

The hard part of fuzzing is not generating inputs but deciding what is **wrong** for an arbitrary input. Useful properties:

| Property | Example |
|---|---|
| **No panics, no hangs** on any input | parsers, decoders, protocol readers |
| **Round trip** | `Unquote(Quote(s)) == s`, `Decode(Encode(x)) == x` |
| **Agreement with a reference** | a fast implementation matches a slow, obviously correct one |
| **Invariants** | output is always valid UTF-8, sorted, within bounds |
| **Idempotence** | `Normalize(Normalize(s)) == Normalize(s)` |

The mini Redis RESP parser (lesson 8.8) has a "no panics" fuzz target, and the exercise below uses round trips.

## Running the fuzzer

```bash
go test ./examples/m09/fuzzing                              # seeds only: fast, runs in CI
go test -run xxx -fuzz=FuzzRoundTrip ./examples/m09/fuzzing  # fuzz until a failure or Ctrl+C
go test -run xxx -fuzz=FuzzRoundTrip -fuzztime=30s ./...     # fuzz for a fixed time
```

- Without `-fuzz`, fuzz targets run like normal tests over the seed corpus, so they cost almost nothing in CI.
- With `-fuzz`, one target runs for as long as you allow, on all CPU cores. `-run xxx` skips the regular tests.
- Inputs that found new code paths are cached in your Go build cache, so later fuzzing sessions start where you left off.

## When the fuzzer finds a bug

The failing input is written to `testdata/fuzz/FuzzXxx/<hash>` in the package directory, and from then on **plain `go test` runs it** as a regression test. The workflow:

1. Fuzz, get a failure.
2. Commit the new `testdata/fuzz` file.
3. Fix the code; `go test` now passes and keeps passing.

## Fuzzing in CI

Run seed corpora in every CI build (they are just tests). Run actual fuzzing on a schedule, for example nightly for a few minutes per target, or continuously with a service like OSS-Fuzz, which supports native Go fuzzing.

## Common mistakes

### Fuzzing without a property

A target that only calls the function catches panics, which is useful, but most bugs produce wrong output rather than panics. Add a property.

### Non-deterministic targets

A target that depends on time, randomness or global state produces failures the fuzzer cannot reproduce.

### Slow targets

The fuzzer's power comes from speed. Avoid network calls and big allocations inside the target.

## Exercise



## Exercise: 9.6 Fuzzing

Implement a run-length `Encode` and `Decode`. The tests include two fuzz targets: a round-trip property and a "never panic, and anything accepted re-encodes consistently" property. After the unit tests pass, run `go test -fuzz=FuzzRoundTrip -fuzztime=20s ./m09/rle` and see whether the fuzzer can break your code (runs longer than 255 are a common trap).

### Starter

```go
//go:build !solution

// Package rle practices fuzzing with a run-length encoder. The tests
// include a fuzz test; run it with:
//
//	go test -fuzz=FuzzRoundTrip -fuzztime=20s ./m09/rle
package rle

import "errors"

// ErrCorrupt is returned by Decode for invalid input.
var ErrCorrupt = errors.New("rle: corrupt data")

// Encode compresses data as pairs of bytes: (count, value), where count
// is 1 to 255. A run longer than 255 is split into several pairs.
//
//	Encode([]byte("aaab")) == []byte{3, 'a', 1, 'b'}
//
// Encode(nil) and Encode([]byte{}) return an empty (or nil) slice.
func Encode(data []byte) []byte {
	// TODO: implement me.
	return nil
}

// Decode reverses Encode. It returns ErrCorrupt if the input has an odd
// length or contains a pair with count 0.
func Decode(enc []byte) ([]byte, error) {
	// TODO: implement me.
	return nil, nil
}
```

```sh
cd exercises
go test ./m09/rle/
```

### Reference solution — try the exercise first

```go
//go:build solution

// Package rle practices fuzzing with a run-length encoder.
package rle

import "errors"

// ErrCorrupt is returned by Decode for invalid input.
var ErrCorrupt = errors.New("rle: corrupt data")

// Encode compresses data as (count, value) byte pairs.
func Encode(data []byte) []byte {
	var out []byte
	for i := 0; i < len(data); {
		v := data[i]
		n := 1
		for i+n < len(data) && data[i+n] == v && n < 255 {
			n++
		}
		out = append(out, byte(n), v)
		i += n
	}
	return out
}

// Decode reverses Encode.
func Decode(enc []byte) ([]byte, error) {
	if len(enc)%2 != 0 {
		return nil, ErrCorrupt
	}
	var out []byte
	for i := 0; i < len(enc); i += 2 {
		n, v := int(enc[i]), enc[i+1]
		if n == 0 {
			return nil, ErrCorrupt
		}
		for range n {
			out = append(out, v)
		}
	}
	return out, nil
}
```

```sh
go test -tags solution ./m09/rle/
```



## Key takeaways

- Fuzzing generates inputs automatically, guided by coverage, and finds the cases you did not think of.
- Write `FuzzXxx(f *testing.F)` with seeds from `f.Add` and a property in `f.Fuzz`.
- Good properties: no panics, round trips, agreement with a reference, invariants.
- Plain `go test` runs seeds and saved failures; `go test -fuzz` explores.
- Commit failing inputs from `testdata/fuzz` as regression tests.

## Further reading

- [Go Fuzzing](https://go.dev/doc/security/fuzz/) on go.dev
- [Tutorial: Getting started with fuzzing](https://go.dev/doc/tutorial/fuzz)
