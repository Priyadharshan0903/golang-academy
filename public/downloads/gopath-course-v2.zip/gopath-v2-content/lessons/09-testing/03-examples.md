# 9.3 Testable examples

Write Example functions that are both documentation on pkg.go.dev and tests run by go test, with naming rules, Output and Unordered output.

## What you will learn

- How `Example` functions become documentation and tests at the same time
- The naming rules that attach examples to packages, types and methods
- `// Output:` and `// Unordered output:`
- When an example is better than a unit test, and when it is not

## The idea

You have been reading testable examples since lesson 1.3: every example in this course is one. An `Example` function in a `_test.go` file is:

1. **Compiled and run by `go test`**, with its standard output compared to the `// Output:` comment.
2. **Shown in the documentation**, by `go doc` and on [pkg.go.dev](https://pkg.go.dev), next to whatever it documents.

So examples are documentation that cannot go out of date.

## Naming



Source: `examples/m09/examplesdoc/example_test.go`

```go
// Example is the package example: shown at the top of the package docs.
func Example() {
	var s examplesdoc.Stack
	s.Push("a")
	s.Push("b")
	v, _ := s.Pop()
	fmt.Println(v, s.Len())
	// Output: b 1
}

// ExampleStack documents the type Stack.
func ExampleStack() {
	var s examplesdoc.Stack
	fmt.Println(s.Len())
	// Output: 0
}

// ExampleStack_Pop documents the method Stack.Pop.
func ExampleStack_Pop() {
	var s examplesdoc.Stack
	_, ok := s.Pop()
	fmt.Println(ok)
	// Output: false
}

// ExampleStack_Pop_order is a second example for Pop; the suffix
// after the method name starts with a lowercase letter.
func ExampleStack_Pop_order() {
	var s examplesdoc.Stack
	for _, v := range []string{"x", "y", "z"} {
		s.Push(v)
	}
	for s.Len() > 0 {
		v, _ := s.Pop()
		fmt.Print(v)
	}
	fmt.Println()
	// Output: zyx
}
```

Local command:

```sh
go test -v ./examples/m09/examplesdoc
```



| Function name | Documents |
|---|---|
| `Example` | the package |
| `ExampleF` | the function `F` |
| `ExampleT` | the type `T` |
| `ExampleT_M` | the method `M` on type `T` |
| any of the above plus `_suffix` | an additional example; the suffix starts with a lowercase letter |

Examples are usually written in the external test package (`package examplesdoc_test`), so they show the API exactly as users call it, with the package name in front.

## Output checks

- `// Output:` followed by the expected lines. Leading and trailing whitespace of the whole output is trimmed before comparing (which is why trailing spaces inside lines bit us in earlier modules).
- `// Unordered output:` compares lines in any order, for output from maps or goroutines:



Source: `examples/m09/examplesdoc/example_test.go`

```go
func Example_unordered() {
	set := map[string]bool{"go": true, "rust": true, "zig": true}
	for k := range maps.Keys(set) { // random order
		fmt.Println(k)
	}
	// Unordered output:
	// rust
	// go
	// zig
}
```

Local command:

```sh
go test -v -run Example_unordered ./examples/m09/examplesdoc
```



- An example **without** an output comment is compiled but not run. That is useful for examples that need a network or print something machine-dependent, though they then only prove the code compiles.

## Examples or unit tests?

Use examples for **showing how to use an API**: the common path, written the way you want users to write it. Use unit tests for **edge cases, error paths and exhaustive tables**. An example with twenty asserts is a bad example; a test without readable usage is a bad tutorial. Most good packages have both.

## Common mistakes

### Machine-dependent output

Printing times, map iteration, pointers or goroutine timing makes examples flaky. Sort, round or use `Unordered output`.

### Wrong names

`ExampleStack_pop` (lowercase method name) does not attach to the `Pop` method, and `go vet` warns about examples that refer to unknown identifiers.

### Examples that hide errors

`v, _ := parse(...)` teaches readers to ignore errors. Show proper handling, even in examples.

## Key takeaways

- `Example` functions are run by `go test` and shown in the documentation.
- Names attach them to the package, functions, types and methods; suffixes add more examples.
- `// Output:` checks output exactly; `// Unordered output:` ignores order.
- Use examples to teach the API and unit tests to cover the edge cases.

## Further reading

- [Testable Examples in Go](https://go.dev/blog/examples) on the Go blog
- [Package testing: Examples](https://pkg.go.dev/testing#hdr-Examples)
