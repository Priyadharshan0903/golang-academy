# 9. Testing in depth

Testing is built into Go: `go test`, the `testing` package and a handful of conventions cover almost everything, with no framework to install. This module goes from the basics you have already used to fuzzing, benchmarks and deterministic concurrency tests.

**Time:** about 4 hours, plus exercises. One exercise turns things around: you write the tests, and the repository checks whether they catch deliberately planted bugs.

- [9.1 Table-driven tests and subtests](01-table-driven.md)
- [9.2 Test helpers, t.Cleanup, t.Context and golden files](02-helpers.md)
- [9.3 Testable examples](03-examples.md)
- [9.4 Mocks, fakes and interfaces for testing](04-fakes.md)
- [9.5 httptest](05-httptest.md)
- [9.6 Fuzzing](06-fuzzing.md)
- [9.7 Benchmarks with b.Loop](07-benchmarks.md)
- [9.8 Coverage and integration tests](08-coverage.md)
- [9.9 Testing concurrent code with testing/synctest](09-synctest.md)
