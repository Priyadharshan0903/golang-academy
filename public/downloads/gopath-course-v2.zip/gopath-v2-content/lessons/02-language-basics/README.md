# 2. Language basics

This module covers the core of the language. You already know what a variable or a loop is, so the focus is on **how Go does it differently**, and on the gotchas that bite developers coming from other languages.

**Time:** about 3 hours, plus exercises.

- [2.1 Variables, zero values and short declarations](01-variables.md)
- [2.2 Basic types, numeric conversions and overflow](02-basic-types.md)
- [2.3 Constants and iota](03-constants-and-iota.md)
- [2.4 Strings, bytes, runes and UTF-8](04-strings-bytes-runes.md)
- [2.5 Control flow: if, for, switch and labels](05-control-flow.md)
- [2.6 Functions: multiple returns, variadics and closures](06-functions.md)
- [2.7 defer, and how it is evaluated](07-defer.md)
- [2.8 Pointers without fear](08-pointers.md)
- [2.9 Scope and shadowing gotchas](09-scope-and-shadowing.md)
