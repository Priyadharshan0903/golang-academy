# 2.5 Control flow: if, for, switch and labels

Go's small set of control structures: if with init statements, the one loop keyword, switch without fallthrough, and labeled break and continue.

## What you will learn

- How `if` works, including the init statement idiom
- The forms of Go's only loop, `for`, including range over integers
- How `switch` differs from C and Java
- How to break out of nested loops with labels
- The `break` inside `switch` trap

## The idea

Go has very few control structures: `if`, `for`, `switch` (plus `select` for channels in Module 6, and `goto`, which you will almost never use). There is no `while`, no `do while`, no ternary `?:` operator, and no `foreach` keyword. Each of the few that exist is flexible enough to cover those cases.

Two syntax rules apply to all of them:

- **No parentheses** around conditions: `if x > 0 {`, not `if (x > 0) {`.
- **Braces are mandatory**, even for one-line bodies. There is no `if x > 0 return`.

## `if`, with an init statement

`if` can start with a short statement, separated by a semicolon. Variables declared there are scoped to the `if` and all its `else` branches:



Source: `examples/m02/controlflow/controlflow_test.go`

```go
func Example_ifWithInit() {
	// The init statement's variables exist only inside the if/else.
	if n, err := strconv.Atoi("42"); err != nil {
		fmt.Println("not a number:", err)
	} else if n > 40 {
		fmt.Println("big:", n)
	} else {
		fmt.Println("small:", n)
	}

	// Output:
	// big: 42
}
```

Local command:

```sh
go test -run Example_ifWithInit -v ./examples/m02/controlflow
```



You will see this pattern constantly with errors:

```go
if err := save(user); err != nil {
	return err
}
```

`err` exists only where it is needed, which keeps the surrounding function free of stale variables.

### No ternary operator

Go deliberately has no `cond ? a : b`. Write it out:

```go
label := "off"
if enabled {
	label = "on"
}
```

It is two extra lines, and nested ternaries are impossible.

## `for`: the only loop



Source: `examples/m02/controlflow/controlflow_test.go`

```go
func Example_forLoops() {
	// 1. Classic three-part loop.
	for i := 0; i < 3; i++ {
		fmt.Println("classic", i)
	}

	// 2. Condition only: Go's "while".
	n := 1
	for n < 100 {
		n *= 3
	}
	fmt.Println(n)

	// 3. Range over an integer (Go 1.22+): i goes 0, 1.
	for i := range 2 {
		fmt.Println("range int", i)
	}

	// 4. Range over a slice gives index and value.
	for i, name := range []string{"ana", "bo"} {
		fmt.Println(i, name)
	}

	// 5. Infinite loop with break.
	tries := 0
	for {
		tries++
		if tries == 3 {
			break
		}
	}
	fmt.Println("tries:", tries)

	// Output:
	// classic 0
	// classic 1
	// classic 2
	// 243
	// range int 0
	// range int 1
	// 0 ana
	// 1 bo
	// tries: 3
}
```

Local command:

```sh
go test -run Example_forLoops -v ./examples/m02/controlflow
```



| Form | Equivalent in other languages |
|---|---|
| `for i := 0; i < n; i++ { }` | C-style `for` |
| `for cond { }` | `while (cond)` |
| `for { }` | `while (true)` |
| `for i := range n { }` | `for i in range(n)` (Go 1.22+) |
| `for i, v := range slice { }` | `foreach` / `enumerate` |
| `for k, v := range m { }` | iterate a map (lesson 3.5) |
| `for r := range ch { }` | read a channel until closed (Module 6) |

With `range`, drop what you do not need: `for i := range s` for indexes only, `for _, v := range s` for values only.

Two details about `range`:

- The value is a **copy** of the element. Assigning to `v` does not change the slice. Use the index (`s[i] = ...`) to modify elements.
- **Map iteration order is random** and changes between runs on purpose. Never rely on it.

Since Go 1.22, each loop iteration gets **fresh** loop variables. This fixed a famous bug with closures and goroutines capturing the loop variable, which you will see in lesson 2.6. Old blog posts that warn about it describe behavior before Go 1.22.

## `switch`



Source: `examples/m02/controlflow/controlflow_test.go`

```go
func describe(code int) string {
	switch code {
	case 200, 201, 204: // several values in one case
		return "success"
	case 301, 302:
		return "redirect"
	case 404:
		return "not found"
	default:
		return "other"
	}
	// No break needed: Go never falls through unless you say so.
}

func grade(score int) string {
	switch { // no expression: same as "switch true"
	case score >= 90:
		return "A"
	case score >= 75:
		return "B"
	default:
		return "C"
	}
}

func Example_switch() {
	fmt.Println(describe(204), describe(302), describe(500))
	fmt.Println(grade(95), grade(80), grade(10))

	// Output:
	// success redirect other
	// A B C
}
```

Local command:

```sh
go test -run Example_switch -v ./examples/m02/controlflow
```



Differences from C, Java and JavaScript:

- **No automatic fallthrough.** Each case ends on its own, so no `break` is needed.
- **A case can list several values**: `case 200, 201, 204:`.
- **Cases do not have to be constants.** They can be any expression, evaluated top to bottom.
- **A switch with no expression** is a clean replacement for long `if / else if` chains, as in `grade` above.
- Like `if`, a `switch` can have an init statement: `switch n := compute(); n { ... }`.

If you really want to continue into the next case, say so with `fallthrough`. It is rare:



Source: `examples/m02/controlflow/controlflow_test.go`

```go
func Example_fallthrough() {
	switch n := 1; n {
	case 1:
		fmt.Println("one")
		fallthrough // run the next case body, without checking it
	case 2:
		fmt.Println("two")
	case 3:
		fmt.Println("three")
	}

	// Output:
	// one
	// two
}
```

Local command:

```sh
go test -run Example_fallthrough -v ./examples/m02/controlflow
```



`fallthrough` runs the next case's body **without** checking its condition. There is also a **type switch** for checking the dynamic type of an interface value, covered in lesson 4.3.

## Labels: breaking out of nested loops

`break` and `continue` apply to the innermost loop. To affect an outer loop, put a **label** on it:



Source: `examples/m02/controlflow/controlflow_test.go`

```go
func Example_labels() {
	grid := [][]int{
		{1, 2, 3},
		{4, -1, 6},
		{7, 8, 9},
	}

search:
	for r, row := range grid {
		for c, v := range row {
			if v < 0 {
				fmt.Printf("negative at row %d, col %d\n", r, c)
				break search // leaves BOTH loops
			}
		}
	}

	// Output:
	// negative at row 1, col 1
}
```

Local command:

```sh
go test -run Example_labels -v ./examples/m02/controlflow
```



`continue outer` works the same way, skipping to the next iteration of the labeled loop.

## The `break` inside `switch` trap

Inside a `switch` (or `select`), a plain `break` exits the **switch**, not the surrounding loop. This surprises almost everyone once:



Source: `examples/m02/controlflow/controlflow_test.go`

```go
func Example_breakInsideSwitch() {
	// break inside a switch only leaves the switch, not the loop.
	for i := range 5 {
		switch i {
		case 2:
			break // ends the switch; the loop keeps going
		}
		fmt.Println("unlabeled", i)
		if i == 2 {
			break // this one is outside the switch: it ends the loop
		}
	}

loop:
	for i := range 5 {
		switch i {
		case 1:
			break loop // a label makes break leave the loop
		}
		fmt.Println("labeled", i)
	}

	// Output:
	// unlabeled 0
	// unlabeled 1
	// unlabeled 2
	// labeled 0
}
```

Local command:

```sh
go test -run Example_breakInsideSwitch -v ./examples/m02/controlflow
```



When you need to leave a loop from inside a `switch` or `select`, use a labeled `break`. You will need this often with `select` in concurrent code.

## Common mistakes

### Modifying the range value instead of the element

```go
for _, p := range players {
	p.Score = 0 // changes a copy; players is untouched
}
```

Use `for i := range players { players[i].Score = 0 }`.

### Relying on map iteration order

Tests that pass locally and fail in CI often do so because of map order. Sort the keys first (`slices.Sorted(maps.Keys(m))`, lesson 3.4) when order matters.

### Plain `break` inside `switch` or `select` in a loop

It only leaves the switch. Use a label.

### Adding `break` at the end of every case

Harmless but noisy, and a sign of C or Java habits. Go cases end on their own.

## Key takeaways

- No parentheses, mandatory braces, no ternary operator.
- `if` and `switch` can take an init statement that scopes variables tightly.
- `for` is the only loop and covers C-style, while, infinite and range loops, including `range n` since Go 1.22.
- `switch` cases do not fall through, can list several values, and a bare `switch` replaces `if / else if` chains.
- Use labels to `break` or `continue` an outer loop, especially from inside `switch` or `select`.

## Further reading

- [Effective Go: Control structures](https://go.dev/doc/effective_go#control-structures)
- [For statements](https://go.dev/ref/spec#For_statements) and [Switch statements](https://go.dev/ref/spec#Switch_statements) in the spec
- [Fixing for loops in Go 1.22](https://go.dev/blog/loopvar-preview) on the Go blog
- [Range over integers](https://go.dev/doc/go1.22#language) in the Go 1.22 release notes
