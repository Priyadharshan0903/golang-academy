# 2.7 defer, and how it is evaluated

How defer schedules cleanup, the exact moment its arguments are evaluated, how it interacts with named results and panics, and the traps of defer in loops.

## What you will learn

- What `defer` does and the order deferred calls run in
- Exactly **when** the arguments of a deferred call are evaluated
- The standard acquire, check, defer release pattern
- How deferred functions can change named results
- The traps: `defer` in loops, ignored `Close` errors and `os.Exit`

## The idea

`defer` schedules a function call to run **when the surrounding function returns**, however it returns: a normal `return`, falling off the end, or a panic. It is Go's answer to `try / finally`, `using` blocks and destructors.

The big benefit is locality. You write the cleanup right next to the thing being cleaned up, instead of at every return statement.

## Order: last in, first out

Deferred calls are pushed onto a stack. They run in **reverse** order:



Source: `examples/m02/deferring/deferring_test.go`

```go
func Example_order() {
	fmt.Println("start")
	defer fmt.Println("deferred 1")
	defer fmt.Println("deferred 2") // runs first: last in, first out
	fmt.Println("end")

	// Output:
	// start
	// end
	// deferred 2
	// deferred 1
}
```

Local command:

```sh
go test -run Example_order -v ./examples/m02/deferring
```



Reverse order is exactly what you want for cleanup: resources acquired later are released first, like closing a file before releasing the lock that protected it.

## When arguments are evaluated

This is the rule that trips people up. A deferred call's **function value and arguments are evaluated immediately**, at the `defer` statement. Only the call itself is delayed:



Source: `examples/m02/deferring/deferring_test.go`

```go
func Example_argumentsEvaluatedEarly() {
	x := 1
	defer fmt.Println("deferred sees x =", x) // x is evaluated NOW
	x = 2
	fmt.Println("x is now", x)

	// Output:
	// x is now 2
	// deferred sees x = 1
}
```

Local command:

```sh
go test -run Example_argumentsEvaluatedEarly -v ./examples/m02/deferring
```



If you want the deferred code to see the **latest** value, defer a closure. The closure captures the variable and reads it when it runs:



Source: `examples/m02/deferring/deferring_test.go`

```go
func Example_closureSeesLatest() {
	x := 1
	defer func() { fmt.Println("closure sees x =", x) }() // reads x later
	x = 2

	// Output:
	// closure sees x = 2
}
```

Local command:

```sh
go test -run Example_closureSeesLatest -v ./examples/m02/deferring
```



## The standard cleanup pattern

Acquire the resource, check the error, then defer the release **immediately**:



Source: `examples/m02/deferring/deferring_test.go`

```go
// firstLine shows the standard pattern: acquire, check the error,
// then defer the release right away.
func firstLine(path string) (string, error) {
	f, err := os.Open(path)
	if err != nil {
		return "", err
	}
	defer f.Close() // runs on every return path below

	buf := make([]byte, 64)
	n, err := f.Read(buf)
	if err != nil {
		return "", err
	}
	for i, b := range buf[:n] {
		if b == '\n' {
			return string(buf[:i]), nil
		}
	}
	return string(buf[:n]), nil
}

func Example_cleanup() {
	dir, _ := os.MkdirTemp("", "defer-example")
	defer os.RemoveAll(dir)

	path := filepath.Join(dir, "notes.txt")
	_ = os.WriteFile(path, []byte("hello\nworld\n"), 0o644)

	line, err := firstLine(path)
	fmt.Println(line, err)

	_, err = firstLine(filepath.Join(dir, "missing.txt"))
	fmt.Println(errors.Is(err, os.ErrNotExist))

	// Output:
	// hello <nil>
	// true
}
```

Local command:

```sh
go test -run Example_cleanup -v ./examples/m02/deferring
```



The order matters. If you write `defer f.Close()` **before** checking `err`, then on failure `f` is `nil` and the deferred `Close` runs on a nil file.

You will use the same shape everywhere:

```go
mu.Lock()
defer mu.Unlock()

resp, err := http.Get(url)
if err != nil {
	return err
}
defer resp.Body.Close()
```

## Changing results from a defer

A deferred **closure** can read and modify the function's **named** results, because they are ordinary variables that are still in scope. The deferred code runs after the `return` statement has set them, but before the caller sees them:



Source: `examples/m02/deferring/deferring_test.go`

```go
// safeDivide turns a panic into an error by changing the named
// result from a deferred function. Panics are covered in Module 5.
func safeDivide(a, b int) (result int, err error) {
	defer func() {
		if r := recover(); r != nil {
			err = fmt.Errorf("recovered: %v", r)
		}
	}()
	return a / b, nil
}

func Example_modifyNamedResult() {
	fmt.Println(safeDivide(10, 2))
	fmt.Println(safeDivide(1, 0))

	// Output:
	// 5 <nil>
	// 0 recovered: runtime error: integer divide by zero
}
```

Local command:

```sh
go test -run Example_modifyNamedResult -v ./examples/m02/deferring
```



The example uses `recover` to turn a panic into an error. Panics and `recover` are covered properly in Module 5; the point here is the mechanism: **deferred functions run even when the function panics**, and they can adjust named results.

A gentler, very common use is adding context to any error a function returns:

```go
func process(path string) (err error) {
	defer func() {
		if err != nil {
			err = fmt.Errorf("process %s: %w", path, err)
		}
	}()
	// ... many return statements, all wrapped automatically
}
```

## Cost

`defer` used to have a noticeable overhead, which led to advice to avoid it in hot paths. Since Go 1.14, most defers are compiled inline ("open-coded defers") and cost close to nothing. Use `defer` for correctness by default, and only remove one if a profile (Module 10) shows it matters.

## Common mistakes

### `defer` inside a loop

```go
for _, path := range paths {
	f, err := os.Open(path)
	if err != nil {
		return err
	}
	defer f.Close() // nothing closes until the WHOLE function returns
	// ...
}
```

With thousands of files, you run out of file descriptors. Move the loop body into its own function, so each `defer` runs at the end of each iteration:

```go
for _, path := range paths {
	if err := processFile(path); err != nil { // processFile defers its own Close
		return err
	}
}
```

### Ignoring the error from `Close` on a file you wrote

For files opened for **reading**, ignoring `Close` errors is fine. For files you **wrote**, `Close` (or `Sync`) can be the moment you learn the data did not reach the disk. Return that error, for example with the named result pattern above:

```go
defer func() {
	if cerr := f.Close(); cerr != nil && err == nil {
		err = cerr
	}
}()
```

### Expecting defers to run on `os.Exit`

`os.Exit` ends the program immediately. **Deferred calls do not run**, and neither does any other cleanup. The same applies to `log.Fatal`, which calls `os.Exit`. This is one reason the checkpoint project in Module 1 kept all logic in `run()` and called `os.Exit` only in `main`.

### Deferring before the error check

`defer f.Close()` before `if err != nil` defers a call on a nil value. Always check first.

## Key takeaways

- `defer` runs a call when the surrounding function returns, including on panic.
- Deferred calls run in last in, first out order.
- Arguments are evaluated at the `defer` statement; use a closure to see later values.
- Pattern: acquire, check the error, `defer` the release on the next line.
- Deferred closures can modify named results, which is useful for wrapping errors.
- Avoid `defer` in loops, handle `Close` errors for written files, and remember that `os.Exit` skips defers.

## Further reading

- [Defer, Panic, and Recover](https://go.dev/blog/defer-panic-and-recover) on the Go blog
- [Defer statements](https://go.dev/ref/spec#Defer_statements) in the spec
- [Effective Go: Defer](https://go.dev/doc/effective_go#defer)
