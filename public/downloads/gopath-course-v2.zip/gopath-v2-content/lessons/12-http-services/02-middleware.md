# 12.2 Middleware

Write HTTP middleware as plain functions: chaining and ordering, capturing the status code safely, request IDs through the context, structured access logs, and panic recovery.

## What you will learn

- What middleware is in Go: a function from `http.Handler` to `http.Handler`
- How to chain middleware, and why the order matters
- How to capture the response status without breaking `Flush` and friends
- Request IDs carried through `context.Context`
- Access logs with `log/slog`, and turning panics into 500 responses

## The idea

Some behavior applies to every request: logging, metrics, authentication, request IDs, panic recovery. Instead of repeating it in each handler, you **wrap** the handler. In Go, middleware is just this:



Source: `examples/m12/middleware/middleware.go`

```go
// A Middleware wraps a handler with extra behavior.
type Middleware func(http.Handler) http.Handler

// Chain wraps h with mws. The first middleware is the outermost: it
// sees the request first and the response last.
func Chain(h http.Handler, mws ...Middleware) http.Handler {
	for i := len(mws) - 1; i >= 0; i-- {
		h = mws[i](h)
	}
	return h
}
```



A middleware takes the next handler and returns a new handler that does something before and/or after calling it. No framework, no registration: plain functions.

## Order matters



Source: `examples/m12/middleware/middleware_test.go`

```go
func trace(name string) Middleware {
	return func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			fmt.Println("enter", name)
			next.ServeHTTP(w, r)
			fmt.Println("leave", name)
		})
	}
}

func ExampleChain() {
	h := Chain(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		fmt.Println("handler")
	}), trace("A"), trace("B"))

	h.ServeHTTP(httptest.NewRecorder(), httptest.NewRequest("GET", "/", nil))
	// Output:
	// enter A
	// enter B
	// handler
	// leave B
	// leave A
}
```

Local command:

```sh
go test -run ExampleChain -v ./examples/m12/middleware
```



Middleware nests like function calls: `Chain(h, A, B)` is `A(B(h))`. The request passes through A, then B, then the handler; the response passes back through B, then A. Decide the order by asking what each middleware needs to see:

- **Request ID** goes outermost, so everything inside can log the ID.
- **Logging** must see the final status code, including the 500 produced when a handler panics, so it goes **outside** panic recovery.
- **Recovery** goes close to the handlers, so it catches their panics and writes a response the outer layers can observe.
- **Authentication** and **rate limiting** go before the expensive work, often only on some routes.

## Capturing the status code

`http.ResponseWriter` does not tell you which status a handler wrote. To log it, wrap the writer:



Source: `examples/m12/middleware/middleware.go`

```go
// statusRecorder remembers the status code a handler writes.
type statusRecorder struct {
	http.ResponseWriter
	status int
	bytes  int
}

func (r *statusRecorder) WriteHeader(code int) {
	if r.status == 0 {
		r.status = code
	}
	r.ResponseWriter.WriteHeader(code)
}

func (r *statusRecorder) Write(b []byte) (int, error) {
	if r.status == 0 {
		r.status = http.StatusOK // Write without WriteHeader means 200
	}
	n, err := r.ResponseWriter.Write(b)
	r.bytes += n
	return n, err
}

// Unwrap lets http.ResponseController reach the original writer, so
// handlers can still flush or set deadlines through the wrapper.
func (r *statusRecorder) Unwrap() http.ResponseWriter { return r.ResponseWriter }
```



Three details make this wrapper correct:

- If a handler calls `Write` without `WriteHeader`, the status is **200**. The wrapper records that.
- Only the **first** `WriteHeader` counts, like in net/http (a second call is ignored, with a log message).
- **`Unwrap`**. Handlers sometimes need features of the underlying writer: flushing a streaming response, setting per-request deadlines, hijacking for WebSockets. The modern way is `http.NewResponseController(w)`, which calls `Unwrap` to find the original writer through any number of wrappers. Without `Unwrap`, your middleware would silently break streaming. The test `TestResponseControllerThroughRecorder` proves it works.

## Request IDs and the context

A request ID ties together every log line about one request, across services. The middleware reuses a sane incoming `X-Request-ID` (set by a load balancer or calling service) or creates one, and stores it in the request's **context** (lesson 7.1):



Source: `examples/m12/middleware/middleware.go`

```go
type requestIDKey struct{}

// RequestID gives every request an ID: the incoming X-Request-ID
// header if it looks sane, or a new random one. The ID is stored in
// the request context and echoed in the response.
func RequestID(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		id := r.Header.Get("X-Request-ID")
		if !validID(id) {
			var b [8]byte
			rand.Read(b[:])
			id = hex.EncodeToString(b[:])
		}
		w.Header().Set("X-Request-ID", id)
		ctx := context.WithValue(r.Context(), requestIDKey{}, id)
		next.ServeHTTP(w, r.WithContext(ctx))
	})
}

// RequestIDFrom returns the request ID stored by RequestID, or "".
func RequestIDFrom(ctx context.Context) string {
	id, _ := ctx.Value(requestIDKey{}).(string)
	return id
}

// validID accepts up to 64 letters, digits and dashes, so a client
// cannot inject newlines or huge values into our logs.
func validID(id string) bool {
	if id == "" || len(id) > 64 {
		return false
	}
	for _, c := range id {
		if !(c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z' || c >= '0' && c <= '9' || c == '-') {
			return false
		}
	}
	return true
}
```



Notes:

- The context key is an unexported type (`requestIDKey{}`), so no other package can collide with it or read it except through `RequestIDFrom`.
- `r.WithContext` returns a **new** request; the middleware passes that one on.
- Incoming IDs are **validated**: a client controls this header, and writing raw client input to logs invites log injection (fake log lines via newlines) and enormous values.
- Request-scoped values like this are what the context's values are for. Do not use the context to pass optional function parameters.

## Access logs with slog



Source: `examples/m12/middleware/middleware.go`

```go
// Logging logs one line per request, after the handler has finished.
func Logging(logger *slog.Logger) Middleware {
	return func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			start := time.Now()
			rec := &statusRecorder{ResponseWriter: w}
			next.ServeHTTP(rec, r)
			logger.LogAttrs(r.Context(), slog.LevelInfo, "request",
				slog.String("method", r.Method),
				slog.String("path", r.URL.Path),
				slog.String("pattern", r.Pattern), // the ServeMux pattern that matched (Go 1.23+)
				slog.Int("status", rec.status),
				slog.Int("bytes", rec.bytes),
				slog.Duration("duration", time.Since(start)),
				slog.String("request_id", RequestIDFrom(r.Context())),
			)
		})
	}
}
```



One structured line per request, written **after** the handler returns, so it has the status and duration. `r.Pattern` (Go 1.23) is the ServeMux pattern that matched, such as `GET /hello/{name}`: much better for grouping than the raw path, which contains IDs. It is set by the ServeMux on the request it receives, so the logging middleware sees it as long as it passes the same `*Request` down; middleware that calls `r.WithContext` creates a new request, and must sit outside logging, as `RequestID` does here. `LogAttrs` with typed attributes avoids allocations in this hot path (lesson 8.4).

## Recovering from panics

`net/http` already recovers panics in handlers: it logs the stack trace and **closes the connection**, so the client sees a network error rather than a response. A recovery middleware does better: it logs through your structured logger, with the request ID, and sends a proper 500.



Source: `examples/m12/middleware/middleware.go`

```go
// Recover turns a panic in a handler into a 500 response and a log
// line with the stack trace, instead of a dropped connection.
func Recover(logger *slog.Logger) Middleware {
	return func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			defer func() {
				v := recover()
				if v == nil {
					return
				}
				if err, ok := v.(error); ok && errors.Is(err, http.ErrAbortHandler) {
					panic(v) // a deliberate abort: let net/http handle it
				}
				logger.Error("panic in handler", "panic", v, "stack", string(debug.Stack()),
					"request_id", RequestIDFrom(r.Context()))
				http.Error(w, "internal server error", http.StatusInternalServerError)
			}()
			next.ServeHTTP(w, r)
		})
	}
}
```



`http.ErrAbortHandler` is a special panic value that handlers use to abort a response deliberately; it is re-panicked so net/http handles it as intended.

Putting it all together, with time and duration removed so the output is stable:



Source: `examples/m12/middleware/middleware_test.go`

```go
// testLogger writes JSON logs without the time and duration, so the
// output is the same on every run.
func testLogger(buf *bytes.Buffer) *slog.Logger {
	return slog.New(slog.NewJSONHandler(buf, &slog.HandlerOptions{
		ReplaceAttr: func(groups []string, a slog.Attr) slog.Attr {
			if a.Key == slog.TimeKey || a.Key == "duration" || a.Key == "stack" {
				return slog.Attr{}
			}
			return a
		},
	}))
}

func ExampleLogging() {
	var logs bytes.Buffer
	mux := http.NewServeMux()
	mux.HandleFunc("GET /hello/{name}", func(w http.ResponseWriter, r *http.Request) {
		fmt.Fprintf(w, "hello, %s\n", r.PathValue("name"))
	})
	mux.HandleFunc("GET /boom", func(w http.ResponseWriter, r *http.Request) {
		panic("something broke")
	})
	h := Chain(mux, RequestID, Logging(testLogger(&logs)), Recover(testLogger(&logs)))

	for _, path := range []string{"/hello/gopher", "/boom"} {
		req := httptest.NewRequest("GET", path, nil)
		req.Header.Set("X-Request-ID", "req-1")
		h.ServeHTTP(httptest.NewRecorder(), req)
	}
	fmt.Print(logs.String())
	// Output:
	// {"level":"INFO","msg":"request","method":"GET","path":"/hello/gopher","pattern":"GET /hello/{name}","status":200,"bytes":14,"request_id":"req-1"}
	// {"level":"ERROR","msg":"panic in handler","panic":"something broke","request_id":"req-1"}
	// {"level":"INFO","msg":"request","method":"GET","path":"/boom","pattern":"GET /boom","status":500,"bytes":22,"request_id":"req-1"}
}
```

Local command:

```sh
go test -run ExampleLogging -v ./examples/m12/middleware
```



The panicking request produces an error log line with the panic value (and, in real use, the stack), then an access log line showing status 500. Both carry the request ID.

## Middleware for specific routes

Middleware does not have to wrap the whole mux. Wrap individual handlers when only some routes need it:

```go
mux.Handle("POST /api/links", rateLimit(http.HandlerFunc(createLink)))
mux.Handle("GET /healthz", http.HandlerFunc(healthz)) // never rate limited
```

The shortener (lesson 12.8) does exactly this.

## Common mistakes

### Wrapping the writer without Unwrap

Streaming, `Flush` and deadlines stop working through your middleware. Add `Unwrap() http.ResponseWriter`.

### Logging inside recovery instead of outside

The access log then misses every panicking request. Order: logging outside, recovery inside.

### Trusting client headers in logs

Validate or sanitize request IDs and anything else from the client before logging it.

### Doing work after writing the response in the handler

The client is already waiting for the connection to finish; heavy work after the response delays it and runs without a deadline. Hand it to a background worker (Module 13).

## Key takeaways

- Middleware is `func(http.Handler) http.Handler`; chain it with plain function calls, first is outermost.
- Order by need: request ID outermost, logging outside recovery, route-specific middleware on individual handlers.
- Wrap `ResponseWriter` to capture the status; record 200 for bare writes and implement `Unwrap`.
- Store request-scoped values like request IDs in the context, with an unexported key type.
- Log with `r.Pattern` for the route, and recover panics into logged 500 responses.

## Further reading

- [Package net/http: ResponseController](https://pkg.go.dev/net/http#ResponseController)
- [Package log/slog](https://pkg.go.dev/log/slog)
