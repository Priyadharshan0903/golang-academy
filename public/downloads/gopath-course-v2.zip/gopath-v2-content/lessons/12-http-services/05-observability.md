# 12.5 Observability: logs, metrics and traces

The three signals of observability for a Go service: structured logs with slog, RED metrics with the Prometheus client, and distributed traces with OpenTelemetry, plus health checks and runtime metrics.

## What you will learn

- The three signals, **logs**, **metrics** and **traces**, and what each is for
- Structured logs that machines can query
- RED metrics with the Prometheus client, and the cardinality trap
- Distributed tracing with OpenTelemetry: spans, context propagation, `traceparent`
- Liveness and readiness endpoints, and runtime metrics

## The three signals

When a service misbehaves in production, you cannot attach a debugger. You can only look at what it emits:

| Signal | Answers | Example |
|---|---|---|
| **Metrics** | Is something wrong? How much, since when? | 2% of `POST /api/links` returned 500 in the last 5 minutes; p99 latency doubled at 14:02 |
| **Logs** | What exactly happened in this case? | `request failed error="connection refused" request_id=a1b2...` |
| **Traces** | Where did the time go across services? | the request spent 1.8 s of its 2 s waiting on the database |

Metrics are cheap aggregates you alert on. Logs are detailed records of events. Traces follow one request through several services. A request ID, or better a **trace ID** present in all three, connects them.

## Logs: structured, one event per line

Lesson 8.4 introduced `log/slog`, and lesson 12.2 built the access log. For production:

- Use the **JSON handler**. Log platforms (Loki, Elasticsearch, CloudWatch) index the fields, so you can query `status >= 500 AND route = "POST /api/links"`.
- Write to **standard output**. In containers, the platform collects stdout; the twelve-factor app never manages log files.
- Log **events**, not narratives: one line per request, one per failure, with fields rather than formatted sentences.
- Choose levels deliberately: `ERROR` for failures someone should look at, `INFO` for normal events like requests and start-up, `DEBUG` for details you turn on temporarily with `LOG_LEVEL=debug`.

## Metrics with Prometheus

**Prometheus** is the standard metrics system in the Kubernetes world. Your service exposes current metric values as text at `/metrics`; Prometheus **scrapes** that endpoint every few seconds and stores the time series.

For a request-driven service, start with the **RED** metrics: **R**ate (requests per second), **E**rrors (failed requests per second), **D**uration (latency distribution). Three metrics cover all of it:



Source: `examples/thirdparty/observability/metrics.go`

```go
// Metrics holds the RED metrics (rate, errors, duration) of an HTTP
// service.
type Metrics struct {
	requests *prometheus.CounterVec
	duration *prometheus.HistogramVec
	inFlight prometheus.Gauge
}

// NewMetrics creates the metrics and registers them with reg.
func NewMetrics(reg prometheus.Registerer) *Metrics {
	m := &Metrics{
		requests: prometheus.NewCounterVec(prometheus.CounterOpts{
			Name: "http_requests_total",
			Help: "HTTP requests by route and status code.",
		}, []string{"route", "code"}),
		duration: prometheus.NewHistogramVec(prometheus.HistogramOpts{
			Name:    "http_request_duration_seconds",
			Help:    "HTTP request latency by route.",
			Buckets: []float64{.005, .01, .025, .05, .1, .25, .5, 1, 2.5},
		}, []string{"route"}),
		inFlight: prometheus.NewGauge(prometheus.GaugeOpts{
			Name: "http_requests_in_flight",
			Help: "HTTP requests currently being served.",
		}),
	}
	reg.MustRegister(m.requests, m.duration, m.inFlight)
	return m
}

// Middleware records every request. It must wrap the ServeMux
// directly, so that r.Pattern is set when the handler returns.
func (m *Metrics) Middleware(mux http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		m.inFlight.Inc()
		defer m.inFlight.Dec()

		start := time.Now()
		rec := &statusRecorder{ResponseWriter: w, status: http.StatusOK}
		mux.ServeHTTP(rec, r)

		// The route pattern, not the path: "/items/{id}" is one time
		// series, while raw paths would create one per item.
		route := r.Pattern
		if route == "" {
			route = "unmatched"
		}
		m.requests.WithLabelValues(route, strconv.Itoa(rec.status)).Inc()
		m.duration.WithLabelValues(route).Observe(time.Since(start).Seconds())
	})
}

type statusRecorder struct {
	http.ResponseWriter
	status int
}

func (r *statusRecorder) WriteHeader(code int) {
	r.status = code
	r.ResponseWriter.WriteHeader(code)
}

func (r *statusRecorder) Unwrap() http.ResponseWriter { return r.ResponseWriter }
```



This example uses the official client library `github.com/prometheus/client_golang`, so it lives in the `examples/thirdparty` module (the main course module has no dependencies). Run `go mod tidy` in `examples/thirdparty` once to download the dependencies. The metric types:

- **Counter**: only goes up (`http_requests_total`). Prometheus computes rates from it: `rate(http_requests_total[5m])`.
- **Gauge**: goes up and down (`http_requests_in_flight`).
- **Histogram**: counts observations in buckets (`http_request_duration_seconds`), from which Prometheus estimates percentiles: `histogram_quantile(0.99, ...)`.

The test scrapes the registry like Prometheus would:



Source: `examples/thirdparty/observability/observability_test.go`

```go
func TestMetrics(t *testing.T) {
	reg := prometheus.NewRegistry()
	h := NewMetrics(reg).Middleware(newMux())
	for _, path := range []string{"/items/1", "/items/2", "/items/3", "/nope"} {
		h.ServeHTTP(httptest.NewRecorder(), httptest.NewRequest("GET", path, nil))
	}

	// Scrape the registry the way Prometheus would.
	rec := httptest.NewRecorder()
	promhttp.HandlerFor(reg, promhttp.HandlerOpts{}).ServeHTTP(rec, httptest.NewRequest("GET", "/metrics", nil))
	out := rec.Body.String()
	for _, want := range []string{
		`http_requests_total{code="200",route="GET /items/{id}"} 3`,
		`http_requests_total{code="404",route="unmatched"} 1`,
		`http_request_duration_seconds_count{route="GET /items/{id}"} 3`,
		`http_requests_in_flight 0`,
	} {
		if !strings.Contains(out, want) {
			t.Errorf("missing %q in:\n%s", want, out)
		}
	}
	for _, line := range strings.Split(out, "\n") {
		if strings.HasPrefix(line, "http_requests_total") || strings.HasPrefix(line, "# TYPE http_requests_total") {
			t.Log(line)
		}
	}
}
```

Local command:

```sh
cd examples/thirdparty && go test -run TestMetrics -v ./observability
```



```text
# TYPE http_requests_total counter
http_requests_total{code="200",route="GET /items/{id}"} 3
http_requests_total{code="404",route="unmatched"} 1
```

### The cardinality trap

Every distinct combination of label values is a separate time series that Prometheus stores. Labelling by the **route pattern** gives a handful of series. Labelling by the **raw path** (`/items/1`, `/items/2`, ...) creates a new series for every ID ever requested, and eventually takes down your monitoring. Never put unbounded values (IDs, user names, raw paths, error messages) in labels. Here `r.Pattern` gives the route for free, and unmatched paths share one label value.

## Traces with OpenTelemetry

A **trace** is the tree of operations performed for one request, possibly across many services. Each operation is a **span**: a name, start and end time, attributes, and a parent. **OpenTelemetry** (OTel) is the vendor-neutral standard for producing traces (and metrics and logs), supported by Jaeger, Grafana Tempo, Honeycomb, Datadog and the cloud providers.

For a trace to cross service boundaries, the caller sends its trace context in the W3C **`traceparent`** header: `00-<trace id>-<parent span id>-<flags>`. The receiving service **extracts** it and creates its spans as children:



Source: `examples/thirdparty/observability/tracing.go`

```go
// Tracing starts a server span for every request. If the caller sent a
// W3C traceparent header, the span joins the caller's trace.
func Tracing(tp trace.TracerProvider, mux http.Handler) http.Handler {
	tracer := tp.Tracer("github.com/Priyadharshan0903/gopath-academy/examples/thirdparty/observability")
	prop := propagation.TraceContext{}

	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		ctx := prop.Extract(r.Context(), propagation.HeaderCarrier(r.Header))
		ctx, span := tracer.Start(ctx, r.Method, trace.WithSpanKind(trace.SpanKindServer))
		defer span.End()

		rec := &statusRecorder{ResponseWriter: w, status: http.StatusOK}
		r = r.WithContext(ctx) // handlers can now start child spans from r.Context()
		mux.ServeHTTP(rec, r)

		// The route is known only after the mux has matched the request,
		// and the mux records it on the request it was given.
		if r.Pattern != "" {
			span.SetName(r.Pattern)
			span.SetAttributes(attribute.String("http.route", r.Pattern))
		}
		span.SetAttributes(
			attribute.String("http.request.method", r.Method),
			attribute.Int("http.response.status_code", rec.status),
		)
		if rec.status >= 500 {
			span.SetStatus(codes.Error, http.StatusText(rec.status))
		}
	})
}
```



The test sends a request with a `traceparent`, as an upstream service would, and inspects the recorded spans:



Source: `examples/thirdparty/observability/observability_test.go`

```go
func TestTracing(t *testing.T) {
	spans := tracetest.NewSpanRecorder()
	tp := sdktrace.NewTracerProvider(sdktrace.WithSpanProcessor(spans))
	defer tp.Shutdown(context.Background())

	h := Tracing(tp, newMux())
	req := httptest.NewRequest("GET", "/items/42", nil)
	// The caller's trace context, as another service would send it.
	req.Header.Set("traceparent", "00-4bf92f3577b34da6a3ce929d0e0e4736-00f067aa0ba902b7-01")
	h.ServeHTTP(httptest.NewRecorder(), req)

	ended := spans.Ended()
	if len(ended) != 2 {
		t.Fatalf("got %d spans, want 2", len(ended))
	}
	child, server := ended[0], ended[1] // the child ends first
	t.Logf("server span %q trace=%s parent=%s attrs=%v", server.Name(), server.SpanContext().TraceID(), server.Parent().SpanID(), server.Attributes())
	t.Logf("child span %q parent=%s", child.Name(), child.Parent().SpanID())

	if server.Name() != "GET /items/{id}" {
		t.Errorf("server span name = %q", server.Name())
	}
	if got := server.SpanContext().TraceID().String(); got != "4bf92f3577b34da6a3ce929d0e0e4736" {
		t.Errorf("trace ID = %s, want the caller's", got)
	}
	if server.Parent().SpanID().String() != "00f067aa0ba902b7" {
		t.Errorf("server span's parent = %s, want the caller's span", server.Parent().SpanID())
	}
	if child.Parent().SpanID() != server.SpanContext().SpanID() {
		t.Error("child span is not a child of the server span")
	}
}
```

Local command:

```sh
cd examples/thirdparty && go test -run TestTracing -v ./observability
```



```text
server span "GET /items/{id}" trace=4bf92f3577b34da6a3ce929d0e0e4736 parent=00f067aa0ba902b7 attrs=[{"http.route":"GET /items/{id}"} {"http.request.method":"GET"} {"http.response.status_code":200}]
child span "load item" parent=c251016ee117c350
```

The server span joined the caller's trace (same trace ID, the caller's span as parent), and the span the handler started from `r.Context()` became its child. That is the whole mechanism: **pass the context**, and spans nest correctly.

In real services:

- The **OTel SDK** is configured once in `main` with an **exporter** that sends spans to a collector (usually OTLP over gRPC or HTTP), and a **sampler** so you do not record every request at high traffic.
- You rarely write the HTTP middleware yourself. The contrib package `go.opentelemetry.io/contrib/instrumentation/net/http/otelhttp` provides server middleware and a client transport that injects `traceparent` into outgoing requests. Most database drivers and RPC libraries have OTel instrumentation too. The middleware in this lesson exists to show what those packages do.
- Use the attribute names from the OTel **semantic conventions** (`http.route`, `http.response.status_code`, as above), available as constants in `go.opentelemetry.io/otel/semconv`, so dashboards work across services.
- Put the trace ID into your log lines, and logs and traces link up.

## Health checks

Orchestrators need to ask two questions, which deserve separate endpoints:

- **Liveness** (`/healthz`): is the process alive, or stuck and in need of a restart? Keep it trivial. Do **not** check dependencies here: if the database is down, restarting every instance of your service makes things worse.
- **Readiness** (`/readyz`): should this instance receive traffic right now? Report not ready during start-up and **during shutdown** (lesson 12.8), and optionally when a critical dependency is unreachable.

Module 15 wires these into Kubernetes probes.

## Runtime metrics

The Prometheus client's Go collector exports the runtime's own metrics (from `runtime/metrics`, lesson 11.1): goroutine count, GC cycles and pause times, heap size, GOMAXPROCS. Register it and you can graph exactly the things Module 11 explained:

```go
reg := prometheus.NewRegistry()
reg.MustRegister(collectors.NewGoCollector(), collectors.NewProcessCollector(collectors.ProcessCollectorOpts{}))
```

A steadily growing `go_goroutines` is a goroutine leak (lesson 7.6); a growing heap after GC is a memory leak; frequent GC cycles point to allocation churn (lesson 10.4).

## Where to expose it

Metrics, pprof (lesson 10.2) and similar endpoints reveal internals. Serve them on a **separate port** (an "admin" port) that is reachable by Prometheus inside the cluster but never routed publicly. The shortener listens on `:8080` for the API and `:9090` for admin.

## Common mistakes

### Unbounded label values

One label with user IDs can create millions of series. Use route patterns and status codes.

### Logging instead of counting

Counting errors by grepping logs is slow and expensive. Emit a metric and alert on it; use logs for the details.

### Liveness checks that test dependencies

A database outage then becomes a restart storm.

### Breaking the context chain

A handler that starts work with `context.Background()` instead of `r.Context()` starts a new, disconnected trace, and loses cancellation too.

## Key takeaways

- Metrics tell you something is wrong, logs tell you what happened, traces tell you where time went.
- Log structured JSON to stdout, one event per line, with a request or trace ID.
- Expose RED metrics with the Prometheus client, labelled by route pattern and status, never by raw path.
- OpenTelemetry traces cross services via the `traceparent` header; pass `r.Context()` and spans nest.
- Separate liveness from readiness, and serve metrics and pprof on an internal admin port.

## Further reading

- [Prometheus: instrumenting a Go application](https://prometheus.io/docs/guides/go-application/)
- [OpenTelemetry Go documentation](https://opentelemetry.io/docs/languages/go/)
- [W3C Trace Context](https://www.w3.org/TR/trace-context/)
