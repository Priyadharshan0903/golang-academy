# 12.7 Exercise: a notes JSON API

Build a small JSON CRUD API from a written specification with ServeMux patterns, correct status codes and headers, checked by table-driven tests.

## The task

The store is written for you: a concurrency-safe, in-memory collection of notes. Your job is the HTTP layer, written to this specification:

| Request | Success | Errors |
|---|---|---|
| `GET /notes` | 200, JSON array of all notes (`[]` when empty) | |
| `POST /notes` with `{"title": "...", "body": "..."}` | 201, the created note, `Location: /notes/{id}` | 400 if the body is not a JSON object, 422 if `title` is empty |
| `GET /notes/{id}` | 200, the note | 400 if `id` is not a number, 404 if it does not exist |
| `DELETE /notes/{id}` | 204, no body | 400, 404 |
| anything else on these paths | | 405 |



## Exercise: 12.7 Exercise: a notes JSON API

Implement `NewHandler` in `starter.go`. The tests check every row of the specification, including headers and the 405 responses.

### Starter

```go
//go:build !solution

package notes

import "net/http"

// NewHandler returns the HTTP API for store:
//
//	GET    /notes       200, a JSON array of all notes ([] when empty)
//	POST   /notes       201, the created note as JSON, and a Location
//	                    header /notes/{id}. 400 if the body is not a
//	                    JSON object, 422 if "title" is empty.
//	GET    /notes/{id}  200 and the note, 404 if it does not exist,
//	                    400 if id is not a number
//	DELETE /notes/{id}  204 with no body, 404 if it does not exist
//
// Successful responses have Content-Type application/json (except 204).
// Other methods must get 405 Method Not Allowed: ServeMux does that for
// you if you put methods in the patterns.
func NewHandler(store *Store) http.Handler {
	mux := http.NewServeMux()
	// TODO: register the four routes.
	return mux
}
```

```sh
cd exercises
go test ./m12/notes/
```

### Reference solution — try the exercise first

```go
//go:build solution

package notes

import (
	"encoding/json"
	"fmt"
	"net/http"
	"strconv"
	"strings"
)

// NewHandler returns the HTTP API for store. See the starter for the
// specification.
func NewHandler(store *Store) http.Handler {
	mux := http.NewServeMux()

	mux.HandleFunc("GET /notes", func(w http.ResponseWriter, r *http.Request) {
		writeJSON(w, http.StatusOK, store.List())
	})

	mux.HandleFunc("POST /notes", func(w http.ResponseWriter, r *http.Request) {
		var in Note
		dec := json.NewDecoder(http.MaxBytesReader(w, r.Body, 1<<20))
		if err := dec.Decode(&in); err != nil {
			http.Error(w, "body must be a JSON object", http.StatusBadRequest)
			return
		}
		if strings.TrimSpace(in.Title) == "" {
			http.Error(w, "title is required", http.StatusUnprocessableEntity)
			return
		}
		n := store.Create(Note{Title: in.Title, Body: in.Body}) // ignore any client-sent ID
		w.Header().Set("Location", fmt.Sprintf("/notes/%d", n.ID))
		writeJSON(w, http.StatusCreated, n)
	})

	mux.HandleFunc("GET /notes/{id}", func(w http.ResponseWriter, r *http.Request) {
		id, ok := parseID(w, r)
		if !ok {
			return
		}
		n, found := store.Get(id)
		if !found {
			http.Error(w, "note not found", http.StatusNotFound)
			return
		}
		writeJSON(w, http.StatusOK, n)
	})

	mux.HandleFunc("DELETE /notes/{id}", func(w http.ResponseWriter, r *http.Request) {
		id, ok := parseID(w, r)
		if !ok {
			return
		}
		if !store.Delete(id) {
			http.Error(w, "note not found", http.StatusNotFound)
			return
		}
		w.WriteHeader(http.StatusNoContent)
	})

	return mux
}

func parseID(w http.ResponseWriter, r *http.Request) (int, bool) {
	id, err := strconv.Atoi(r.PathValue("id"))
	if err != nil {
		http.Error(w, "id must be a number", http.StatusBadRequest)
		return 0, false
	}
	return id, true
}

func writeJSON(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	json.NewEncoder(w).Encode(v)
}
```

```sh
go test -tags solution ./m12/notes/
```



```bash
cd exercises
go test ./m12/notes
```

## Hints



### Hint 1: the routes

Four patterns with methods: `"GET /notes"`, `"POST /notes"`, `"GET /notes/{id}"` and `"DELETE /notes/{id}"`. With methods in the patterns, ServeMux produces the 405 responses by itself (lesson 12.1).





### Hint 2: an empty list

`json.Marshal` turns a nil slice into `null`, not `[]`. `Store.List` returns a non-nil empty slice, so encoding it directly gives `[]`. Keep it that way.





### Hint 3: keep handlers short

Write two small helpers: `writeJSON(w, status, v)`, which sets `Content-Type` before `WriteHeader`, and `parseID(w, r)`, which writes the 400 itself and returns `(id, ok)`.



The reference solution is in `exercises/m12/notes/solution.go`.

## Going further

- Use the strict `DecodeJSON` from lesson 12.3, and return problem details for errors.
- Add `PUT /notes/{id}` to replace a note, returning 200 or 404.
- Wrap the handler with the request ID and logging middleware from lesson 12.2.
