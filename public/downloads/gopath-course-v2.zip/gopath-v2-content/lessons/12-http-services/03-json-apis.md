# 12.3 Request validation and JSON APIs

Decode request bodies strictly and safely, validate business rules separately, choose the right status codes, and return errors as RFC 9457 problem details, with every failure path tested.

## What you will learn

- How to decode JSON request bodies safely: size limits, unknown fields, trailing data
- Turning decoding errors into helpful client messages
- Separating **decoding** from **validation**
- Which status codes to use: 400, 413, 415, 422 and friends
- Returning errors in the standard **problem details** format (RFC 9457)

## The idea

A JSON endpoint does three distinct things with a request body, and each can fail differently:

1. **Read** it: is it JSON, is it too big? → `415`, `413`
2. **Decode** it into a Go struct: is it well-formed, are the types right, are there unknown fields? → `400`
3. **Validate** it against business rules: is the email an email, is the age plausible? → `422`

Keeping these separate keeps handlers short and error messages precise.

## Decoding safely

`json.NewDecoder(r.Body).Decode(&v)` is how most tutorials decode. It has four problems in a public API: no size limit (a client can send gigabytes), unknown fields are silently ignored (a typo like `"emial"` is accepted and dropped), anything after the first value is ignored, and its error messages are not meant for clients. This helper fixes all four:



Source: `examples/m12/jsonapi/jsonapi.go`

```go
// A RequestError is a problem with the request, reported to the client.
type RequestError struct {
	Status int
	Detail string
}

func (e *RequestError) Error() string { return e.Detail }

// DecodeJSON decodes a request body holding exactly one JSON object
// into a T. It limits the body to maxBytes and rejects unknown fields.
// Every error it returns is a *RequestError that is safe to show.
func DecodeJSON[T any](w http.ResponseWriter, r *http.Request, maxBytes int64) (T, error) {
	var v T
	if mt, _, err := mime.ParseMediaType(r.Header.Get("Content-Type")); err != nil || mt != "application/json" {
		return v, &RequestError{http.StatusUnsupportedMediaType, "Content-Type must be application/json"}
	}

	r.Body = http.MaxBytesReader(w, r.Body, maxBytes)
	dec := json.NewDecoder(r.Body)
	dec.DisallowUnknownFields()

	if err := dec.Decode(&v); err != nil {
		return v, decodeError(err)
	}
	// Exactly one value: anything after it, even a second object, is an error.
	if err := dec.Decode(&struct{}{}); !errors.Is(err, io.EOF) {
		return v, &RequestError{http.StatusBadRequest, "body must contain a single JSON object"}
	}
	return v, nil
}

func decodeError(err error) *RequestError {
	var (
		syntaxErr *json.SyntaxError
		typeErr   *json.UnmarshalTypeError
		tooBig    *http.MaxBytesError
	)
	switch {
	case errors.As(err, &tooBig):
		return &RequestError{http.StatusRequestEntityTooLarge, fmt.Sprintf("body must be at most %d bytes", tooBig.Limit)}
	case errors.Is(err, io.EOF):
		return &RequestError{http.StatusBadRequest, "body must not be empty"}
	case errors.As(err, &syntaxErr), errors.Is(err, io.ErrUnexpectedEOF):
		return &RequestError{http.StatusBadRequest, "body is not valid JSON"}
	case errors.As(err, &typeErr) && typeErr.Field != "":
		return &RequestError{http.StatusBadRequest, fmt.Sprintf("field %q has the wrong type", typeErr.Field)}
	default:
		// For example an unknown field. The exact wording comes from
		// encoding/json and differs between Go versions.
		return &RequestError{http.StatusBadRequest, strings.TrimPrefix(err.Error(), "json: ")}
	}
}
```



- `mime.ParseMediaType` accepts `application/json; charset=utf-8` as well as the plain form.
- `http.MaxBytesReader` fails the read after `maxBytes`, and tells the server to close the connection rather than read the rest.
- `DisallowUnknownFields` rejects fields the struct does not have.
- The second `Decode` must hit `io.EOF`: the body holds exactly one JSON value.
- `decodeError` maps errors to messages a client can act on. It checks error **types** (`*json.SyntaxError`, `*json.UnmarshalTypeError`, `*http.MaxBytesError`) with `errors.As`, never message text.

That last rule matters more than ever: since Go 1.27, `encoding/json` is implemented on top of `encoding/json/v2` (lesson 8.2), and the wording of some error messages differs between versions. The example's test for unknown fields checks only the status and that the field name appears, so it passes on Go 1.24 and Go 1.27 alike.

## Validation is separate



Source: `examples/m12/jsonapi/jsonapi.go`

```go
// CreateUser is the body of POST /users.
type CreateUser struct {
	Name  string `json:"name"`
	Email string `json:"email"`
	Age   int    `json:"age"`
}

// Validate checks the business rules, returning one message per field.
func (c CreateUser) Validate() map[string]string {
	errs := map[string]string{}
	if strings.TrimSpace(c.Name) == "" {
		errs["name"] = "is required"
	}
	if _, err := mail.ParseAddress(c.Email); err != nil {
		errs["email"] = "must be a valid email address"
	}
	if c.Age < 0 || c.Age > 150 {
		errs["age"] = "must be between 0 and 150"
	}
	return errs
}

// User is what the API returns.
type User struct {
	ID    int    `json:"id"`
	Name  string `json:"name"`
	Email string `json:"email"`
	Age   int    `json:"age,omitzero"` // omitted when 0 (Go 1.24+)
}

// HandleCreateUser decodes, validates, and responds.
func HandleCreateUser(w http.ResponseWriter, r *http.Request) {
	in, err := DecodeJSON[CreateUser](w, r, 1<<20) // 1 MiB is plenty for this body
	if err != nil {
		var re *RequestError
		errors.As(err, &re)
		WriteProblem(w, Problem{Status: re.Status, Detail: re.Detail})
		return
	}
	if errs := in.Validate(); len(errs) > 0 {
		WriteProblem(w, Problem{Status: http.StatusUnprocessableEntity, Detail: "validation failed", Errors: errs})
		return
	}
	user := User{ID: 1, Name: in.Name, Email: in.Email, Age: in.Age}
	w.Header().Set("Location", fmt.Sprintf("/users/%d", user.ID))
	WriteJSON(w, http.StatusCreated, user)
}
```



`Validate` is a method on the request type, returning one message per field. Nothing in it knows about HTTP, so it is easy to unit test, and the handler stays a straight line: decode, validate, act, respond. Validation libraries using struct tags exist, but for most services plain Go is clearer and checked by the compiler.

The response type `User` is a **different type** from the request type `CreateUser`. Separate types for input and output let them evolve independently and make it impossible to accidentally accept fields clients should not set (like `id`). Note `omitzero` (Go 1.24) on `Age`, which omits the field when it is zero.

## Problem details

For errors, use the standard format from **RFC 9457**, "Problem Details for HTTP APIs": a JSON object served as `application/problem+json` with `title`, `status` and an optional `detail`, extensible with your own members:



Source: `examples/m12/jsonapi/jsonapi.go`

```go
// Problem is an error response in the "problem details" format of
// RFC 9457, served as application/problem+json.
type Problem struct {
	Title  string            `json:"title"`
	Status int               `json:"status"`
	Detail string            `json:"detail,omitempty"`
	Errors map[string]string `json:"errors,omitempty"` // our extension: errors per field
}

// WriteJSON writes v as JSON with the given status code.
func WriteJSON(w http.ResponseWriter, status int, v any) error {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	return json.NewEncoder(w).Encode(v)
}

// WriteProblem writes p as a problem details response.
func WriteProblem(w http.ResponseWriter, p Problem) {
	if p.Title == "" {
		p.Title = http.StatusText(p.Status)
	}
	w.Header().Set("Content-Type", "application/problem+json")
	w.WriteHeader(p.Status)
	json.NewEncoder(w).Encode(p)
}
```



Clients and API gateways recognize the format, and every error from your API has the same shape.

## Every path, tested



Source: `examples/m12/jsonapi/jsonapi_test.go`

```go
func Example() {
	for _, body := range []string{
		`{"name":"Ada","email":"ada@example.com","age":36}`,
		`{"name":"Bob","email":"bob@example.com"}`,
		`{"name":"","email":"nope","age":-1}`,
		`{"name":"Ada","email":"ada@example.com","age":"36"}`,
		`{"name":"Ada"`,
		`{"name":"Ada","email":"ada@example.com"} {"name":"Eve"}`,
		``,
	} {
		code, resp := post(body, "application/json")
		fmt.Println(code, resp)
	}
	code, resp := post(`{}`, "text/plain")
	fmt.Println(code, resp)
	// Output:
	// 201 {"id":1,"name":"Ada","email":"ada@example.com","age":36}
	// 201 {"id":1,"name":"Bob","email":"bob@example.com"}
	// 422 {"title":"Unprocessable Entity","status":422,"detail":"validation failed","errors":{"age":"must be between 0 and 150","email":"must be a valid email address","name":"is required"}}
	// 400 {"title":"Bad Request","status":400,"detail":"field \"age\" has the wrong type"}
	// 400 {"title":"Bad Request","status":400,"detail":"body is not valid JSON"}
	// 400 {"title":"Bad Request","status":400,"detail":"body must contain a single JSON object"}
	// 400 {"title":"Bad Request","status":400,"detail":"body must not be empty"}
	// 415 {"title":"Unsupported Media Type","status":415,"detail":"Content-Type must be application/json"}
}
```

Local command:

```sh
go test -run Example -v ./examples/m12/jsonapi
```



Each line is one request and its exact response. Note:

- A successful create returns **201 Created** with a `Location` header pointing at the new resource.
- The missing `age` in the second request is valid and omitted from the response.
- Validation reports **all** field errors at once, so a client can fix everything in one round trip. (Map keys are sorted in JSON output, so the output is stable.)
- A string where a number belongs is a **decoding** error (400), not a validation error.
- Two JSON objects in one body are rejected.
- The wrong `Content-Type` gets **415 Unsupported Media Type**.

## Choosing status codes

| Code | Use it when |
|---|---|
| 200 OK | a successful read or update that returns a body |
| 201 Created | a resource was created; set `Location` |
| 204 No Content | success with no body, typically DELETE |
| 400 Bad Request | the request is malformed: not JSON, wrong types, unknown fields |
| 401 Unauthorized | no or invalid credentials |
| 403 Forbidden | valid credentials, but not allowed |
| 404 Not Found | the resource does not exist |
| 405 Method Not Allowed | ServeMux sends it for you |
| 409 Conflict | the request conflicts with current state, such as a duplicate key |
| 413 Content Too Large | the body is over your limit |
| 415 Unsupported Media Type | wrong `Content-Type` |
| 422 Unprocessable Content | well-formed, but fails validation |
| 429 Too Many Requests | rate limited; set `Retry-After` |
| 500 Internal Server Error | a bug or a failed dependency; never show internal details |
| 503 Service Unavailable | temporarily unable, for example during shutdown |

Some teams use 400 for validation errors too. Either is defensible; be consistent and document it.

## Common mistakes

### Decoding without a size limit

One request can exhaust memory. Always use `http.MaxBytesReader` (or `http.MaxBytesHandler` for the whole server, lesson 12.6).

### Matching error strings

They change between Go versions. Use `errors.As` with the error types.

### Showing internal errors to clients

`"pq: connection refused to 10.0.3.7"` helps attackers and confuses users. Log the details; return a generic message and a request ID (lesson 12.8 does this).

### Writing headers after the body

Headers and the status must be set before the first `Write`. `WriteJSON` sets `Content-Type`, then `WriteHeader`, then writes.

## Key takeaways

- Decode strictly: check `Content-Type`, limit size, disallow unknown fields, require a single value.
- Classify decode errors by type with `errors.As`, never by message.
- Validate separately with plain Go methods that return per-field errors.
- Use distinct request and response types.
- Return errors as `application/problem+json` (RFC 9457) with accurate status codes.

## Further reading

- [RFC 9457: Problem Details for HTTP APIs](https://www.rfc-editor.org/rfc/rfc9457)
- [RFC 9110: HTTP Semantics](https://www.rfc-editor.org/rfc/rfc9110), the definitions of every status code
- [Package encoding/json](https://pkg.go.dev/encoding/json)
