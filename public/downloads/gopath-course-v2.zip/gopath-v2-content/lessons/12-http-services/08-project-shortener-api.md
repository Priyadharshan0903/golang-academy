# 12.8 Project milestone: the shortener's HTTP API

Milestone 2 of the URL shortener: a production-shaped HTTP service with a JSON API, redirects, error mapping, request IDs, access logs, Prometheus metrics, per-client rate limiting, health checks and graceful shutdown, tested end to end.

## The milestone

In milestone 1 (lesson 5.7) you built the shortener's core: the `link` package, with no knowledge of HTTP. Milestone 2 puts a service in front of it, using everything from this module. The core does not change at all; that is the payoff of keeping it independent.

| Milestone | After module | Adds | Status |
|---|---|---|---|
| 1. Core | 5. Errors | Domain types, errors, validation, `Service`, in-memory store | done |
| **2. HTTP API** (this lesson) | 12. HTTP services | JSON API, redirects, middleware, metrics, shutdown | done |
| 3. Postgres | 13. Working with data | A database-backed `Store`, migrations | next |
| 4. Deploy | 15. Cloud native | Container image and Kubernetes manifests | |

The code is in [`projects/shortener`](https://github.com/Priyadharshan0903/gopath-academy/tree/main/projects/shortener). The shortener is now **its own Go module**, because it uses two third party packages: the Prometheus client, and `golang.org/x/time/rate` for rate limiting (the production version of the token bucket you built in lesson 7.8).

```text
cmd/shortener/      main: wiring, the two servers, graceful shutdown
internal/link/      the domain from milestone 1, unchanged
internal/httpapi/   routes, JSON, error mapping, middleware, metrics, rate limiting
internal/config/    configuration from environment variables
```

Everything is under `internal/`, so no other module can import it: the only public interface of this program is HTTP.

## Try it

```bash
cd projects/shortener
go mod tidy                      # first time only
LOG_FORMAT=text go run ./cmd/shortener
```

```bash
$ curl -s -X POST localhost:8080/api/links -H 'Content-Type: application/json' \
    -d '{"url": "https://go.dev/doc", "code": "godoc"}'
{"code":"godoc","url":"https://go.dev/doc","short_url":"http://localhost:8080/godoc","created_at":"..."}

$ curl -si localhost:8080/godoc | grep -E '^(HTTP|Location)'
HTTP/1.1 302 Found
Location: https://go.dev/doc

$ curl -s -X POST localhost:8080/api/links -H 'Content-Type: application/json' \
    -d '{"url": "https://go.dev", "code": "godoc"}'
{"title":"Conflict","status":409,"detail":"create \"godoc\": code already in use","request_id":"..."}

$ curl -s localhost:9090/metrics | grep 'shortener_http_requests_total{'
shortener_http_requests_total{code="201",route="POST /api/links"} 1
shortener_http_requests_total{code="302",route="GET /{code}"} 1
shortener_http_requests_total{code="409",route="POST /api/links"} 1
```

## The routes and the middleware stack



Source: `projects/shortener/internal/httpapi/api.go`

```go
// New returns the complete HTTP handler: routes wrapped in middleware.
func New(o Options) http.Handler {
	a := &api{o}
	limit := func(h http.HandlerFunc) http.Handler {
		if o.Limiter == nil {
			return h
		}
		return o.Limiter.Middleware(o.ClientIP, h)
	}

	mux := http.NewServeMux()
	mux.Handle("POST /api/links", limit(a.createLink))
	mux.Handle("GET /api/links/{code}", limit(a.getLink))
	mux.Handle("DELETE /api/links/{code}", limit(a.deleteLink))
	mux.Handle("GET /{code}", limit(a.redirect))
	mux.HandleFunc("GET /{$}", a.home)
	mux.HandleFunc("GET /healthz", a.healthz)
	mux.HandleFunc("GET /readyz", a.readyz)

	// Outermost first. Recover sits inside Logging and Metrics so that
	// panicking requests are still logged and counted, as 500s.
	var h http.Handler = mux
	h = recoverPanics(o.Logger, h)
	if o.Metrics != nil {
		h = o.Metrics.Middleware(h)
	}
	h = logRequests(o.Logger, h)
	h = requestID(h)
	return h
}
```



Things to notice:

- **Rate limiting wraps individual routes** (lesson 12.2), so health checks are never limited. Because it runs inside the mux, rate limited requests still get their route label in metrics.
- **Recovery sits inside logging and metrics**, so a panicking request is logged and counted as a 500 like any other.
- **`GET /{code}` and `GET /healthz` do not conflict**: `/healthz` is more specific (lesson 12.1). It does mean `healthz`, `readyz` and `api` can never be short codes; a real service would reserve them in validation.

## The handlers



Source: `projects/shortener/internal/httpapi/api.go`

```go
func (a *api) createLink(w http.ResponseWriter, r *http.Request) {
	in, err := decodeJSON[createRequest](w, r, 16<<10)
	if err != nil {
		a.writeError(w, r, err)
		return
	}
	l, err := a.Service.Shorten(r.Context(), in.URL, in.Code)
	if err != nil {
		a.writeError(w, r, err)
		return
	}
	w.Header().Set("Location", "/api/links/"+l.Code)
	writeJSON(w, http.StatusCreated, a.response(l))
}

func (a *api) getLink(w http.ResponseWriter, r *http.Request) {
	l, err := a.Service.Resolve(r.Context(), r.PathValue("code"))
	if err != nil {
		a.writeError(w, r, err)
		return
	}
	writeJSON(w, http.StatusOK, a.response(l))
}

func (a *api) deleteLink(w http.ResponseWriter, r *http.Request) {
	if err := a.Service.Delete(r.Context(), r.PathValue("code")); err != nil {
		a.writeError(w, r, err)
		return
	}
	w.WriteHeader(http.StatusNoContent)
}

func (a *api) redirect(w http.ResponseWriter, r *http.Request) {
	l, err := a.Service.Resolve(r.Context(), r.PathValue("code"))
	if err != nil {
		a.writeError(w, r, err)
		return
	}
	// 302, not 301: browsers cache 301s forever, so a link could never
	// be changed or counted again.
	http.Redirect(w, r, l.URL, http.StatusFound)
}
```



Each handler is a straight line: decode, call the service, respond or hand the error to `writeError`. The redirect uses **302 Found**, not 301: browsers cache permanent redirects indefinitely, so a 301 could never be counted or changed again.

## Mapping errors to status codes

Milestone 1 promised that "the HTTP layer maps each sentinel error to a status code". Here it is, in one place:



Source: `projects/shortener/internal/httpapi/errors.go`

```go
// statusFor maps an error to an HTTP status code. This is the one place
// where domain errors meet HTTP, as planned in milestone 1.
func statusFor(err error) int {
	var re *requestError
	switch {
	case errors.As(err, &re):
		return re.status
	case errors.Is(err, link.ErrNotFound):
		return http.StatusNotFound
	case errors.Is(err, link.ErrCodeTaken):
		return http.StatusConflict
	case errors.Is(err, link.ErrInvalidURL), errors.Is(err, link.ErrInvalidCode):
		return http.StatusUnprocessableEntity
	default:
		return http.StatusInternalServerError
	}
}

// writeError writes err as a problem response. Details of client errors
// are shown to the client; server errors are logged, and the client
// gets only a generic message and the request ID to quote.
func (a *api) writeError(w http.ResponseWriter, r *http.Request, err error) {
	status := statusFor(err)
	p := problem{Title: http.StatusText(status), Status: status, RequestID: requestIDFrom(r.Context())}
	if status < 500 {
		p.Detail = err.Error()
	} else {
		a.Logger.LogAttrs(r.Context(), slog.LevelError, "request failed",
			slog.String("error", err.Error()), slog.String("request_id", p.RequestID))
	}
	w.Header().Set("Content-Type", "application/problem+json")
	w.WriteHeader(status)
	json.NewEncoder(w).Encode(p)
}
```



Because the service wraps errors with `%w`, `errors.Is` finds `link.ErrCodeTaken` inside `create "godoc": code already in use`. Client errors show their detail; server errors are **logged in full and hidden from the client**, who gets a generic message and the request ID to quote in a bug report. `TestServerErrorsAreNotLeaked` checks both halves with a store that fails like a broken database.

## Wiring it together

`main` is three lines: create a context that is cancelled on SIGINT or SIGTERM, call `run`, and exit non-zero if it fails. Everything else is in `run`:



Source: `projects/shortener/cmd/shortener/main.go`

```go
// run is the whole program. It takes its dependencies as parameters,
// so tests can run it with their own environment and output, and stop
// it by cancelling ctx.
func run(ctx context.Context, getenv func(string) string, stdout io.Writer) error {
	cfg, err := config.Load(getenv)
	if err != nil {
		return fmt.Errorf("configuration: %w", err)
	}
	logger := newLogger(cfg, stdout)
	logger.Info("starting", "addr", cfg.Addr, "admin_addr", cfg.AdminAddr, "base_url", cfg.BaseURL.String())

	reg := prometheus.NewRegistry()
	reg.MustRegister(collectors.NewGoCollector(), collectors.NewProcessCollector(collectors.ProcessCollectorOpts{}))

	limiter := httpapi.NewClientLimiter(cfg.RateLimit, cfg.RateBurst)
	clientIP := httpapi.RemoteIP
	if cfg.ClientIPHeader != "" {
		clientIP = httpapi.HeaderIP(cfg.ClientIPHeader)
	}

	store, closeStore, err := openStore(ctx, cfg, logger)
	if err != nil {
		return err
	}
	defer closeStore()

	var ready atomic.Bool
	api := newServer(httpapi.New(httpapi.Options{
		Service:  link.NewService(store),
		BaseURL:  cfg.BaseURL,
		Logger:   logger,
		Ready:    &ready,
		Metrics:  httpapi.NewMetrics(reg),
		Limiter:  limiter,
		ClientIP: clientIP,
	}))
	admin := newServer(adminMux(reg))
```



`run` takes `getenv` and `stdout` as parameters and stops when its context is cancelled. That makes the **whole program testable**: `TestRun` starts it on free ports (`ADDR=127.0.0.1:0`), finds the actual addresses in the JSON log, creates a link over real HTTP, follows the redirect, scrapes the admin port's metrics, then cancels the context, exactly what a SIGTERM does, and checks that `run` returns `nil`.

Two servers: the **API** on `:8080` and the **admin** server on `:9090` with `/metrics` and pprof, never exposed publicly (lesson 12.5). The pprof handlers are registered on the admin mux explicitly instead of importing `net/http/pprof` for its side effect on the default mux.

## Graceful shutdown, Kubernetes style



Source: `projects/shortener/cmd/shortener/main.go`

```go
select {
	case err = <-serveErr:
		logger.Error("server failed", "error", err)
	case <-ctx.Done():
		logger.Info("shutting down")
	}

	// Graceful shutdown (lesson 7.7). First report "not ready" and keep
	// serving for SHUTDOWN_DELAY, so a load balancer that still routes to
	// us has time to notice. Then stop accepting connections and let
	// in-flight requests finish within SHUTDOWN_TIMEOUT.
	ready.Store(false)
	if err == nil && cfg.ShutdownDelay > 0 {
		time.Sleep(cfg.ShutdownDelay)
	}
	shutdownCtx, cancel := context.WithTimeout(context.Background(), cfg.ShutdownTimeout)
	defer cancel()
	shutdownErr := errors.Join(api.Shutdown(shutdownCtx), admin.Shutdown(shutdownCtx))
	wg.Wait()
	logger.Info("stopped")
	return errors.Join(err, shutdownErr)
}
```



Lesson 7.7 introduced `Server.Shutdown`. In Kubernetes there is one more subtlety: when a pod is terminated, removing it from the Service's endpoints and sending it SIGTERM happen **at the same time**. For a few seconds, other components may still route new requests to a pod that has started shutting down. So the shortener:

1. turns `/readyz` to 503 immediately,
2. keeps serving normally for `SHUTDOWN_DELAY` (default 0 locally; about 5 seconds in Kubernetes),
3. then calls `Shutdown`, which stops accepting connections and waits up to `SHUTDOWN_TIMEOUT` for in-flight requests.

Module 15 sets these values in the Deployment manifest, along with probes on `/healthz` and `/readyz`.

## What the tests cover

```bash
go test ./...
```

| Test | Checks |
|---|---|
| `TestCreateResolveRedirect` | the happy path: 201 with `Location`, JSON fields, 302 redirect |
| `TestErrorMapping` | 409, 422, 400, 415, 404 and 405, table-driven |
| `TestServerErrorsAreNotLeaked` | internal errors are logged, not shown; problem includes the request ID |
| `TestRateLimit` | burst of 3 then 429; health checks never limited |
| `TestReadiness` | `/readyz` is 503 until ready |
| `TestMetricsAndLogs` | counters by route pattern and status; access log fields |
| `TestRun` | the real program over real HTTP, and a clean shutdown on cancel |
| `config` tests | defaults, and every invalid variable reported at once |

## Your turn

Ideas to extend the milestone, in rough order of difficulty:

1. Reserve `api`, `healthz` and `readyz` so they cannot be used as custom codes. Where does that rule belong: `link` or `httpapi`?
2. Design `DELETE /api/links/{code}`: which status codes, and which new `Store` method? Then compare with the version milestone 4 adds (lesson 15.4 needs it).
3. Count redirects per code. Should that be a Prometheus label? (Lesson 12.5 says no. Why?) Where should it be stored instead?
4. Add OpenTelemetry tracing with the middleware from lesson 12.5, or with `otelhttp`.

Next, Module 13 replaces the in-memory store with PostgreSQL, without changing a line of `httpapi`.
