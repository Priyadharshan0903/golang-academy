# 12.6 Security basics: timeouts, limits, TLS and CSRF

The settings every Go HTTP server exposed to a network needs: server timeouts (with a slowloris test), header and body limits, TLS configuration, security headers, Go 1.25's CrossOriginProtection against CSRF, and handling secrets.

## What you will learn

- Why `http.Server`'s zero values are unsafe on the internet, and which timeouts to set
- How a slowloris attack works, and a test that shows the defense
- Limiting header and body sizes
- TLS in Go, and when to terminate it elsewhere
- Security headers, and CSRF protection with `http.CrossOriginProtection` (Go 1.25)

## Timeouts

`http.Server` with no timeouts waits **forever** for a client. One client can open thousands of connections and send nothing, or send a byte every few seconds, and the server keeps a goroutine and a socket for each until it runs out of file descriptors or memory. Set all four timeouts:



Source: `examples/m12/security/security.go`

```go
// NewServer returns an http.Server with limits suitable for a service
// exposed to the internet. The zero values in http.Server mean "no
// limit", so every one of these must be set explicitly.
func NewServer(addr string, h http.Handler) *http.Server {
	return &http.Server{
		Addr:    addr,
		Handler: h,

		// Slow clients must not hold connections open forever.
		ReadHeaderTimeout: 5 * time.Second,   // time to read the request headers
		ReadTimeout:       30 * time.Second,  // time to read the whole request, body included
		WriteTimeout:      60 * time.Second,  // time to write the response
		IdleTimeout:       120 * time.Second, // keep-alive connections waiting for the next request

		MaxHeaderBytes: 64 << 10, // 64 KiB of headers is plenty (the default is 1 MiB)

		TLSConfig: &tls.Config{MinVersion: tls.VersionTLS12},
	}
}
```



| Field | Limits |
|---|---|
| `ReadHeaderTimeout` | reading the request line and headers. The most important one. |
| `ReadTimeout` | reading the entire request, body included. |
| `WriteTimeout` | from the end of reading the headers to the end of writing the response. It caps how long a handler can take, so streaming endpoints need a different value (set per request with `http.ResponseController.SetWriteDeadline`). |
| `IdleTimeout` | how long a keep-alive connection may wait for its next request. |

### Slowloris, tested

A **slowloris** client sends headers slowly and never finishes, to tie up the server. This test does exactly that against a real server:



Source: `examples/m12/security/security_test.go`

```go
// A "slowloris" client opens a connection and sends its headers very
// slowly, tying up the server. ReadHeaderTimeout cuts it off.
func TestReadHeaderTimeout(t *testing.T) {
	srv := httptest.NewUnstartedServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {}))
	srv.Config.ReadHeaderTimeout = 200 * time.Millisecond
	srv.Start()
	defer srv.Close()

	start := time.Now() // before dialing: the server's clock starts when it accepts
	conn, err := net.Dial("tcp", srv.Listener.Addr().String())
	if err != nil {
		t.Fatal(err)
	}
	defer conn.Close()

	io.WriteString(conn, "GET / HTTP/1.1\r\nHost: example.com\r\n") // ...and never finish
	conn.SetReadDeadline(time.Now().Add(5 * time.Second))
	_, err = bufio.NewReader(conn).ReadString('\n')
	elapsed := time.Since(start)

	t.Logf("server gave up after %v (err=%v)", elapsed.Round(10*time.Millisecond), err)
	var netErr net.Error
	if errors.As(err, &netErr) && netErr.Timeout() {
		t.Fatal("the server never closed the connection")
	}
	if elapsed < 200*time.Millisecond {
		t.Fatalf("closed after %v, before the timeout", elapsed)
	}
}
```

Local command:

```sh
go test -v -run TestReadHeaderTimeout ./examples/m12/security
```



```text
security_test.go:37: server gave up after 200ms (err=EOF)
```

With `ReadHeaderTimeout` set, the server closes the connection when the time runs out. Remove that line and the test fails after 5 seconds: the server would have waited forever.

Timeouts are also needed in the other direction. Every outgoing `http.Client` needs a `Timeout` and every outgoing request a context with a deadline (lesson 8.7), or one slow dependency can make all your handlers hang.

## Size limits

- **Headers**: `MaxHeaderBytes` defaults to 1 MiB. 64 KiB is plenty for most APIs.
- **Bodies** have no default limit. Limit them per handler with `http.MaxBytesReader` (lesson 12.3) or for a whole server with `http.MaxBytesHandler`:



Source: `examples/m12/security/security.go`

```go
// LimitBody caps every request body at n bytes. Reading more fails
// with an *http.MaxBytesError, and the server closes the connection.
func LimitBody(n int64, next http.Handler) http.Handler {
	return http.MaxBytesHandler(next, n)
}
```



Also bound everything a client controls in size or count: list page sizes, batch sizes, upload sizes, query complexity.

## TLS

Go's `crypto/tls` is a complete, well-maintained TLS implementation with secure defaults: TLS 1.2 as the minimum for servers, modern cipher suites only, TLS 1.3 preferred, and post-quantum key exchange enabled by default in recent releases. To serve HTTPS directly:

```go
srv := NewServer(":8443", handler)
log.Fatal(srv.ListenAndServeTLS("cert.pem", "key.pem"))
```

You rarely need to change the `tls.Config`; setting `MinVersion` explicitly, as above, documents the intent. For automatic certificates from Let's Encrypt, the `golang.org/x/crypto/acme/autocert` package handles issuance and renewal.

In **Kubernetes**, TLS is usually terminated at the **ingress controller** or a service mesh, and the Go service speaks plain HTTP inside the cluster (Module 15). That is a reasonable default; teams that need encryption inside the cluster add mesh mTLS rather than certificates in every service.

## Security headers

APIs consumed by browsers should send a few headers that make browsers stricter:



Source: `examples/m12/security/security.go`

```go
// Headers sets response headers that make browsers safer when they
// talk to this service.
func Headers(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		h := w.Header()
		h.Set("X-Content-Type-Options", "nosniff") // never guess a different content type
		h.Set("Referrer-Policy", "no-referrer")
		h.Set("Content-Security-Policy", "default-src 'none'; frame-ancestors 'none'") // an API serves no pages
		if r.TLS != nil {
			h.Set("Strict-Transport-Security", "max-age=31536000") // only ever use HTTPS from now on
		}
		next.ServeHTTP(w, r)
	})
}
```



`nosniff` stops browsers from interpreting a JSON response as HTML or script; the CSP tells them this response may load nothing and may not be framed; HSTS tells them to use HTTPS for this host from now on, and is only sent over TLS.

## CSRF protection (Go 1.25)

**Cross-site request forgery**: a malicious page makes the victim's browser send a request to your site, and the browser attaches the victim's cookies. If your site uses cookie sessions, the request is authenticated. The traditional defense was CSRF tokens in every form.

Go 1.25 added `http.CrossOriginProtection`, which uses headers that all browsers since 2023 send: **`Sec-Fetch-Site`**, falling back to comparing **`Origin`** with `Host`. It rejects state-changing requests (anything except GET, HEAD and OPTIONS) that come from another origin:



Source: `examples/m12/security/csrf.go`

```go
// ProtectForms rejects cross-origin, state-changing browser requests:
// the defense against cross-site request forgery that Go 1.25 added to
// net/http. Requests from our own site and from trusted origins pass.
func ProtectForms(next http.Handler) (http.Handler, error) {
	cop := http.NewCrossOriginProtection()
	if err := cop.AddTrustedOrigin("https://admin.example.com"); err != nil {
		return nil, err
	}
	return cop.Handler(next), nil
}
```





Source: `examples/m12/security/csrf_test.go`

```go
func ExampleProtectForms() {
	h, _ := ProtectForms(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		fmt.Fprint(w, "done")
	}))
	try := func(method, header, value string) {
		req := httptest.NewRequest(method, "https://shop.example.com/cart", nil)
		if header != "" {
			req.Header.Set(header, value)
		}
		rec := httptest.NewRecorder()
		h.ServeHTTP(rec, req)
		fmt.Printf("%-4s %-30s %d\n", method, header+" "+value, rec.Code)
	}
	try("POST", "Sec-Fetch-Site", "same-origin")
	try("POST", "Sec-Fetch-Site", "cross-site")
	try("GET", "Sec-Fetch-Site", "cross-site")
	try("POST", "Origin", "https://evil.example.net")
	try("POST", "Origin", "https://admin.example.com")
	try("POST", "", "") // curl, or another server: no browser headers
	// Output:
	// POST Sec-Fetch-Site same-origin     200
	// POST Sec-Fetch-Site cross-site      403
	// GET  Sec-Fetch-Site cross-site      200
	// POST Origin https://evil.example.net 403
	// POST Origin https://admin.example.com 200
	// POST                                200
}
```

Local command:

```sh
go test -run ExampleProtectForms -v ./examples/m12/security
```



Same-origin POSTs pass, cross-site POSTs get 403, safe methods always pass, trusted origins pass, and requests without browser headers (curl, other servers) pass because they cannot carry a victim's cookies. Two consequences:

- Your GET handlers must **never change state**, because they are always allowed.
- APIs authenticated with an `Authorization` header instead of cookies are not exposed to CSRF in the first place, since browsers do not attach that header automatically.

These files carry `//go:build go1.25`, because the course's main module still supports Go 1.24.

## Secrets

- Read secrets from files or the environment at start-up (lesson 12.4); never log them, never put them in URLs (URLs end up in logs and browser history).
- Compare secrets such as API keys with `crypto/subtle.ConstantTimeCompare`, so the comparison time does not leak how many characters matched.
- Generate tokens and IDs with `crypto/rand` (`rand.Text()` since Go 1.24 returns a secure random string), never `math/rand`.

## Common mistakes

### No timeouts

`http.ListenAndServe` and a bare `&http.Server{}` have none. Always set them.

### Unlimited bodies

`io.ReadAll(r.Body)` on a public endpoint reads whatever a client sends.

### State changes on GET

Browsers, crawlers and link previewers follow GET links freely, and CSRF protection lets them through.

### Comparing secrets with ==

Use `subtle.ConstantTimeCompare`.

## Key takeaways

- Set `ReadHeaderTimeout`, `ReadTimeout`, `WriteTimeout` and `IdleTimeout` on every server; the zero values mean "wait forever".
- Limit header size with `MaxHeaderBytes` and body size with `MaxBytesReader` or `MaxBytesHandler`.
- Go's TLS defaults are good; in Kubernetes, TLS usually terminates at the ingress.
- Send `nosniff`, a restrictive CSP and, over TLS, HSTS.
- Wrap cookie-authenticated, state-changing endpoints with `http.CrossOriginProtection` (Go 1.25), and keep GET handlers free of side effects.

## Further reading

- [The complete guide to Go net/http timeouts](https://blog.cloudflare.com/the-complete-guide-to-golang-net-http-timeouts/) on the Cloudflare blog
- [Package net/http: CrossOriginProtection](https://pkg.go.dev/net/http#CrossOriginProtection)
- [OWASP Cheat Sheet Series](https://cheatsheetseries.owasp.org/)
