# 12.4 Configuration and the twelve-factor app

Load configuration from the environment into one typed struct, validate it at start-up with every error reported at once, read secrets from files, and keep secrets out of logs.

## What you will learn

- The twelve-factor rule for configuration, and why it fits containers
- Loading config into a typed struct with defaults and validation
- Testing configuration without touching the real environment
- Reading secrets from files, as Kubernetes provides them
- Logging configuration without leaking secrets

## The idea

The **twelve-factor app** methodology (written at Heroku in 2011, and still the norm for cloud services) says: store configuration in the **environment**. The same build artifact, one container image, then runs in development, staging and production, with only environment variables differing. Kubernetes, Docker and every platform support this directly.

Configuration is anything that varies between deployments: addresses, URLs of other services, credentials, limits, log levels. It is **not** things like your route table, which belong in code.

## One struct, loaded once



Source: `examples/m12/config/config.go`

```go
// Config is everything the service needs to know about its
// environment. It is loaded once at start-up and passed down
// explicitly; no package reads environment variables on its own.
type Config struct {
	Addr            string        // ADDR, default ":8080"
	BaseURL         *url.URL      // BASE_URL, required
	LogLevel        slog.Level    // LOG_LEVEL: debug, info, warn, error
	ShutdownTimeout time.Duration // SHUTDOWN_TIMEOUT, default 10s
	RateLimit       float64       // RATE_LIMIT, requests per second per client
	DatabaseURL     string        // DATABASE_URL or DATABASE_URL_FILE, a secret
}

// Load reads the configuration through getenv (os.Getenv in main, a
// map in tests) and reports every problem at once.
func Load(getenv func(string) string) (Config, error) {
	cfg := Config{
		Addr:            ":8080",
		LogLevel:        slog.LevelInfo,
		ShutdownTimeout: 10 * time.Second,
		RateLimit:       10,
	}
	var errs []error

	if v := getenv("ADDR"); v != "" {
		cfg.Addr = v
	}
	if v := getenv("BASE_URL"); v == "" {
		errs = append(errs, errors.New("BASE_URL is required"))
	} else if u, err := url.Parse(v); err != nil || u.Scheme == "" || u.Host == "" {
		errs = append(errs, fmt.Errorf("BASE_URL must be an absolute URL, got %q", v))
	} else {
		cfg.BaseURL = u
	}
	if v := getenv("LOG_LEVEL"); v != "" {
		if err := cfg.LogLevel.UnmarshalText([]byte(v)); err != nil {
			errs = append(errs, fmt.Errorf("LOG_LEVEL: %w", err))
		}
	}
	if v := getenv("SHUTDOWN_TIMEOUT"); v != "" {
		d, err := time.ParseDuration(v)
		if err != nil || d <= 0 {
			errs = append(errs, fmt.Errorf("SHUTDOWN_TIMEOUT must be a positive duration like 15s, got %q", v))
		}
		cfg.ShutdownTimeout = d
	}
	if v := getenv("RATE_LIMIT"); v != "" {
		f, err := strconv.ParseFloat(v, 64)
		if err != nil || f <= 0 {
			errs = append(errs, fmt.Errorf("RATE_LIMIT must be a positive number, got %q", v))
		}
		cfg.RateLimit = f
	}

	secret, err := secretFrom(getenv, "DATABASE_URL")
	if err != nil {
		errs = append(errs, err)
	}
	cfg.DatabaseURL = secret

	return cfg, errors.Join(errs...)
}
```



The pattern:

- **One `Config` struct** with typed fields (`time.Duration`, `*url.URL`, `slog.Level`), not strings to be parsed later all over the code.
- **Defaults** for everything that has a sensible one; only truly deployment-specific values are required.
- **Validate at start-up** and report **every** problem at once with `errors.Join`. A service with bad configuration should refuse to start with a clear message, not fail on the first request an hour later.
- **`getenv` is a parameter.** `main` passes `os.Getenv`; tests pass a map. No test ever has to modify the process environment, and tests can run in parallel.
- **Load once, pass down.** No package reads environment variables on its own; they receive what they need as constructor arguments. That keeps dependencies visible and code testable.



Source: `examples/m12/config/config_test.go`

```go
func ExampleLoad() {
	cfg, err := Load(env(map[string]string{
		"BASE_URL":         "https://sho.rt",
		"LOG_LEVEL":        "debug",
		"SHUTDOWN_TIMEOUT": "30s",
	}))
	fmt.Println(err)
	fmt.Println(cfg.Addr, cfg.BaseURL, cfg.LogLevel, cfg.ShutdownTimeout, cfg.RateLimit)

	_, err = Load(env(map[string]string{
		"LOG_LEVEL":        "loud",
		"SHUTDOWN_TIMEOUT": "soon",
		"RATE_LIMIT":       "-1",
	}))
	fmt.Println(err)
	// Output:
	// <nil>
	// :8080 https://sho.rt DEBUG 30s 10
	// BASE_URL is required
	// LOG_LEVEL: slog: level string "loud": unknown name
	// SHUTDOWN_TIMEOUT must be a positive duration like 15s, got "soon"
	// RATE_LIMIT must be a positive number, got "-1"
}
```

Local command:

```sh
go test -run ExampleLoad -v ./examples/m12/config
```



## Flags or environment variables?

Both are fine and many services accept both. Command-line flags (the `flag` package, Module 14) are self-documenting (`-help`) and natural for CLIs. Environment variables are natural for services in containers, where the platform sets them from manifests. A common approach: environment variables for services, flags for tools, and if you support both, flags win.

Avoid configuration **files** for the basics. They have to be built into the image or mounted, and they invite a second, hidden source of truth. Mount a file when the configuration is genuinely structured and large.

## Secrets

Passwords, API keys and database URLs with credentials are configuration too, with extra rules:

- Never commit them, never bake them into images.
- Prefer reading them from **files**. Kubernetes Secrets and Docker secrets are usually mounted as files, and file contents do not show up in `env` output, process listings, or crash reports that dump the environment.

A widely used convention is a `_FILE` suffix: `DATABASE_URL_FILE=/run/secrets/db-url` means "read the value from this file":



Source: `examples/m12/config/config.go`

```go
// secretFrom reads a secret from NAME, or from the file named by
// NAME_FILE. Files are how Kubernetes and Docker usually provide
// secrets, and they keep secrets out of `env` output and crash dumps.
func secretFrom(getenv func(string) string, name string) (string, error) {
	value, file := getenv(name), getenv(name+"_FILE")
	switch {
	case value != "" && file != "":
		return "", fmt.Errorf("set %s or %s_FILE, not both", name, name)
	case file != "":
		b, err := os.ReadFile(file)
		if err != nil {
			return "", fmt.Errorf("%s_FILE: %w", name, err)
		}
		return strings.TrimSpace(string(b)), nil
	default:
		return value, nil
	}
}
```



## Logging the configuration safely

Logging the effective configuration at start-up is very useful when debugging deployments. Implementing `slog.LogValuer` controls exactly what is printed:



Source: `examples/m12/config/config.go`

```go
// LogValue makes slog print the config without the secret, so logging
// the config at start-up is safe.
func (c Config) LogValue() slog.Value {
	base := ""
	if c.BaseURL != nil {
		base = c.BaseURL.String()
	}
	return slog.GroupValue(
		slog.String("addr", c.Addr),
		slog.String("base_url", base),
		slog.String("log_level", c.LogLevel.String()),
		slog.Duration("shutdown_timeout", c.ShutdownTimeout),
		slog.Float64("rate_limit", c.RateLimit),
		slog.Bool("database_url_set", c.DatabaseURL != ""),
	)
}
```



`TestSecretFromFile` logs the whole config and checks that the password does not appear. The log shows only `config.database_url_set=true`. Writing that test is cheap insurance: a careless `slog.Any("config", cfg)` in the future still cannot leak the secret.

## Common mistakes

### Reading os.Getenv deep inside packages

Configuration becomes invisible and untestable. Read once in `main`, pass values down.

### Failing on the first error

Operators then fix one variable per deploy. Collect all errors with `errors.Join`.

### Secrets in environment variables printed at start-up

Redact with `LogValuer`, and prefer files.

### Silent defaults for required settings

A default `BASE_URL` of `localhost` in production produces wrong links quietly. Make settings that differ in every environment required, or at least log them at start-up.

## Key takeaways

- Store configuration in the environment; one image runs everywhere.
- Load into one typed struct with defaults; validate at start-up and report all errors at once.
- Inject `getenv` so tests use a map.
- Read secrets from files where possible (`NAME_FILE`), and redact them in logs with `slog.LogValuer`.

## Further reading

- [The Twelve-Factor App: Config](https://12factor.net/config)
- [Kubernetes: Secrets](https://kubernetes.io/docs/concepts/configuration/secret/)
