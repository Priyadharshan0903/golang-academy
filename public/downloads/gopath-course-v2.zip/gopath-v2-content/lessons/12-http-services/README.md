# 12. Building HTTP services

Part 4 is about running Go in production. It starts where most Go services start: an HTTP API. Go's standard library is enough to build one properly. Since Go 1.22 its router understands methods and path parameters, so many teams no longer need a web framework at all.

This module builds the pieces one at a time, each with tests, and then assembles them into **milestone 2 of the URL shortener**: a complete service with JSON endpoints, redirects, request IDs, access logs, Prometheus metrics, rate limiting, health checks and graceful shutdown. Module 15 deploys it to Kubernetes.

**Time:** about 5 to 6 hours, plus the exercise and project.

- [12.1 net/http and ServeMux routing](01-servemux.md)
- [12.2 Middleware](02-middleware.md)
- [12.3 Request validation and JSON APIs](03-json-apis.md)
- [12.4 Configuration and the twelve-factor app](04-configuration.md)
- [12.5 Observability: logs, metrics and traces](05-observability.md)
- [12.6 Security basics: timeouts, limits, TLS and CSRF](06-security.md)
- [12.7 Exercise: a notes JSON API](07-exercise.md)
- [12.8 Project milestone: the shortener's HTTP API](08-project-shortener-api.md)
