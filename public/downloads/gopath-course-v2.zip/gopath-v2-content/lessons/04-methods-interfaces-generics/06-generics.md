# 4.6 Generics: type parameters and constraints

Write functions and types that work across many types with type parameters, constrain them with any, comparable, cmp.Ordered and type unions, and rely on type inference.

## What you will learn

- How to declare generic functions and generic types
- What a **constraint** is: `any`, `comparable`, `cmp.Ordered`, method constraints and type unions
- What `~` means in a constraint
- How type inference saves you from writing type arguments
- How to get the zero value of a type parameter

## The idea

Generics (added in Go 1.18) let you write code once for many types, **without** losing compile-time type checking. Before generics you had two options: copy the code for every type, or use `any` and type assertions. Generics remove that trade-off for code like containers, algorithms over slices and maps, and helpers like `Map` or `Filter`.

A generic function declares **type parameters** in square brackets before its normal parameters. Each type parameter has a **constraint** that says which types are allowed and what you can do with them.

## Generic functions



Source: `examples/m04/generics/generics_test.go`

```go
// Map works for any input type T and output type U.
func Map[T, U any](items []T, f func(T) U) []U {
	out := make([]U, 0, len(items))
	for _, v := range items {
		out = append(out, f(v))
	}
	return out
}

func Example_genericFunction() {
	lengths := Map([]string{"go", "rust", "zig"}, func(s string) int { return len(s) })
	fmt.Println(lengths)

	labels := Map(lengths, strconv.Itoa) // T and U are inferred from the arguments
	fmt.Printf("%q\n", labels)

	explicit := Map[int, int]([]int{1, 2}, func(n int) int { return n * 10 })
	fmt.Println(explicit)

	// Output:
	// [2 4 3]
	// ["2" "4" "3"]
	// [10 20]
}
```

Local command:

```sh
go test -run Example_genericFunction -v ./examples/m04/generics
```



`Map[T, U any]` has two type parameters. You almost never write type arguments yourself: the compiler **infers** `T` and `U` from the arguments. Explicit type arguments (`Map[int, int]`) are needed only when inference has nothing to work from, for example when a type parameter appears only in the result.

## Constraints

A constraint is an interface. It limits which types can be used **and** decides which operations are allowed inside the function.



Source: `examples/m04/generics/generics_test.go`

```go
// MaxOf needs values it can compare with >, so it constrains T to
// cmp.Ordered (all integer, float and string types).
func MaxOf[T cmp.Ordered](first T, rest ...T) T {
	m := first
	for _, v := range rest {
		if v > m {
			m = v
		}
	}
	return m
}

// IndexOf only needs ==, so comparable is enough.
func IndexOf[T comparable](items []T, target T) int {
	for i, v := range items {
		if v == target {
			return i
		}
	}
	return -1
}

func Example_constraints() {
	fmt.Println(MaxOf(3, 9, 2), MaxOf("pear", "apple"), MaxOf(1.5, -2.0))
	fmt.Println(IndexOf([]string{"a", "b", "c"}, "c"))

	// Output:
	// 9 pear 1.5
	// 2
}
```

Local command:

```sh
go test -run Example_constraints -v ./examples/m04/generics
```



| Constraint | Allows | Operations you can use |
|---|---|---|
| `any` | every type | assign, pass, return; no operators |
| `comparable` | types usable with `==` | `==`, `!=`, map keys |
| `cmp.Ordered` | integers, floats, strings | `<`, `<=`, `>`, `>=`, plus `==` |
| an interface with methods | types having those methods | call those methods |
| a type union | the listed types | operators all of them support |

Choose the **loosest** constraint that lets the function do its job. `IndexOf` only needs `==`, so it uses `comparable`, and callers can use it with structs. `MaxOf` needs `>`, so it requires `cmp.Ordered`.

### Type unions and `~`



Source: `examples/m04/generics/generics_test.go`

```go
// Number is a constraint made of a type union. The ~ means "any type
// whose underlying type is", so named types like Celsius qualify too.
type Number interface {
	~int | ~int64 | ~float64
}

func Sum[T Number](nums ...T) T {
	var total T // the zero value of whatever T is
	for _, n := range nums {
		total += n
	}
	return total
}

type Celsius float64

func Example_typeUnions() {
	fmt.Println(Sum(1, 2, 3))
	fmt.Println(Sum(Celsius(20.5), Celsius(1.5)))

	// Output:
	// 6
	// 22
}
```

Local command:

```sh
go test -run Example_typeUnions -v ./examples/m04/generics
```



- `int | int64 | float64` is a **type union**: T must be one of those types, and you can use operators they all support (here `+`).
- `~float64` means "**any type whose underlying type is** `float64`". Without the tilde, `Celsius` would not be allowed, even though it is a `float64` underneath.
- Interfaces containing unions can only be used as constraints, not as ordinary variable types.

The `cmp.Ordered` constraint in the standard library is built exactly this way, as a union of `~int`, `~int8`, ..., `~float64` and `~string`.

### Method constraints



Source: `examples/m04/generics/generics_test.go`

```go
// A constraint can require methods too, not just types.
type Named interface {
	Name() string
}

type User struct{ name string }

func (u User) Name() string { return u.name }

func JoinNames[T Named](items []T) string {
	names := Map(items, func(v T) string { return v.Name() })
	return strings.Join(names, ", ")
}

func Example_methodConstraint() {
	fmt.Println(JoinNames([]User{{"ana"}, {"bo"}}))

	// Output:
	// ana, bo
}
```

Local command:

```sh
go test -run Example_methodConstraint -v ./examples/m04/generics
```



Notice how `JoinNames` calls `Map` with a function on `T`: generic functions compose.

## Generic types

Types can have type parameters too. Methods on a generic type use the type's parameters (written in the receiver as `Stack[T]`):



Source: `examples/m04/generics/generics_test.go`

```go
// Stack is a generic type: the element type is a parameter.
type Stack[T any] struct {
	items []T
}

func (s *Stack[T]) Push(v T) { s.items = append(s.items, v) }

// Pop returns the top element, or the zero value and false if empty.
func (s *Stack[T]) Pop() (T, bool) {
	var zero T
	if len(s.items) == 0 {
		return zero, false
	}
	v := s.items[len(s.items)-1]
	s.items = s.items[:len(s.items)-1]
	return v, true
}

func (s *Stack[T]) Len() int { return len(s.items) }

func Example_genericType() {
	var words Stack[string]
	words.Push("first")
	words.Push("second")
	top, _ := words.Pop()
	fmt.Println(top, words.Len())

	var nums Stack[int]
	_, ok := nums.Pop()
	fmt.Println(ok)

	// Output:
	// second 1
	// false
}
```

Local command:

```sh
go test -run Example_genericType -v ./examples/m04/generics
```



`var zero T` is how you get the zero value of a type parameter. It is needed whenever a generic function must return "nothing", as in `Pop` on an empty stack.

You must instantiate a generic type with concrete type arguments before using it: `Stack[string]`, `Stack[int]`. A `Stack[string]` and a `Stack[int]` are different, unrelated types.

## How generics compile

Go compiles generic code using a mix of specialization and runtime dictionaries (called "GC shape stenciling"). You do not need the details, but two consequences are worth knowing:

- Generic code is fully type checked at compile time. There are no runtime type errors from generics.
- Generic code is usually as fast as hand-written code, but not always. In hot paths, measure (Module 10) before assuming.

## Common mistakes

### Constraints that are too strict

`func Contains[T cmp.Ordered]` when you only use `==`. Callers cannot use it with structs or pointers. Use `comparable`.

### Forgetting `~` for named types

`Sum[T int | float64]` rejects `Celsius` and `time.Duration`. Add `~` unless you deliberately want only the exact types.

### Making everything generic

A function used with exactly one type does not need type parameters. Lesson 4.7 covers when generics hurt more than they help.

### Expecting methods to add new type parameters (before Go 1.27)

Until Go 1.27, methods could only use the type parameters of their receiver type. Lesson 4.7 covers the new generic methods.

## Exercise



## Exercise: 4.6 Generics: type parameters and constraints

Build a generic `Set[T comparable]` with `New`, `Add`, `Has`, `Len` and `Union`, plus a function `Sorted[T cmp.Ordered]`. Think about why `Sorted` is a function rather than a method: the set only requires `comparable`, but sorting needs ordering. The tests use strings, ints and a struct type.

### Starter

```go
//go:build !solution

// Package set practices generics: a generic type, generic methods
// on it, and functions whose constraints are stricter than the type's.
package set

import "cmp"

// Set is an unordered collection of unique values.
// The zero value is NOT ready to use; create one with New.
type Set[T comparable] struct {
	// TODO: add the fields you need.
}

// New returns a set containing items.
func New[T comparable](items ...T) *Set[T] {
	// TODO: implement me.
	return &Set[T]{}
}

// Add inserts v. Adding a value that is already present does nothing.
func (s *Set[T]) Add(v T) {
	// TODO: implement me.
}

// Has reports whether v is in the set.
func (s *Set[T]) Has(v T) bool {
	// TODO: implement me.
	return false
}

// Len returns the number of values in the set.
func (s *Set[T]) Len() int {
	// TODO: implement me.
	return 0
}

// Union returns a NEW set with every value from s and other.
// Neither s nor other is modified.
func (s *Set[T]) Union(other *Set[T]) *Set[T] {
	// TODO: implement me.
	return nil
}

// Sorted returns the values of s in ascending order. It is a function,
// not a method, because it needs a stricter constraint (cmp.Ordered)
// than the Set type itself (comparable).
func Sorted[T cmp.Ordered](s *Set[T]) []T {
	// TODO: implement me.
	return nil
}
```

```sh
cd exercises
go test ./m04/set/
```

### Reference solution — try the exercise first

```go
//go:build solution

// Package set practices generics: a generic type, generic methods
// on it, and functions whose constraints are stricter than the type's.
package set

import (
	"cmp"
	"maps"
	"slices"
)

// Set is an unordered collection of unique values.
type Set[T comparable] struct {
	m map[T]struct{}
}

// New returns a set containing items.
func New[T comparable](items ...T) *Set[T] {
	s := &Set[T]{m: make(map[T]struct{}, len(items))}
	for _, v := range items {
		s.Add(v)
	}
	return s
}

// Add inserts v.
func (s *Set[T]) Add(v T) { s.m[v] = struct{}{} }

// Has reports whether v is in the set.
func (s *Set[T]) Has(v T) bool {
	_, ok := s.m[v]
	return ok
}

// Len returns the number of values in the set.
func (s *Set[T]) Len() int { return len(s.m) }

// Union returns a new set with every value from s and other.
func (s *Set[T]) Union(other *Set[T]) *Set[T] {
	out := &Set[T]{m: maps.Clone(s.m)}
	for v := range other.m {
		out.Add(v)
	}
	return out
}

// Sorted returns the values of s in ascending order.
func Sorted[T cmp.Ordered](s *Set[T]) []T {
	return slices.Sorted(maps.Keys(s.m))
}
```

```sh
go test -tags solution ./m04/set/
```



## Key takeaways

- Type parameters go in square brackets; the compiler usually infers type arguments.
- Constraints are interfaces that restrict types and enable operations: `any`, `comparable`, `cmp.Ordered`, method sets and type unions.
- `~T` includes all types whose underlying type is `T`.
- Generic types like `Stack[T]` must be instantiated, and `var zero T` gives a zero value.
- Pick the loosest constraint that works.

## Further reading

- [Tutorial: Getting started with generics](https://go.dev/doc/tutorial/generics)
- [An Introduction To Generics](https://go.dev/blog/intro-generics) on the Go blog
- [Type parameter declarations](https://go.dev/ref/spec#Type_parameter_declarations) in the spec
- [Package cmp](https://pkg.go.dev/cmp)
