# 4.2 Interfaces: implicit satisfaction and small interfaces

How Go interfaces are satisfied without declarations, why small interfaces are better, how method sets decide what satisfies what, and how interfaces compose.

## What you will learn

- How an interface is defined and satisfied, with no `implements` keyword
- Why small interfaces lead to better designs, and how they make testing easy
- What an interface value contains
- How **method sets** decide whether `T` or only `*T` satisfies an interface
- How to compose interfaces and check satisfaction at compile time

## The idea

An interface is a **set of method signatures**. Any type that has all of those methods satisfies the interface, automatically. There is no declaration like `class Rect implements Shape`.



Source: `examples/m04/interfaces/interfaces_test.go`

```go
// Shape is satisfied by any type that has these two methods.
type Shape interface {
	Area() float64
	Perimeter() float64
}

type Rect struct{ W, H float64 }

func (r Rect) Area() float64      { return r.W * r.H }
func (r Rect) Perimeter() float64 { return 2 * (r.W + r.H) }

type Circle struct{ R float64 }

func (c Circle) Area() float64      { return math.Pi * c.R * c.R }
func (c Circle) Perimeter() float64 { return 2 * math.Pi * c.R }

// No "implements" keyword anywhere: Rect and Circle simply have
// the right methods.

func totalArea(shapes ...Shape) float64 {
	var sum float64
	for _, s := range shapes {
		sum += s.Area()
	}
	return sum
}

func Example_implicitSatisfaction() {
	fmt.Printf("%.2f\n", totalArea(Rect{2, 3}, Circle{1}))

	// Output:
	// 9.14
}
```

Local command:

```sh
go test -run Example_implicitSatisfaction -v ./examples/m04/interfaces
```



This has a big consequence: **the code that uses an interface can define it, without the implementations knowing about it.** You can write an interface that a type from the standard library, or from a third party package, already satisfies. Producers and consumers stay decoupled.

## Small interfaces

The most useful interfaces in Go have one or two methods: `io.Reader`, `io.Writer`, `fmt.Stringer`, `error`, `http.Handler`. The Go proverb says it directly: *the bigger the interface, the weaker the abstraction.*



Source: `examples/m04/interfaces/interfaces_test.go`

```go
// Small interfaces are easy to satisfy and easy to fake in tests.
type Notifier interface {
	Notify(msg string) error
}

type EmailNotifier struct{ To string }

func (e EmailNotifier) Notify(msg string) error {
	fmt.Println("email to", e.To+":", msg)
	return nil
}

// recorder is a test double: no network, just memory.
type recorder struct{ sent []string }

func (r *recorder) Notify(msg string) error {
	r.sent = append(r.sent, msg)
	return nil
}

func alertOnHighLoad(n Notifier, load float64) {
	if load > 0.9 {
		n.Notify(fmt.Sprintf("load is %.0f%%", load*100))
	}
}

func Example_smallInterfaces() {
	alertOnHighLoad(EmailNotifier{To: "oncall@example.com"}, 0.95)

	rec := &recorder{}
	alertOnHighLoad(rec, 0.5)
	alertOnHighLoad(rec, 0.99)
	fmt.Println(rec.sent)

	// Output:
	// email to oncall@example.com: load is 95%
	// [load is 99%]
}
```

Local command:

```sh
go test -run Example_smallInterfaces -v ./examples/m04/interfaces
```



Because `alertOnHighLoad` only asks for something that can `Notify`, a test can pass a tiny in-memory recorder instead of a real email sender. No mocking framework needed. This is the main way Go code is made testable.

By convention, one-method interfaces are named after the method plus `-er`: `Reader`, `Writer`, `Notifier`, `Closer`, `Stringer`.

## Interface values

An interface value holds two things: the **dynamic type** of the value stored in it, and the **value** itself.



Source: `examples/m04/interfaces/interfaces_test.go`

```go
func Example_interfaceValues() {
	var s Shape // nil interface: no type, no value
	fmt.Println(s == nil)

	s = Rect{1, 2}
	fmt.Printf("%T %v\n", s, s) // dynamic type and value

	s = Circle{3}
	fmt.Printf("%T %v\n", s, s)

	// Output:
	// true
	// interfaces.Rect {1 2}
	// interfaces.Circle {3}
}
```

Local command:

```sh
go test -run Example_interfaceValues -v ./examples/m04/interfaces
```



When you call a method on an interface value, Go looks up the method for the dynamic type and calls it. An interface with no type and no value is `nil`, and calling a method on it panics. Lesson 4.4 looks at the tricky case where the type is set but the value is a nil pointer.

## Method sets: `T` vs `*T`

Which methods does a type have, for the purpose of satisfying an interface?

| Type | Method set |
|---|---|
| `T` (a value) | methods with **value** receivers |
| `*T` (a pointer) | methods with value receivers **and** pointer receivers |

So if any method in an interface is implemented with a pointer receiver, only a **pointer** satisfies that interface:



Source: `examples/m04/interfaces/interfaces_test.go`

```go
type Resetter interface{ Reset() }

type Buffer struct{ data []string }

// Reset has a pointer receiver, so only *Buffer has it in its
// method set. A Buffer value does not satisfy Resetter.
func (b *Buffer) Reset() { b.data = b.data[:0] }

// Compile-time check: fails to build if *Buffer stops satisfying it.
var _ Resetter = (*Buffer)(nil)

func Example_methodSets() {
	b := &Buffer{data: []string{"x"}}
	var r Resetter = b // fine: *Buffer has Reset
	// var r2 Resetter = Buffer{} would not compile:
	// Buffer does not implement Resetter (method Reset has pointer receiver)
	r.Reset()
	fmt.Println(len(b.data))

	// Output:
	// 0
}
```

Local command:

```sh
go test -run Example_methodSets -v ./examples/m04/interfaces
```



Why the asymmetry? A value stored in an interface is a copy that is not addressable, so Go could not take its address to call a pointer method. Methods that modify state need a pointer, and that requirement carries over to interfaces.

The line `var _ Resetter = (*Buffer)(nil)` is a **compile-time assertion**. It costs nothing at run time, and the build fails if `*Buffer` ever stops satisfying `Resetter`. Use it when a type is meant to implement an interface but nothing in the package would otherwise prove it.

## Composing interfaces

Interfaces can embed other interfaces, combining their method sets:



Source: `examples/m04/interfaces/interfaces_test.go`

```go
type Reader interface{ Read() string }
type Writer interface{ Write(s string) }

// ReadWriter embeds two interfaces: it requires both method sets.
type ReadWriter interface {
	Reader
	Writer
}

type memFile struct{ sb strings.Builder }

func (m *memFile) Read() string   { return m.sb.String() }
func (m *memFile) Write(s string) { m.sb.WriteString(s) }

func Example_embeddedInterfaces() {
	var rw ReadWriter = &memFile{}
	rw.Write("hello ")
	rw.Write("gopher")
	fmt.Println(rw.Read())

	// Output:
	// hello gopher
}
```

Local command:

```sh
go test -run Example_embeddedInterfaces -v ./examples/m04/interfaces
```



The standard library does this throughout `io`: `io.ReadWriter`, `io.ReadCloser`, `io.ReadWriteCloser`. Build big interfaces from small ones, and let functions ask for only the small piece they need.

## Where to define interfaces

Define an interface **in the package that uses it**, not next to the implementation. A storage package should export a concrete `*PostgresStore`. The service that needs storage declares the two or three methods it actually calls. Lesson 4.8 develops this into the rule "accept interfaces, return structs".

Do not create an interface until you have a reason: a second implementation, a test double, or a function that should accept several types. An interface with exactly one implementation and no tests using it is usually just indirection.

## Common mistakes

### Large "god" interfaces

A `UserRepository` interface with 20 methods is hard to implement, hard to fake and couples every caller to all 20. Split it, or let each consumer declare what it uses.

### Defining interfaces on the producer side

Exporting `type Store interface` next to `type store struct` (and returning the interface) prevents callers from using any method you did not put in the interface. Return the concrete type.

### Forgetting the pointer when satisfying an interface

`cannot use b (variable of struct type Buffer) as Resetter value in variable declaration: Buffer does not implement Resetter (method Reset has pointer receiver)`. Pass `&b`.

### Pointers to interfaces

`*io.Reader` is almost never what you want. An interface value already holds a pointer when the dynamic type is a pointer. Pass interfaces by value.

## Exercise



## Exercise: 4.2 Interfaces: implicit satisfaction and small interfaces

Implement `MemStore`, then two **decorators**: `Prefixed`, which namespaces keys, and `Counting`, which records hits, misses and sets. Both wrap any `Store`, so the last test stacks them on top of each other. Decide which receivers need to be pointers.

### Starter

```go
//go:build !solution

// Package kv practices interfaces: one small interface, several
// implementations, and decorators that wrap any implementation.
package kv

// Store is a minimal key-value store.
type Store interface {
	Get(key string) (value string, ok bool)
	Set(key, value string)
}

// MemStore is an in-memory Store. Its zero value is NOT ready to use;
// create one with NewMemStore.
type MemStore struct {
	// TODO: add the fields you need.
}

// NewMemStore returns an empty, ready to use MemStore.
func NewMemStore() *MemStore {
	// TODO: implement me.
	return &MemStore{}
}

// Get returns the value for key and whether it was present.
func (m *MemStore) Get(key string) (string, bool) {
	// TODO: implement me.
	return "", false
}

// Set stores value under key, replacing any previous value.
func (m *MemStore) Set(key, value string) {
	// TODO: implement me.
}

// Prefixed wraps another Store and adds Prefix to every key, so
// several users can share one Store without key collisions.
//
//	p := Prefixed{Prefix: "user:", Inner: mem}
//	p.Set("1", "ana") // stores "user:1" in mem
type Prefixed struct {
	Prefix string
	Inner  Store
}

// Get looks up Prefix+key in the inner store.
func (p Prefixed) Get(key string) (string, bool) {
	// TODO: implement me.
	return "", false
}

// Set stores value under Prefix+key in the inner store.
func (p Prefixed) Set(key, value string) {
	// TODO: implement me.
}

// Counting wraps another Store and counts calls to Get and Set.
// A Get counts as a Hit when the key was present and a Miss otherwise.
type Counting struct {
	Inner              Store
	Hits, Misses, Sets int
}

// Get forwards to Inner and records a hit or a miss.
func (c *Counting) Get(key string) (string, bool) {
	// TODO: implement me.
	return "", false
}

// Set forwards to Inner and counts the call.
func (c *Counting) Set(key, value string) {
	// TODO: implement me.
}
```

```sh
cd exercises
go test ./m04/kv/
```

### Reference solution — try the exercise first

```go
//go:build solution

// Package kv practices interfaces: one small interface, several
// implementations, and decorators that wrap any implementation.
package kv

// Store is a minimal key-value store.
type Store interface {
	Get(key string) (value string, ok bool)
	Set(key, value string)
}

// MemStore is an in-memory Store.
type MemStore struct {
	data map[string]string
}

// NewMemStore returns an empty, ready to use MemStore.
func NewMemStore() *MemStore {
	return &MemStore{data: make(map[string]string)}
}

// Get returns the value for key and whether it was present.
func (m *MemStore) Get(key string) (string, bool) {
	v, ok := m.data[key]
	return v, ok
}

// Set stores value under key.
func (m *MemStore) Set(key, value string) { m.data[key] = value }

// Prefixed wraps another Store and adds Prefix to every key.
type Prefixed struct {
	Prefix string
	Inner  Store
}

// Get looks up Prefix+key in the inner store.
func (p Prefixed) Get(key string) (string, bool) { return p.Inner.Get(p.Prefix + key) }

// Set stores value under Prefix+key in the inner store.
func (p Prefixed) Set(key, value string) { p.Inner.Set(p.Prefix+key, value) }

// Counting wraps another Store and counts calls to Get and Set.
type Counting struct {
	Inner              Store
	Hits, Misses, Sets int
}

// Get forwards to the inner store and records a hit or a miss.
func (c *Counting) Get(key string) (string, bool) {
	v, ok := c.Inner.Get(key)
	if ok {
		c.Hits++
	} else {
		c.Misses++
	}
	return v, ok
}

// Set forwards to the inner store and records the call.
func (c *Counting) Set(key, value string) {
	c.Sets++
	c.Inner.Set(key, value)
}
```

```sh
go test -tags solution ./m04/kv/
```



## Key takeaways

- A type satisfies an interface by having its methods; there is no `implements`.
- Keep interfaces small, often a single method, named with `-er`.
- An interface value holds a dynamic type and a value.
- `*T` has both value and pointer methods; `T` only value methods. Pointer-receiver methods mean only `*T` satisfies.
- Define interfaces where they are used, and check satisfaction with `var _ I = (*T)(nil)`.

## Further reading

- [Interface types](https://go.dev/ref/spec#Interface_types) and [Method sets](https://go.dev/ref/spec#Method_sets) in the spec
- [Effective Go: Interfaces](https://go.dev/doc/effective_go#interfaces)
- [Go Proverbs](https://go-proverbs.github.io/), including "The bigger the interface, the weaker the abstraction"
- [Go FAQ: Why doesn't Go have "implements" declarations?](https://go.dev/doc/faq#implements_interface)
