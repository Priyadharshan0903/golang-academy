# 4. Methods, interfaces and generics

This module is where Go's design really shows. There are no classes and no inheritance; instead you have **methods** on any named type, **interfaces** that are satisfied implicitly, and **generics** for code that works across types. Together they replace most of what class hierarchies do in other languages, with less coupling.

**Time:** about 4 hours, plus exercises.

- [4.1 Methods: value vs pointer receivers](01-methods.md)
- [4.2 Interfaces: implicit satisfaction and small interfaces](02-interfaces.md)
- [4.3 The empty interface, any, type assertions and type switches](03-any-and-type-switches.md)
- [4.4 Nil interfaces vs interfaces holding nil](04-nil-interfaces.md)
- [4.5 Common standard interfaces](05-standard-interfaces.md)
- [4.6 Generics: type parameters and constraints](06-generics.md)
- [4.7 Generic methods (Go 1.27) and when generics are the wrong tool](07-generic-methods.md)
- [4.8 Designing APIs: accept interfaces, return structs](08-api-design.md)
