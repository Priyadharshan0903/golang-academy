# 14. CLIs and tooling

Go is the language of command-line tools: `kubectl`, `docker`, `terraform`, `gh` and `hugo` are all Go programs. A single static binary that starts instantly, cross-compiles to every platform with one environment variable, and needs no runtime installed: that is hard to beat for tools.

This module covers what makes a CLI pleasant to use and easy to ship: a clear command structure, sensible configuration, generated code where it saves effort, and releases people can trust. It ends with **shortctl**, a client for the shortener API.

**Time:** about 3 to 4 hours, plus the exercise and project.

- [14.1 flag vs Cobra](01-flag-and-cobra.md)
- [14.2 Configuration for CLIs: files, environment and flags](02-configuration.md)
- [14.3 Code generation with go generate](03-go-generate.md)
- [14.4 Releasing binaries](04-releasing.md)
- [14.5 Exercise: a to-do CLI](05-exercise.md)
- [14.6 Project: shortctl, a CLI for the shortener](06-project-shortctl.md)
