# 14.2 Configuration for CLIs: files, environment and flags

Give a CLI layered configuration with a predictable order of precedence: defaults, a config file in the user's config directory, environment variables and flags, using flag.Visit to know which flags were actually set.

## What you will learn

- The standard order of precedence for CLI configuration
- Where config files belong: `os.UserConfigDir`
- Telling "flag not given" apart from "flag given with its default value" with `flag.Visit`
- Strict config files that reject typos
- Showing users where each setting came from

## The idea

A service gets its configuration from the environment (lesson 12.4). A CLI is used by people, interactively and in scripts, so it usually accepts several sources, each overriding the previous one:

```text
defaults  <  config file  <  environment variables  <  command-line flags
```

The logic: the config file holds a user's long-term preferences, environment variables adjust them for a shell session or a CI job, and a flag is the most specific, deliberate choice for one run. `git`, `kubectl`, `aws` and most well-behaved tools follow this order.

## The loader



Source: `examples/m14/layered/layered.go`

```go
// Config is the effective configuration of a CLI called shortctl.
type Config struct {
	Server  string        // base URL of the API
	Timeout time.Duration // per request
	Output  string        // "text" or "json"
	Source  map[string]string
}

// fileConfig is the JSON config file. Pointers tell "not set" apart
// from "set to the zero value".
type fileConfig struct {
	Server  *string `json:"server"`
	Timeout *string `json:"timeout"`
	Output  *string `json:"output"`
}

// Env abstracts the outside world so tests can control it.
type Env struct {
	Getenv    func(string) string
	ReadFile  func(string) ([]byte, error)
	ConfigDir func() (string, error) // os.UserConfigDir in real use
}

// OS is the real environment.
var OS = Env{Getenv: os.Getenv, ReadFile: os.ReadFile, ConfigDir: os.UserConfigDir}

// Load resolves the configuration. Later sources override earlier ones:
//
//	defaults < config file < environment variables < flags
//
// It returns the remaining positional arguments.
func Load(args []string, env Env) (Config, []string, error) {
	cfg := Config{Server: "http://localhost:8080", Timeout: 10 * time.Second, Output: "text",
		Source: map[string]string{"server": "default", "timeout": "default", "output": "default"}}

	fs := flag.NewFlagSet("shortctl", flag.ContinueOnError)
	configPath := fs.String("config", "", "config file (default: $SHORTCTL_CONFIG or <user config dir>/shortctl/config.json)")
	server := fs.String("server", "", "API base URL")
	timeout := fs.Duration("timeout", 0, "request timeout")
	output := fs.String("output", "", "output format: text or json")
	if err := fs.Parse(args); err != nil {
		return cfg, nil, err
	}

	// 1. The config file, if there is one.
	if err := cfg.applyFile(*configPath, env); err != nil {
		return cfg, nil, err
	}

	// 2. Environment variables.
	for name, apply := range map[string]func(string) error{
		"SHORTCTL_SERVER":  func(v string) error { cfg.Server = v; return nil },
		"SHORTCTL_TIMEOUT": func(v string) (err error) { cfg.Timeout, err = time.ParseDuration(v); return },
		"SHORTCTL_OUTPUT":  func(v string) error { cfg.Output = v; return nil },
	} {
		if v := env.Getenv(name); v != "" {
			if err := apply(v); err != nil {
				return cfg, nil, fmt.Errorf("%s: %w", name, err)
			}
			cfg.Source[keyOf(name)] = "env " + name
		}
	}

	// 3. Flags, but only those given on the command line. fs.Visit
	// visits exactly the flags that were set, so a flag's default
	// never overrides the file or the environment.
	fs.Visit(func(f *flag.Flag) {
		switch f.Name {
		case "server":
			cfg.Server = *server
		case "timeout":
			cfg.Timeout = *timeout
		case "output":
			cfg.Output = *output
		default:
			return
		}
		cfg.Source[f.Name] = "flag -" + f.Name
	})

	if cfg.Output != "text" && cfg.Output != "json" {
		return cfg, nil, fmt.Errorf("output must be text or json, got %q (from %s)", cfg.Output, cfg.Source["output"])
	}
	return cfg, fs.Args(), nil
}
```



The interesting line is **`fs.Visit`**. A flag's default value cannot be told apart from a value the user typed by looking at the variable: if `-timeout` defaults to `0` and the environment says `5s`, did the user type `-timeout 0`? `fs.Visit` calls its function only for flags that were **set on the command line**, while `fs.VisitAll` visits all of them. Applying flags inside `Visit` means an unset flag never overrides the file or the environment.

That is also why the flags are declared with empty defaults, and the real defaults live in the `Config` literal: the help text explains them in words instead.

## The config file



Source: `examples/m14/layered/layered.go`

```go
func (cfg *Config) applyFile(path string, env Env) error {
	explicit := path != ""
	if !explicit {
		path = env.Getenv("SHORTCTL_CONFIG")
		explicit = path != ""
	}
	if !explicit {
		dir, err := env.ConfigDir()
		if err != nil {
			return nil // no config directory on this system: skip the file
		}
		path = filepath.Join(dir, "shortctl", "config.json")
	}

	b, err := env.ReadFile(path)
	if errors.Is(err, fs.ErrNotExist) && !explicit {
		return nil // the default file is optional; an explicit one is not
	}
	if err != nil {
		return err
	}

	var fc fileConfig
	dec := json.NewDecoder(bytes.NewReader(b))
	dec.DisallowUnknownFields() // a typo in a key should be an error, not ignored
	if err := dec.Decode(&fc); err != nil {
		return fmt.Errorf("%s: %w", path, err)
	}
	src := "file " + path
	if fc.Server != nil {
		cfg.Server, cfg.Source["server"] = *fc.Server, src
	}
	if fc.Timeout != nil {
		d, err := time.ParseDuration(*fc.Timeout)
		if err != nil {
			return fmt.Errorf("%s: timeout: %w", path, err)
		}
		cfg.Timeout, cfg.Source["timeout"] = d, src
	}
	if fc.Output != nil {
		cfg.Output, cfg.Source["output"] = *fc.Output, src
	}
	return nil
}
```



- **Location.** `os.UserConfigDir()` returns the platform's convention: `$XDG_CONFIG_HOME` or `~/.config` on Linux, `~/Library/Application Support` on macOS, `%AppData%` on Windows. Put files in a subdirectory named after the tool.
- **Optional, unless asked for.** A missing default file is normal. A missing file the user named explicitly (with `-config` or `SHORTCTL_CONFIG`) is an error.
- **Pointers for "not set".** `*string` fields distinguish a key that is absent from a key set to `""`.
- **Strict.** `DisallowUnknownFields` turns `"sever": "..."` into an error instead of a silently ignored setting.

JSON keeps this dependency-free. Many tools prefer YAML or TOML for config files people edit by hand, which need a third party package; the layering logic is the same.

## Precedence, demonstrated



Source: `examples/m14/layered/layered_test.go`

```go
func ExampleLoad() {
	files := map[string]string{
		"/home/ada/.config/shortctl/config.json": `{"server": "https://sho.rt", "timeout": "3s"}`,
	}
	env := fakeEnv(map[string]string{"SHORTCTL_TIMEOUT": "5s"}, files)

	cfg, args, err := Load([]string{"-output", "json", "create", "https://go.dev"}, env)
	if err != nil {
		fmt.Println(err)
		return
	}
	fmt.Printf("server  = %-14s from %s\n", cfg.Server, cfg.Source["server"])
	fmt.Printf("timeout = %-14s from %s\n", cfg.Timeout, cfg.Source["timeout"])
	fmt.Printf("output  = %-14s from %s\n", cfg.Output, cfg.Source["output"])
	fmt.Println("args   =", args)
	// Output:
	// server  = https://sho.rt from file /home/ada/.config/shortctl/config.json
	// timeout = 5s             from env SHORTCTL_TIMEOUT
	// output  = json           from flag -output
	// args   = [create https://go.dev]
}
```

Local command:

```sh
go test -v -run ExampleLoad ./examples/m14/layered
```



The file sets the server and a 3s timeout, the environment overrides the timeout to 5s, and a flag sets the output format. Recording the **source** of each value costs a few lines and saves a lot of confused debugging: a `shortctl config` command that prints this table is a feature users love ("why is it talking to staging?").

## Common mistakes

### Flag defaults overriding the environment

Applying every flag value, set or not, silently discards the file and environment. Use `fs.Visit`.

### Config files in the home directory root

`~/.mytoolrc` clutters home directories. Use `os.UserConfigDir()`.

### Ignoring unknown keys

Typos then do nothing, silently. Reject them.

### Secrets in flags

Command lines are visible to other users of the machine (`ps`) and saved in shell history. Read tokens from environment variables, files, or the OS keychain.

## Key takeaways

- Order sources as defaults < config file < environment < flags.
- Use `flag.Visit` to apply only the flags the user actually set.
- Keep config files in `os.UserConfigDir()`, optional by default, strict about unknown keys.
- Track where each setting came from, and say so in error messages.

## Further reading

- [Package flag: Visit](https://pkg.go.dev/flag#FlagSet.Visit)
- [os.UserConfigDir](https://pkg.go.dev/os#UserConfigDir)
- [XDG Base Directory Specification](https://specifications.freedesktop.org/basedir-spec/latest/)
