# 14.6 Project: shortctl, a CLI for the shortener

Build a command-line client for the shortener API: layered configuration, text or JSON output, problem details turned into clear errors, proper exit codes, and tests that run the real API in-process.

## The project

Services get command-line clients: `kubectl` for Kubernetes, `gh` for GitHub, `stripe` for Stripe. **shortctl** is the shortener's, and it uses every lesson of this module. It lives next to the server, in [`projects/shortener/cmd/shortctl`](https://github.com/Priyadharshan0903/gopath-academy/tree/main/projects/shortener/cmd/shortctl), so the two can share tests.

```text
$ shortctl create -code godoc https://go.dev/doc
http://localhost:8080/godoc

$ shortctl get godoc
http://localhost:8080/godoc -> https://go.dev/doc (created 2026-10-16 12:25 UTC)

$ shortctl -output json get godoc
{
  "code": "godoc",
  "url": "https://go.dev/doc",
  "short_url": "http://localhost:8080/godoc",
  "created_at": "2026-10-16T12:25:10.316877532Z"
}

$ shortctl create -code godoc https://go.dev; echo "exit $?"
shortctl: create "godoc": code already in use (HTTP 409)
exit 1

$ shortctl get; echo "exit $?"
shortctl: usage: get needs exactly one CODE
exit 2
```

That output is from a real run against the shortener service from Module 12.

## Try it

```bash
cd projects/shortener
go run ./cmd/shortener &                     # the API, in memory
go run ./cmd/shortctl create https://go.dev  # prints a short URL
go run ./cmd/shortctl -h
```

Point it at another server with `-server`, `SHORTCTL_SERVER`, or a config file at `<user config dir>/shortctl/config.json`:

```json
{"server": "https://sho.rt", "timeout": "5s"}
```

## The structure

`main` is three lines (lesson 14.1). `run` loads configuration, picks the command, and turns errors into exit codes in one place:



Source: `projects/shortener/cmd/shortctl/run.go`

```go
func run(ctx context.Context, args []string, e env, stdout, stderr io.Writer) int {
	cfg, rest, err := loadConfig(args, e, stderr)
	if errors.Is(err, flag.ErrHelp) {
		return exitOK
	}
	if err != nil {
		fmt.Fprintln(stderr, "shortctl:", err)
		return exitUsage
	}
	if len(rest) == 0 {
		usage(stderr)
		return exitUsage
	}

	c := &client{base: cfg.Server, http: &http.Client{Timeout: cfg.Timeout}}
	out := &printer{w: stdout, json: cfg.Output == "json"}

	switch rest[0] {
	case "create":
		err = cmdCreate(ctx, c, out, rest[1:], stderr)
	case "get":
		err = cmdGet(ctx, c, out, rest[1:])
	case "delete":
		if len(rest) != 2 {
			err = fmt.Errorf("%w: delete needs exactly one CODE", errUsage)
		} else if err = c.delete(ctx, rest[1]); err == nil {
			err = out.print(map[string]string{"deleted": rest[1]}, "deleted "+rest[1])
		}
	case "version":
		err = out.print(map[string]string{"version": version()}, version())
	default:
		err = fmt.Errorf("%w: unknown command %q", errUsage, rest[0])
	}

	switch {
	case err == nil, errors.Is(err, flag.ErrHelp):
		return exitOK
	case errors.Is(err, errUsage):
		fmt.Fprintln(stderr, "shortctl:", err)
		return exitUsage
	default:
		fmt.Fprintln(stderr, "shortctl:", err)
		return exitError
	}
}
```



Configuration (`config.go`) is the layered loader of lesson 14.2: defaults, then the config file, then `SHORTCTL_*` variables, then only the flags actually given, found with `fs.Visit`.

Output has two modes. **Text** is a single line for people; **JSON** (`-output json`) is for scripts, so `shortctl -output json get godoc | jq -r .url` works. Offering both is cheap with a small `printer` type, and it saves users from parsing text with `awk`.

## The API client



Source: `projects/shortener/cmd/shortctl/client.go`

```go
// client talks to the shortener API.
type client struct {
	base string
	http *http.Client
}

// apiError is an error response from the API (RFC 9457 problem details).
type apiError struct {
	Status int    `json:"status"`
	Title  string `json:"title"`
	Detail string `json:"detail"`
}

func (e *apiError) Error() string {
	if e.Detail != "" {
		return fmt.Sprintf("%s (HTTP %d)", e.Detail, e.Status)
	}
	return fmt.Sprintf("%s (HTTP %d)", e.Title, e.Status)
}

func (c *client) create(ctx context.Context, target, code string) (apiLink, error) {
	body, _ := json.Marshal(map[string]string{"url": target, "code": code})
	return c.do(ctx, http.MethodPost, "/api/links", body, http.StatusCreated)
}

func (c *client) get(ctx context.Context, code string) (apiLink, error) {
	return c.do(ctx, http.MethodGet, "/api/links/"+url.PathEscape(code), nil, http.StatusOK)
}

func (c *client) delete(ctx context.Context, code string) error {
	_, err := c.do(ctx, http.MethodDelete, "/api/links/"+url.PathEscape(code), nil, http.StatusNoContent)
	return err
}

func (c *client) do(ctx context.Context, method, path string, body []byte, want int) (apiLink, error) {
	req, err := http.NewRequestWithContext(ctx, method, strings.TrimSuffix(c.base, "/")+path, bytes.NewReader(body))
	if err != nil {
		return apiLink{}, err
	}
	if body != nil {
		req.Header.Set("Content-Type", "application/json")
	}
	req.Header.Set("Accept", "application/json")

	resp, err := c.http.Do(req)
	if err != nil {
		return apiLink{}, fmt.Errorf("cannot reach %s: %w", c.base, err)
	}
	defer resp.Body.Close()
	data, err := io.ReadAll(io.LimitReader(resp.Body, 1<<20))
	if err != nil {
		return apiLink{}, err
	}

	if resp.StatusCode != want {
		apiErr := &apiError{Status: resp.StatusCode, Title: http.StatusText(resp.StatusCode)}
		json.Unmarshal(data, apiErr) // best effort: keep the defaults if it is not JSON
		return apiLink{}, apiErr
	}
	var l apiLink
	if resp.StatusCode == http.StatusNoContent {
		return l, nil
	}
	if err := json.Unmarshal(data, &l); err != nil {
		return apiLink{}, fmt.Errorf("unexpected response from %s: %w", c.base, err)
	}
	return l, nil
}
```



Things to notice:

- **A timeout on the `http.Client`** (lesson 8.7), configurable, and the request carries the command's context, so Ctrl+C cancels a slow request.
- **Error responses are decoded.** The server answers errors with problem details (lesson 12.3), so the client shows the server's `detail`, `create "godoc": code already in use`, plus the status. If the body is not JSON (a proxy's HTML error page, say), it falls back to the status text.
- **The response body is limited** with `io.LimitReader`, so a misbehaving server cannot make the client read gigabytes.
- **Network errors say what was unreachable**: `cannot reach http://localhost:8080: ... connection refused`.
- **`url.PathEscape`** for the code in the path, even though the server validates codes: never build URLs from unescaped input.

## Testing against the real API



Source: `projects/shortener/cmd/shortctl/main_test.go`

```go
package main

import (
	"bytes"
	"context"
	"encoding/json"
	"io/fs"
	"log/slog"
	"net/http/httptest"
	"net/url"
	"strings"
	"testing"

	"github.com/Priyadharshan0903/gopath-academy/projects/shortener/internal/httpapi"
	"github.com/Priyadharshan0903/gopath-academy/projects/shortener/internal/link"
)

// newServer runs the real API handler with an in-memory store.
func newServer(t *testing.T) *httptest.Server {
	t.Helper()
	srv := httptest.NewServer(nil)
	base, _ := url.Parse(srv.URL)
	srv.Config.Handler = httpapi.New(httpapi.Options{
		Service: link.NewService(link.NewMemoryStore()),
		BaseURL: base,
		Logger:  slog.New(slog.DiscardHandler),
	})
	t.Cleanup(srv.Close)
	return srv
}

type result struct {
	code           int
	stdout, stderr string
}

func shortctl(t *testing.T, vars map[string]string, args ...string) result {
	t.Helper()
	e := env{
		getenv:    func(k string) string { return vars[k] },
		readFile:  func(string) ([]byte, error) { return nil, fs.ErrNotExist },
		configDir: func() (string, error) { return "/nonexistent", nil },
	}
	var out, errOut bytes.Buffer
	code := run(context.Background(), args, e, &out, &errOut)
	return result{code, out.String(), errOut.String()}
}

func TestCreateAndGet(t *testing.T) {
	srv := newServer(t)
	vars := map[string]string{"SHORTCTL_SERVER": srv.URL}

	r := shortctl(t, vars, "create", "-code", "godoc", "https://go.dev/doc")
	if r.code != 0 || r.stdout != srv.URL+"/godoc\n" {
		t.Fatalf("create: %+v", r)
	}
	r = shortctl(t, vars, "get", "godoc")
	if r.code != 0 || !strings.HasPrefix(r.stdout, srv.URL+"/godoc -> https://go.dev/doc (created ") {
		t.Fatalf("get: %+v", r)
	}
	r = shortctl(t, vars, "-output", "json", "get", "godoc")
	var l apiLink
	if err := json.Unmarshal([]byte(r.stdout), &l); err != nil || l.URL != "https://go.dev/doc" {
		t.Fatalf("get -output json: %+v (%v)", r, err)
	}
}

func TestDelete(t *testing.T) {
	srv := newServer(t)
	vars := map[string]string{"SHORTCTL_SERVER": srv.URL}
	shortctl(t, vars, "create", "-code", "temp", "https://go.dev")
	if r := shortctl(t, vars, "delete", "temp"); r.code != 0 || r.stdout != "deleted temp\n" {
		t.Fatalf("delete: %+v", r)
	}
	if r := shortctl(t, vars, "delete", "temp"); r.code != 1 || !strings.Contains(r.stderr, "HTTP 404") {
		t.Fatalf("second delete: %+v", r)
	}
}

func TestErrors(t *testing.T) {
	srv := newServer(t)
	vars := map[string]string{"SHORTCTL_SERVER": srv.URL}
	shortctl(t, vars, "create", "-code", "taken", "https://go.dev")

	tests := []struct {
		name   string
		args   []string
		code   int
		stderr string
	}{
		{"conflict", []string{"create", "-code", "taken", "https://go.dev"}, 1, `create "taken": code already in use (HTTP 409)`},
		{"not found", []string{"get", "nothere"}, 1, "link not found (HTTP 404)"},
		{"invalid url", []string{"create", "ftp://x"}, 1, "HTTP 422"},
		{"no command", nil, 2, "usage: shortctl"},
		{"unknown command", []string{"remove", "x"}, 2, `unknown command "remove"`},
		{"missing url", []string{"create"}, 2, "exactly one URL"},
		{"bad output", []string{"-output", "yaml", "get", "x"}, 2, "text or json"},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			r := shortctl(t, vars, tt.args...)
			if r.code != tt.code || !strings.Contains(r.stderr, tt.stderr) {
				t.Errorf("exit %d, stderr %q; want exit %d and %q", r.code, r.stderr, tt.code, tt.stderr)
			}
		})
	}
}

func TestServerDown(t *testing.T) {
	srv := newServer(t)
	srv.Close()
	r := shortctl(t, map[string]string{"SHORTCTL_SERVER": srv.URL}, "get", "abc")
	if r.code != 1 || !strings.Contains(r.stderr, "cannot reach") {
		t.Fatalf("%+v", r)
	}
}
```



The tests start the **real** HTTP handler from `internal/httpapi` with an in-memory store on an `httptest.Server`, and run shortctl's `run` against it. This tests the client and the server's contract together: if the API changes a field name or a status code, these tests fail. It is only possible because both live in one module; for a client in another repository, the same idea becomes a contract test against a recorded or shared specification.

## Version

`shortctl version` prints `debug.ReadBuildInfo().Main.Version`. Built with `go install github.com/Priyadharshan0903/gopath-academy/projects/shortener/cmd/shortctl@v1.0.0`, it prints `v1.0.0`; built from a tagged git checkout with Go 1.24 or later, it prints the tag (lesson 14.4). No `-ldflags` needed.

## Your turn

1. Add `shortctl open CODE`, which opens the target URL in the browser (`xdg-open`, `open` or `rundll32` depending on `runtime.GOOS`).
2. Add `shortctl config`, printing the effective configuration and where each value came from (lesson 14.2's `Source` map).
3. Add a `-quiet` flag that prints only the short URL, for use in scripts: `url=$(shortctl -quiet create https://go.dev)`.
4. Add `shortctl` to the greet project's release setup (lesson 14.4): a second build in `.goreleaser.yaml`.

## Module 14 recap

You can now build command-line tools that behave the way users and scripts expect, with the standard `flag` package or Cobra; configure them from files, environment and flags in a predictable order; generate code with pinned tools or your own generator; and ship reproducible, versioned binaries for every platform with GoReleaser.

Next is **[Module 15: Go for cloud native](../15-cloud-native/README.md)**, where the shortener goes into a container and onto Kubernetes, and you write Go that talks to Kubernetes itself.
