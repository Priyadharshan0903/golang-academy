# 14.5 Exercise: a to-do CLI

Build a small command-line tool from a specification: global flags, subcommands with their own flags, configuration from flag or environment, file storage, and correct exit codes.

## The task



## Exercise: 14.5 Exercise: a to-do CLI

Implement `Run` in `starter.go`: a to-do list with the subcommands `add`, `list` (with `-all`) and `done`, a global `-file` flag that falls back to `$TODO_FILE` and then `todo.json`, and the exit codes 0, 1 and 2 as specified. `load` and `save` in `store.go` handle the JSON file for you.

### Starter

```go
//go:build !solution

package todo

import "io"

// Run is the whole program; main would call
// os.Exit(Run(os.Args[1:], os.Getenv, os.Stdout, os.Stderr)).
//
// Usage:
//
//	todo [-file PATH] add TEXT...     add an item (the words are joined with spaces)
//	todo [-file PATH] list [-all]     print open items as "N. text"; -all also
//	                                  prints done items, as "N. [x] text"
//	todo [-file PATH] done N          mark item N (1-based, as printed by list) done
//
// The list lives in the -file flag's path; if the flag is not given, in
// $TODO_FILE; if that is empty too, in "todo.json".
//
// Exit codes: 0 on success, 1 for runtime errors (such as an unreadable
// file or an item number that does not exist), 2 for usage errors
// (unknown command, bad flags, missing or non-numeric arguments).
// Errors are printed to stderr, prefixed with "todo: ".
func Run(args []string, getenv func(string) string, stdout, stderr io.Writer) int {
	// TODO: implement me. load and save are in store.go.
	return 2
}
```

```sh
cd exercises
go test ./m14/todo/
```

### Reference solution — try the exercise first

```go
//go:build solution

package todo

import (
	"errors"
	"flag"
	"fmt"
	"io"
	"strconv"
	"strings"
)

var errUsage = errors.New("usage")

// Run is the whole program. See the starter for the specification.
func Run(args []string, getenv func(string) string, stdout, stderr io.Writer) int {
	err := run(args, getenv, stdout, stderr)
	switch {
	case err == nil, errors.Is(err, flag.ErrHelp):
		return 0
	case errors.Is(err, errUsage):
		fmt.Fprintln(stderr, "todo:", err)
		return 2
	default:
		fmt.Fprintln(stderr, "todo:", err)
		return 1
	}
}

func run(args []string, getenv func(string) string, stdout, stderr io.Writer) error {
	global := flag.NewFlagSet("todo", flag.ContinueOnError)
	global.SetOutput(stderr)
	file := global.String("file", "", "path of the list (default $TODO_FILE or todo.json)")
	if err := global.Parse(args); err != nil {
		return usage(err)
	}
	path := *file
	if path == "" {
		path = getenv("TODO_FILE")
	}
	if path == "" {
		path = "todo.json"
	}

	rest := global.Args()
	if len(rest) == 0 {
		return fmt.Errorf("%w: expected a command: add, list or done", errUsage)
	}
	cmd, cmdArgs := rest[0], rest[1:]

	items, err := load(path)
	if err != nil {
		return err
	}

	switch cmd {
	case "add":
		if len(cmdArgs) == 0 {
			return fmt.Errorf("%w: add needs some text", errUsage)
		}
		items = append(items, Item{Text: strings.Join(cmdArgs, " ")})
		if err := save(path, items); err != nil {
			return err
		}
		fmt.Fprintf(stdout, "added %d. %s\n", len(items), items[len(items)-1].Text)
		return nil

	case "list":
		fs := flag.NewFlagSet("list", flag.ContinueOnError)
		fs.SetOutput(stderr)
		all := fs.Bool("all", false, "include done items")
		if err := fs.Parse(cmdArgs); err != nil {
			return usage(err)
		}
		for i, it := range items {
			switch {
			case !it.Done:
				fmt.Fprintf(stdout, "%d. %s\n", i+1, it.Text)
			case *all:
				fmt.Fprintf(stdout, "%d. [x] %s\n", i+1, it.Text)
			}
		}
		return nil

	case "done":
		if len(cmdArgs) != 1 {
			return fmt.Errorf("%w: done needs exactly one item number", errUsage)
		}
		n, err := strconv.Atoi(cmdArgs[0])
		if err != nil {
			return fmt.Errorf("%w: %q is not a number", errUsage, cmdArgs[0])
		}
		if n < 1 || n > len(items) {
			return fmt.Errorf("no item %d (the list has %d)", n, len(items))
		}
		items[n-1].Done = true
		return save(path, items)

	default:
		return fmt.Errorf("%w: unknown command %q", errUsage, cmd)
	}
}

func usage(err error) error {
	if errors.Is(err, flag.ErrHelp) {
		return err
	}
	return fmt.Errorf("%w: %v", errUsage, err)
}
```

```sh
go test -tags solution ./m14/todo/
```



```bash
cd exercises
go test ./m14/todo
```

A session with the finished tool looks like this:

```text
$ todo add buy milk
added 1. buy milk
$ todo add write tests
added 2. write tests
$ todo done 2
$ todo list -all
1. buy milk
2. [x] write tests
$ todo done 7; echo "exit $?"
todo: no item 7 (the list has 2)
exit 1
$ todo remove 1; echo "exit $?"
todo: usage: unknown command "remove"
exit 2
```

## Hints



### Hint 1: two levels of flags

Parse the global flags with one `FlagSet`; `fs.Args()` then starts with the command name. Give `list` its own `FlagSet` for `-all`. Use `flag.ContinueOnError` everywhere so `Run` decides the exit code (lesson 14.1).





### Hint 2: one place for exit codes

Write an inner `run` that returns an `error`, wrap usage problems with a sentinel such as `errUsage`, and convert to an exit code once in `Run` with `errors.Is`. Do not forget `flag.ErrHelp`: `-h` is success.





### Hint 3: precedence

The `-file` flag wins over `$TODO_FILE`, which wins over `todo.json`. Since the flag's default is `""`, an empty value means "not given" here, so `fs.Visit` is not needed (lesson 14.2).



The reference solution is in `exercises/m14/todo/solution.go`. Notice how `save` in `store.go` writes a temporary file and renames it: a crash in the middle of saving can never leave a half-written list, because a rename within one directory is atomic.

## Going further

- Add `todo undo N` and `todo clear` (remove done items).
- Wire it to a real `main` package and try `go install` and `go version -m` on the result (lesson 14.4).
- Rewrite it with Cobra (lesson 14.1) and compare the amount of code.
