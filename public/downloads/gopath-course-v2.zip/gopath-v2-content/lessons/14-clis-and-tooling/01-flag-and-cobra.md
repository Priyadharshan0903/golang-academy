# 14.1 flag vs Cobra

Build command-line tools with subcommands using the standard flag package, handle files and standard input, use exit codes properly, make the whole program testable, and see what Cobra adds.

## What you will learn

- The conventions users expect from a command-line tool
- Subcommands with the standard `flag` package, one `FlagSet` per command
- Reading files or standard input, writing to stdout and stderr
- Exit codes, and how Ctrl+C should behave
- Testing a CLI completely, in-process
- What **Cobra** gives you, and when it is worth the dependency

## Conventions worth following

Unix tools agree on a few rules, and tools that follow them compose with everything else:

- **Results go to stdout, messages to stderr.** Then `tool | jq` works, and errors still reach the terminal.
- **Read the files named as arguments, or standard input if there are none.** Then `tool file.json` and `cat file.json | tool` both work.
- **Exit code 0 means success.** 1 is a general error; 2 is a usage error (the `flag` package exits with 2). Scripts check exit codes, not messages.
- **`-h` prints help**, and is not an error.
- **Ctrl+C stops promptly** and cleanly.

## The example: jsonq

`jsonq` is a small tool with three subcommands, built with only the standard library:

```bash
$ echo '{"name":"Ada","emails":["ada@example.com","countess@example.org"]}' | jsonq get -raw emails.1
countess@example.org
$ jsonq get -h
usage: jsonq get [flags] PATH [FILE...]
  -raw
    	print strings without quotes
```

### main is three lines



Source: `examples/m14/jsonq/main.go`

```go
// Command jsonq reads JSON and answers simple questions about it. It is
// the example program for lesson 14.1: subcommands with the standard
// flag package, input from files or standard input, and exit codes.
//
//	jsonq keys [-sort] [FILE...]
//	jsonq get [-raw] PATH [FILE...]
//	jsonq pretty [-indent N] [FILE...]
//
// With no FILE, jsonq reads standard input.
package main

import (
	"context"
	"os"
	"os/signal"
)

func main() {
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt)
	defer stop()
	os.Exit(run(ctx, os.Args[1:], os.Stdin, os.Stdout, os.Stderr))
}
```



`main` connects the program to the real process: a context cancelled by Ctrl+C, the real arguments and streams, and the exit code. Everything else is in `run`, which takes all of these as parameters. This is the same pattern as the greet CLI (lesson 1.8) and the shortener's `run` (lesson 12.8), and it is what makes the program testable.

### Subcommands



Source: `examples/m14/jsonq/run.go`

```go
// command is one subcommand: its flags and what it does.
type command struct {
	name    string
	summary string
	run     func(ctx context.Context, args []string, env *env) error
}

// env is what commands may touch. Tests provide buffers instead of the
// real standard streams.
type env struct {
	stdin          io.Reader
	stdout, stderr io.Writer
}

var commands = []command{
	{"keys", "print the top-level keys of each object", runKeys},
	{"get", "print the value at a dotted PATH, such as user.emails.0", runGet},
	{"pretty", "re-indent JSON", runPretty},
}

// errUsage marks errors that are the caller's fault (exit code 2).
var errUsage = errors.New("usage error")

func run(ctx context.Context, args []string, stdin io.Reader, stdout, stderr io.Writer) int {
	e := &env{stdin: stdin, stdout: stdout, stderr: stderr}
	if len(args) == 0 || args[0] == "-h" || args[0] == "-help" || args[0] == "help" {
		usage(stderr)
		return exitUsage
	}
	i := slices.IndexFunc(commands, func(c command) bool { return c.name == args[0] })
	if i < 0 {
		fmt.Fprintf(stderr, "jsonq: unknown command %q\n\n", args[0])
		usage(stderr)
		return exitUsage
	}

	err := commands[i].run(ctx, args[1:], e)
	switch {
	case err == nil:
		return exitOK
	case errors.Is(err, flag.ErrHelp):
		return exitOK // -h was requested and printed
	case errors.Is(err, errUsage):
		fmt.Fprintln(stderr, "jsonq:", err)
		return exitUsage
	default:
		fmt.Fprintln(stderr, "jsonq:", err)
		return exitError
	}
}

func usage(w io.Writer) {
	fmt.Fprintln(w, "usage: jsonq <command> [flags] [args]\n\ncommands:")
	for _, c := range commands {
		fmt.Fprintf(w, "  %-8s %s\n", c.name, c.summary)
	}
	fmt.Fprintln(w, "\nRun 'jsonq <command> -h' for the flags of a command.")
}
```



The `flag` package has no notion of subcommands, but you do not need one: look at `args[0]`, and give each command its own **`flag.FlagSet`**. A table of commands keeps dispatch and the usage message in one place.

Errors are classified once, at the top: wrapping `errUsage` marks errors that are the caller's fault (exit 2), anything else is a runtime error (exit 1), and `flag.ErrHelp` (the user asked for `-h`) is success.



Source: `examples/m14/jsonq/run.go`

```go
// newFlags returns a FlagSet that reports errors instead of exiting,
// and prints its usage to the command's stderr.
func newFlags(name string, e *env, argsHelp string) *flag.FlagSet {
	fs := flag.NewFlagSet(name, flag.ContinueOnError)
	fs.SetOutput(e.stderr)
	fs.Usage = func() {
		fmt.Fprintf(e.stderr, "usage: jsonq %s [flags] %s\n", name, argsHelp)
		fs.PrintDefaults()
	}
	return fs
}

func parse(fs *flag.FlagSet, args []string) error {
	err := fs.Parse(args)
	if err != nil && !errors.Is(err, flag.ErrHelp) {
		return fmt.Errorf("%w: %v", errUsage, err)
	}
	return err
}
```



`flag.ContinueOnError` makes `Parse` **return** errors instead of calling `os.Exit(2)` itself, which is what a testable program needs. `SetOutput` sends the flag package's messages to the command's stderr, and a custom `Usage` adds the positional arguments to the help text.

Note a limitation of `flag`: it stops parsing at the first non-flag argument. `jsonq get emails.1 -raw` treats `-raw` as a file name; flags must come first. Cobra (below) relaxes this.

### Files or standard input



Source: `examples/m14/jsonq/run.go`

```go
// eachDocument calls fn for every JSON value in the named files, or in
// standard input if there are none. A file may hold several values,
// one after another, like JSON Lines.
func eachDocument(ctx context.Context, files []string, e *env, fn func(name string, v any) error) error {
	if len(files) == 0 {
		return decodeAll(ctx, "stdin", e.stdin, fn)
	}
	for _, name := range files {
		f, err := os.Open(name)
		if err != nil {
			return err // already says which file
		}
		err = decodeAll(ctx, name, f, fn)
		f.Close()
		if err != nil {
			return err
		}
	}
	return nil
}

func decodeAll(ctx context.Context, name string, r io.Reader, fn func(string, any) error) error {
	dec := json.NewDecoder(r)
	dec.UseNumber() // keep numbers exactly as written
	for {
		if err := ctx.Err(); err != nil {
			return err // Ctrl+C stops between documents
		}
		var v any
		err := dec.Decode(&v)
		if errors.Is(err, io.EOF) {
			return nil
		}
		if err != nil {
			return fmt.Errorf("%s: invalid JSON: %w", name, err)
		}
		if err := fn(name, v); err != nil {
			return err
		}
	}
}
```



Reading through an `io.Reader` makes files and stdin the same thing (lesson 8.1). A `json.Decoder` reads value after value, so files with several JSON documents (JSON Lines) work for free. Checking `ctx.Err()` between documents makes Ctrl+C stop the tool cleanly in the middle of a large input.

## Testing the whole CLI



Source: `examples/m14/jsonq/run_test.go`

```go
func Example() {
	code, out, _ := jsonq(user, "keys", "-sort")
	fmt.Print(out)
	fmt.Println("exit", code)

	_, out, _ = jsonq(user, "get", "-raw", "emails.1")
	fmt.Print(out)

	code, _, errOut := jsonq(user, "get", "emails.5")
	fmt.Print(errOut)
	fmt.Println("exit", code)

	code, _, errOut = jsonq(user, "pretty", "-indent", "9")
	fmt.Print(errOut)
	fmt.Println("exit", code)
	// Output:
	// age
	// emails
	// name
	// exit 0
	// countess@example.org
	// jsonq: stdin: no index "5" in an array of 2
	// exit 1
	// jsonq: usage error: -indent must be between 0 and 8
	// exit 2
}
```

Local command:

```sh
go test -v -run Example ./examples/m14/jsonq
```



Because `run` takes its arguments, input and outputs as parameters, a test can execute the whole program in-process, many times per millisecond, and check exactly what a user would see: stdout, stderr and the exit code. No subprocess, no build step. The other tests cover help, unknown commands, missing files and cancellation.

## Cobra

`github.com/spf13/cobra` is the library behind `kubectl`, `docker`, `gh`, `hugo` and many more. Here are two of jsonq's commands in Cobra:



Source: `examples/thirdparty/clicobra/cli.go`

```go
// NewRootCmd builds the command tree. Building it in a function, not in
// package variables and init functions, lets every test get a fresh
// tree with its own input and output.
func NewRootCmd() *cobra.Command {
	root := &cobra.Command{
		Use:           "jsonq",
		Short:         "Answer simple questions about JSON",
		SilenceUsage:  true, // do not print usage for errors from RunE
		SilenceErrors: true, // the caller prints errors once
	}
	root.PersistentFlags().Bool("compact", false, "print JSON without indentation") // inherited by subcommands
	root.AddCommand(newKeysCmd(), newGetCmd())
	return root
}

func newKeysCmd() *cobra.Command {
	var sorted bool
	cmd := &cobra.Command{
		Use:   "keys",
		Short: "Print the top-level keys of an object read from stdin",
		Args:  cobra.NoArgs,
		RunE: func(cmd *cobra.Command, args []string) error {
			obj, err := readObject(cmd.InOrStdin())
			if err != nil {
				return err
			}
			keys := make([]string, 0, len(obj))
			for k := range obj {
				keys = append(keys, k)
			}
			if sorted {
				slices.Sort(keys)
			}
			fmt.Fprintln(cmd.OutOrStdout(), strings.Join(keys, "\n"))
			return nil
		},
	}
	cmd.Flags().BoolVarP(&sorted, "sort", "s", false, "sort the keys")
	return cmd
}

func newGetCmd() *cobra.Command {
	return &cobra.Command{
		Use:     "get KEY",
		Short:   "Print the value of a top-level key",
		Example: `  echo '{"name":"Ada"}' | jsonq get name`,
		Args:    cobra.ExactArgs(1),
		RunE: func(cmd *cobra.Command, args []string) error {
			obj, err := readObject(cmd.InOrStdin())
			if err != nil {
				return err
			}
			v, ok := obj[args[0]]
			if !ok {
				return fmt.Errorf("no key %q", args[0])
			}
			compact, _ := cmd.Flags().GetBool("compact")
			var b []byte
			if compact {
				b, err = json.Marshal(v)
			} else {
				b, err = json.MarshalIndent(v, "", "  ")
			}
			if err != nil {
				return err
			}
			fmt.Fprintln(cmd.OutOrStdout(), string(b))
			return nil
		},
	}
}
```



What you get, compared with `flag`:

- **A command tree**, with nested subcommands (`kubectl config set-context ...`).
- **POSIX-style flags** through `pflag`: `--long` and `-s` short forms, and flags allowed after positional arguments.
- **Persistent flags** inherited by subcommands (`--compact` here, `--namespace` in kubectl).
- **Argument validation** (`cobra.ExactArgs(1)`), and generated help and usage:

```text
Answer simple questions about JSON

Usage:
  jsonq [command]

Available Commands:
  completion  Generate the autocompletion script for the specified shell
  get         Print the value of a top-level key
  help        Help about any command
  keys        Print the top-level keys of an object read from stdin

Flags:
      --compact   print JSON without indentation
  -h, --help      help for jsonq
```

- **Shell completion** for bash, zsh, fish and PowerShell, generated: `jsonq completion bash`.

Two habits keep Cobra code testable. Build the tree in a **function** (`NewRootCmd`) instead of package-level variables wired up in `init`, so each test gets a fresh tree. And use `cmd.InOrStdin()`, `cmd.OutOrStdout()` and `RunE` (returning errors) rather than the global `os.Stdin`, `fmt.Println` and `os.Exit`:



Source: `examples/thirdparty/clicobra/cli_test.go`

```go
func execute(stdin string, args ...string) (string, error) {
	cmd := NewRootCmd()
	var out bytes.Buffer
	cmd.SetIn(strings.NewReader(stdin))
	cmd.SetOut(&out)
	cmd.SetErr(&out)
	cmd.SetArgs(args)
	err := cmd.Execute()
	return out.String(), err
}

func Example() {
	out, _ := execute(`{"b":{"x":[1,2]},"a":true}`, "keys", "-s")
	fmt.Print(out)
	out, _ = execute(`{"b":{"x":[1,2]},"a":true}`, "get", "b", "--compact")
	fmt.Print(out)
	_, err := execute(`{}`, "get")
	fmt.Println(err)
	_, err = execute(`{}`, "lookup")
	fmt.Println(err)
	// Output:
	// a
	// b
	// {"x":[1,2]}
	// accepts 1 arg(s), received 0
	// unknown command "lookup" for "jsonq"
}
```

Local command:

```sh
cd examples/thirdparty && go test -v -run Example ./clicobra
```



## Which to use

Use **`flag`** for tools with a handful of flags and up to a few subcommands: no dependencies, and everything is visible in a page of code. Most internal tools and many open source ones never need more. Use **Cobra** when the tool grows a real command hierarchy, when users expect GNU-style flags and completion, or when you are building a `kubectl` plugin or another tool in that ecosystem. (`urfave/cli` and `kong` are popular alternatives with different styles.)

## Common mistakes

### Calling os.Exit or log.Fatal deep in the code

Deferred functions do not run, and the code becomes untestable. Return errors to `run`; exit only in `main`.

### Printing errors to stdout

They end up in the next program of a pipeline. Errors go to stderr.

### Exit code 0 on failure

Scripts and CI then believe it worked. Return non-zero on any failure.

### Global state in Cobra commands

Package-level flag variables leak between tests. Build commands in functions.

## Key takeaways

- Results to stdout, messages to stderr; files as arguments or stdin; exit 0, 1 or 2.
- Keep `main` tiny; put the program in `run(ctx, args, stdin, stdout, stderr) int` and test it in-process.
- With `flag`, use one `FlagSet` per subcommand with `ContinueOnError`; classify errors once at the top.
- Cobra adds command trees, POSIX flags, persistent flags, generated help and shell completion; build its commands in functions and use `RunE` and the command's streams.

## Further reading

- [Package flag](https://pkg.go.dev/flag)
- [Cobra user guide](https://github.com/spf13/cobra/blob/main/site/content/user_guide.md)
- [Command Line Interface Guidelines](https://clig.dev/)
