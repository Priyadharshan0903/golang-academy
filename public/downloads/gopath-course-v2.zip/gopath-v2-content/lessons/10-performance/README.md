# 10. Profiling and performance

This module follows one rule: **measure first**. Every claim about speed in it comes from a benchmark or a profile that was actually run, on a 2-core cloud VM, and you can rerun every one of them yourself. The running example is a log analyzer that gets about 140 times faster over the course of the module, guided by data at every step.

**Time:** about 3 to 4 hours, plus the exercise.

- [10.1 Measure first: benchmarks and benchstat](01-measure-first.md)
- [10.2 CPU and memory profiling with pprof](02-pprof.md)
- [10.3 The execution tracer and flight recorder](03-tracer.md)
- [10.4 Allocation reduction and escape analysis](04-allocations.md)
- [10.5 Profile-guided optimization (PGO)](05-pgo.md)
- [10.6 sync.Pool and when it helps](06-sync-pool.md)
- [10.7 Exercise: optimize under an allocation budget](07-exercise.md)
