# 10.7 Exercise: optimize under an allocation budget

Take correct but wasteful code, profile it, and make it pass an allocation budget test without breaking correctness.

## The task

This exercise is the module in miniature. The starter code is **correct**, and its correctness tests already pass. But it allocates wildly, and a test enforces an allocation budget it misses by a factor of about 50.



## Exercise: 10.7 Exercise: optimize under an allocation budget

`TopTags` finds the most common hashtags in a list of posts. Make `TestAllocationBudget` pass (at most 400 allocations for 1000 posts) while keeping `TestTopTags` and `TestTiesAreAlphabetical` green. Use the workflow from this module: run the benchmark, read a memory profile, fix the biggest source, measure again.

### Starter

```go
//go:build !solution

// Package hashtags is an optimization exercise. The starter code below
// is CORRECT but allocates far too much. Make it pass the allocation
// budget test without breaking the correctness tests.
//
//	cd exercises
//	go test ./m10/hashtags                       # correctness + budget
//	go test -bench . -benchmem ./m10/hashtags    # measure
//	go test -bench . -memprofile mem.out ./m10/hashtags && go tool pprof -top -sample_index=alloc_space mem.out
package hashtags

import (
	"fmt"
	"sort"
	"strings"
)

// TopTags returns the n most common hashtags in posts, most common
// first, ties broken alphabetically. A hashtag is a word (words are
// separated by ASCII whitespace) that starts with '#' followed by one or
// more ASCII letters, digits or underscores; the tag ends at the first
// other character. Tags are case-insensitive and returned in lowercase.
func TopTags(posts []string, n int) []string {
	counts := map[string]int{}
	for _, post := range posts {
		for _, word := range strings.Fields(post) { // allocates a slice per post
			if !strings.HasPrefix(word, "#") {
				continue
			}
			tag := ""
			for _, r := range word[1:] {
				if r == '_' || r >= '0' && r <= '9' || r >= 'a' && r <= 'z' || r >= 'A' && r <= 'Z' {
					tag += string(r) // allocates on every character
				} else {
					break
				}
			}
			if tag != "" {
				counts[strings.ToLower(tag)]++ // allocates even when already lowercase
			}
		}
	}

	type pair struct {
		tag   string
		count int
	}
	var pairs []pair
	for t, c := range counts {
		pairs = append(pairs, pair{t, c})
	}
	sort.Slice(pairs, func(i, j int) bool {
		// Building sort keys with Sprintf allocates on every comparison.
		return fmt.Sprintf("%09d", 1e9-pairs[i].count)+pairs[i].tag < fmt.Sprintf("%09d", 1e9-pairs[j].count)+pairs[j].tag
	})

	var out []string
	for i := 0; i < len(pairs) && i < n; i++ {
		out = append(out, pairs[i].tag)
	}
	return out
}
```

```sh
cd exercises
go test ./m10/hashtags/
```

### Reference solution — try the exercise first

```go
//go:build solution

// Package hashtags is an optimization exercise.
package hashtags

import (
	"cmp"
	"slices"
	"strings"
)

// TopTags returns the n most common hashtags in posts.
func TopTags(posts []string, n int) []string {
	counts := make(map[string]int, 64)
	for _, post := range posts {
		for i := 0; i < len(post); i++ {
			if post[i] != '#' || (i > 0 && !isSpace(post[i-1])) {
				continue // a tag must start a word
			}
			j := i + 1
			lower := true
			for j < len(post) && isTagByte(post[j]) {
				if 'A' <= post[j] && post[j] <= 'Z' {
					lower = false
				}
				j++
			}
			if j == i+1 {
				continue
			}
			tag := post[i+1 : j] // a substring: no allocation
			if !lower {
				tag = strings.ToLower(tag) // allocate only when needed
			}
			counts[tag]++
			i = j - 1 // continue after the tag
		}
	}

	type pair struct {
		tag   string
		count int
	}
	pairs := make([]pair, 0, len(counts))
	for t, c := range counts {
		pairs = append(pairs, pair{t, c})
	}
	slices.SortFunc(pairs, func(a, b pair) int {
		return cmp.Or(cmp.Compare(b.count, a.count), strings.Compare(a.tag, b.tag))
	})

	out := make([]string, 0, min(n, len(pairs)))
	for _, p := range pairs[:min(n, len(pairs))] {
		out = append(out, p.tag)
	}
	return out
}

func isTagByte(c byte) bool {
	return c == '_' || '0' <= c && c <= '9' || 'a' <= c && c <= 'z' || 'A' <= c && c <= 'Z'
}

func isSpace(c byte) bool {
	return c == ' ' || c == '\t' || c == '\n' || c == '\r' || c == '\v' || c == '\f'
}
```

```sh
go test -tags solution ./m10/hashtags/
```



## Suggested workflow

```bash
cd exercises

# 1. Where do we stand?
go test ./m10/hashtags                                  # TestAllocationBudget fails
go test -run xxx -bench . -benchmem ./m10/hashtags      # note ns/op, B/op, allocs/op

# 2. Where do the allocations come from?
go test -run xxx -bench . -memprofile mem.out ./m10/hashtags
go tool pprof -top -sample_index=alloc_objects mem.out
go tool pprof -list TopTags -sample_index=alloc_objects mem.out

# 3. Fix the biggest source, then repeat steps 1 and 2.
```

On the test VM, the starter measured about **19,840 allocations** and 760 µs per call; the reference solution measured **255 allocations** and about 95 µs.

## Hints

Try to find these yourself in the profile before reading them.



### Hint 1: where the starter allocates

Four places: `strings.Fields` allocates a slice for every post; `tag += string(r)` allocates a new string for every character; `strings.ToLower` allocates even when the tag is already lowercase; and the sort comparator calls `fmt.Sprintf` twice on every comparison.





### Hint 2: substrings are free

A substring like `post[i+1:j]` shares memory with `post` and does not allocate. Using it as a map key does not allocate either. Scan the bytes of each post directly instead of splitting it into words.





### Hint 3: sorting

`slices.SortFunc` with `cmp.Or(cmp.Compare(...), strings.Compare(...))` (lesson 3.4) compares without allocating.



The reference solution is in `exercises/m10/hashtags/solution.go`.

## Part 3, first half: recap

You can now measure performance honestly with benchmarks and benchstat, find hot spots with CPU and memory profiles, investigate latency with the tracer and flight recorder, reason about allocations with escape analysis, apply PGO, and reuse objects with `sync.Pool`, always checking the result with data.

Next is **[Module 11: Runtime internals](../11-runtime-internals/README.md)**, which explains the machinery behind what you have been measuring.
