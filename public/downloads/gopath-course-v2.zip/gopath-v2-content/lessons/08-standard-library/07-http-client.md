# 8.7 net/http client done right

Make HTTP requests that cannot hang, leak connections or silently ignore errors: timeouts, contexts, closing and limiting bodies, checking status codes, and tuning the Transport.

## What you will learn

- Why the default HTTP client is a production risk
- The steps every correct request needs
- Timeouts: `Client.Timeout`, request contexts and `Transport` timeouts
- Why you must close response bodies, and why status codes are not errors
- Testing clients against `httptest.Server`
- The `Transport` settings worth knowing

## The idea

`net/http` makes requests look trivial: `resp, err := http.Get(url)`. That line has three production problems:

1. The default client has **no timeout**. A server that accepts the connection and never answers blocks your goroutine forever.
2. If you forget `resp.Body.Close()`, the connection cannot be reused, and you leak file descriptors and goroutines.
3. A `404` or `500` response returns `err == nil`. If you only check `err`, failures look like successes.

## A correct request, step by step



Source: `examples/m08/httpclient/httpclient_test.go`

```go
// One client for the whole program: it pools and reuses connections.
var client = &http.Client{
	Timeout: 10 * time.Second, // whole request: connect, headers and body
}

type Repo struct {
	Name  string `json:"name"`
	Stars int    `json:"stars"`
}

// getRepo shows every step a correct request needs.
func getRepo(ctx context.Context, baseURL, name string) (Repo, error) {
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, baseURL+"/repos/"+name, nil)
	if err != nil {
		return Repo{}, err
	}
	req.Header.Set("Accept", "application/json")

	resp, err := client.Do(req)
	if err != nil {
		return Repo{}, fmt.Errorf("get repo %s: %w", name, err)
	}
	defer resp.Body.Close() // always close, or the connection cannot be reused

	if resp.StatusCode != http.StatusOK { // a 404 or 500 is NOT an error from Do
		io.Copy(io.Discard, io.LimitReader(resp.Body, 4096))
		return Repo{}, fmt.Errorf("get repo %s: unexpected status %s", name, resp.Status)
	}

	var r Repo
	// Limit how much we are willing to read from someone else's server.
	if err := json.NewDecoder(io.LimitReader(resp.Body, 1<<20)).Decode(&r); err != nil {
		return Repo{}, fmt.Errorf("decode repo %s: %w", name, err)
	}
	return r, nil
}
```



1. **One shared `http.Client`** for the whole program. Clients are safe for concurrent use and keep a pool of connections. Creating a client per request throws that pool away.
2. **`http.NewRequestWithContext`** so the caller's cancellation and deadline apply (lesson 7.1).
3. **Set headers** such as `Accept`, authentication and a `User-Agent`.
4. **Check `err` from `Do`.** It covers network failures, timeouts and cancellation, never HTTP status codes.
5. **`defer resp.Body.Close()`** immediately after the error check.
6. **Check `resp.StatusCode`** and turn unexpected statuses into errors.
7. **Limit and decode the body.** `io.LimitReader` stops a misbehaving server from filling your memory.

For connection reuse, the body should be read to the end before closing; since Go 1.27, closing an HTTP/1 response body drains a limited amount of unread content automatically, but reading or discarding what you do not need (as the error path does with `io.Copy(io.Discard, ...)`) keeps the behavior explicit.

## Testing against a fake server



Source: `examples/m08/httpclient/httpclient_test.go`

```go
func Example_request() {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/repos/go" {
			http.NotFound(w, r)
			return
		}
		w.Header().Set("Content-Type", "application/json")
		fmt.Fprint(w, `{"name":"go","stars":125000}`)
	}))
	defer srv.Close()

	ctx := context.Background()
	repo, err := getRepo(ctx, srv.URL, "go")
	fmt.Println(repo, err)

	_, err = getRepo(ctx, srv.URL, "nope")
	fmt.Println(err)

	// Output:
	// {go 125000} <nil>
	// get repo nope: unexpected status 404 Not Found
}
```

Local command:

```sh
go test -run Example_request -v ./examples/m08/httpclient
```



`httptest.NewServer` starts a real HTTP server on a local port with any handler you give it. Tests run fast, need no network, and can simulate every failure: slow responses, bad JSON, 500s. Go 1.27 adds `httptest.NewTestServer`, which uses an in-memory network and works with `testing/synctest` for deterministic timing.

## Timeouts



Source: `examples/m08/httpclient/httpclient_test.go`

```go
func Example_timeouts() {
	slow := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		select {
		case <-time.After(time.Second):
		case <-r.Context().Done(): // the client gave up
		}
	}))
	defer slow.Close()

	ctx, cancel := context.WithTimeout(context.Background(), 20*time.Millisecond)
	defer cancel()
	_, err := getRepo(ctx, slow.URL, "go")

	var netErr net.Error
	fmt.Println(errors.Is(err, context.DeadlineExceeded))
	fmt.Println(errors.As(err, &netErr) && netErr.Timeout())

	// Output:
	// true
	// true
}
```

Local command:

```sh
go test -run Example_timeouts -v ./examples/m08/httpclient
```



There are several layers, and they combine:

| Setting | Limits | Use |
|---|---|---|
| `Client.Timeout` | the entire request, including reading the body | a safety net on every client |
| Request context deadline | the entire request, per call | when each call needs its own budget |
| `Transport.DialContext` timeout | establishing the TCP connection | detecting unreachable hosts quickly |
| `Transport.TLSHandshakeTimeout` | the TLS handshake | slow or broken TLS endpoints |
| `Transport.ResponseHeaderTimeout` | waiting for response headers after sending the request | servers that accept but never answer |

A timeout error satisfies `net.Error` with `Timeout() == true`, and a context deadline also matches `context.DeadlineExceeded`. Both are worth retrying for idempotent requests, with backoff (lesson 5.6).

## Tuning the Transport



Source: `examples/m08/httpclient/httpclient_test.go`

```go
// newTunedClient shows the Transport settings worth knowing. The
// defaults are reasonable; tune them when profiling or metrics say so.
func newTunedClient() *http.Client {
	t := http.DefaultTransport.(*http.Transport).Clone()
	t.MaxIdleConns = 100
	t.MaxIdleConnsPerHost = 20 // default is 2: low for services calling one backend a lot
	t.IdleConnTimeout = 90 * time.Second
	t.TLSHandshakeTimeout = 5 * time.Second
	t.ResponseHeaderTimeout = 5 * time.Second
	return &http.Client{Transport: t, Timeout: 15 * time.Second}
}

func Example_transport() {
	c := newTunedClient()
	fmt.Println(c.Timeout, c.Transport.(*http.Transport).MaxIdleConnsPerHost)

	// Output:
	// 15s 20
}
```

Local command:

```sh
go test -run Example_transport -v ./examples/m08/httpclient
```



Clone `http.DefaultTransport` and adjust it instead of building one from scratch, so you keep its sensible defaults (proxy from environment, HTTP/2, keep-alives). The setting people most often need is **`MaxIdleConnsPerHost`**: its default of 2 means a service making many concurrent calls to one backend keeps opening new connections. Raise it to roughly your expected concurrency to that host.

## Retries

Only retry requests that are **safe to repeat**: `GET`, `HEAD`, `PUT` and `DELETE` are idempotent by definition; `POST` usually is not, unless the API supports idempotency keys. Retry on network errors, timeouts, `429` and `5xx`, with exponential backoff and jitter, and respect a `Retry-After` header.

## Common mistakes

### Using `http.Get` or `http.DefaultClient` in services

No timeout. Use your own client with `Timeout` set.

### A new `http.Client` (or `Transport`) per request

Destroys connection reuse. Every request pays for a TCP and TLS handshake, and idle connections pile up.

### Not closing the body

Leaks connections. `defer resp.Body.Close()` right after checking `err`.

### Treating non-2xx as success

`err == nil` with a 503 response. Always check `StatusCode`.

### Reading unlimited bodies

`io.ReadAll(resp.Body)` from a server you do not control. Wrap it in `io.LimitReader`.

## Exercise



## Exercise: 8.7 net/http client done right

Write a small API client with `GetUser` and `CreateUser`. It must send the right headers, respect the context, map `404` to `ErrNotFound` and other failures to an `*APIError` that carries the server's error message, and decode JSON responses. The tests run against an `httptest` server, including a slow endpoint that must time out.

### Starter

```go
//go:build !solution

// Package apiclient practices net/http and encoding/json by building a
// small, correct client for a JSON API.
package apiclient

import (
	"context"
	"errors"
	"net/http"
)

// ErrNotFound is returned when the API responds with 404.
var ErrNotFound = errors.New("not found")

// APIError is returned for any other non-2xx response. The API sends
// error bodies like {"error": "message"}.
type APIError struct {
	Status  int    // HTTP status code
	Message string // the "error" field of the body, if present
}

func (e *APIError) Error() string {
	// TODO: implement me. Suggested: "api error 503: maintenance".
	return ""
}

// User is the API's user resource:
//
//	{"id": 7, "name": "Ana", "email": "ana@example.com"}
type User struct {
	ID    int
	Name  string
	Email string
}

// Client talks to the API at BaseURL using HTTP. HTTP must not be nil.
type Client struct {
	BaseURL string
	HTTP    *http.Client
}

// GetUser fetches GET {BaseURL}/users/{id}.
//
//   - It sends "Accept: application/json".
//   - It respects ctx (use http.NewRequestWithContext).
//   - 200: decode the body into a User.
//   - 404: return an error wrapping ErrNotFound.
//   - Other statuses: return an *APIError (wrapped is fine).
//   - It always closes the response body.
func (c *Client) GetUser(ctx context.Context, id int) (User, error) {
	// TODO: implement me.
	return User{}, nil
}

// CreateUser sends POST {BaseURL}/users with a JSON body
// {"name": ..., "email": ...} and "Content-Type: application/json",
// and returns the created User from a 201 response. Other statuses
// are handled like in GetUser.
func (c *Client) CreateUser(ctx context.Context, name, email string) (User, error) {
	// TODO: implement me.
	return User{}, nil
}
```

```sh
cd exercises
go test ./m08/apiclient/
```

### Reference solution — try the exercise first

```go
//go:build solution

// Package apiclient practices net/http and encoding/json by building a
// small, correct client for a JSON API.
package apiclient

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
)

// ErrNotFound is returned when the API responds with 404.
var ErrNotFound = errors.New("not found")

// APIError is returned for any other non-2xx response.
type APIError struct {
	Status  int
	Message string
}

func (e *APIError) Error() string { return fmt.Sprintf("api error %d: %s", e.Status, e.Message) }

// User is the API's user resource.
type User struct {
	ID    int    `json:"id"`
	Name  string `json:"name"`
	Email string `json:"email"`
}

// Client talks to the API at BaseURL.
type Client struct {
	BaseURL string
	HTTP    *http.Client
}

// GetUser fetches a user by ID.
func (c *Client) GetUser(ctx context.Context, id int) (User, error) {
	var u User
	err := c.do(ctx, http.MethodGet, fmt.Sprintf("/users/%d", id), nil, http.StatusOK, &u)
	if err != nil {
		return User{}, fmt.Errorf("get user %d: %w", id, err)
	}
	return u, nil
}

// CreateUser creates a user and returns it.
func (c *Client) CreateUser(ctx context.Context, name, email string) (User, error) {
	var u User
	body := map[string]string{"name": name, "email": email}
	if err := c.do(ctx, http.MethodPost, "/users", body, http.StatusCreated, &u); err != nil {
		return User{}, fmt.Errorf("create user: %w", err)
	}
	return u, nil
}

// do performs one request and decodes a JSON response into out.
func (c *Client) do(ctx context.Context, method, path string, in any, want int, out any) error {
	var body io.Reader
	if in != nil {
		b, err := json.Marshal(in)
		if err != nil {
			return err
		}
		body = bytes.NewReader(b)
	}
	req, err := http.NewRequestWithContext(ctx, method, c.BaseURL+path, body)
	if err != nil {
		return err
	}
	req.Header.Set("Accept", "application/json")
	if in != nil {
		req.Header.Set("Content-Type", "application/json")
	}

	resp, err := c.HTTP.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	limited := io.LimitReader(resp.Body, 1<<20)

	switch {
	case resp.StatusCode == want:
		return json.NewDecoder(limited).Decode(out)
	case resp.StatusCode == http.StatusNotFound:
		return ErrNotFound
	default:
		var e struct {
			Error string `json:"error"`
		}
		json.NewDecoder(limited).Decode(&e) // best effort
		return &APIError{Status: resp.StatusCode, Message: e.Error}
	}
}
```

```sh
go test -tags solution ./m08/apiclient/
```



## Key takeaways

- Use one shared `http.Client` with a `Timeout`; never the default client in services.
- Every request: context, headers, check `err`, close the body, check the status, limit the body.
- Status codes are not errors; translate them yourself.
- Test against `httptest.Server`; tune `MaxIdleConnsPerHost` for busy backends.
- Retry only idempotent requests, with backoff.

## Further reading

- [Package net/http](https://pkg.go.dev/net/http), especially Client and Transport
- [Package net/http/httptest](https://pkg.go.dev/net/http/httptest)
- [The complete guide to Go net/http timeouts](https://blog.cloudflare.com/the-complete-guide-to-golang-net-http-timeouts/) on the Cloudflare blog
