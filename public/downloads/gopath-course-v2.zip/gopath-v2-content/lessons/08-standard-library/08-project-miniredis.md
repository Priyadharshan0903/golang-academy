# 8.8 Project: a mini Redis server

Build a Redis-compatible TCP server with only the standard library: the RESP protocol with bufio, a concurrent keyspace with expiry, append-only file persistence, and graceful shutdown. Works with redis-cli.

## What you will build

A small server that speaks the real Redis protocol, so the real `redis-cli` can talk to it:

```bash
go run ./projects/miniredis/cmd/miniredis -addr 127.0.0.1:6380 -aof /tmp/mini.aof
```

```bash
$ redis-cli -p 6380 set greeting "hello gopher"
OK
$ redis-cli -p 6380 get greeting
"hello gopher"
$ redis-cli -p 6380 incr visits
(integer) 1
```

Stop it with Ctrl+C, start it again, and the data is still there.

It brings together Modules 6, 7 and 8: TCP networking, `bufio` parsing, a mutex-protected store, background goroutines, `context` cancellation, files and `slog`. The code is in [`projects/miniredis`](https://github.com/Priyadharshan0903/golang-academy/tree/master/content-source/gopath-academy/projects/miniredis).

## Architecture

```text
              ┌───────────────── server ──────────────────┐
redis-cli ──▶ │ accept loop ──▶ one goroutine per client  │
redis-cli ──▶ │                   │  resp.Reader / Writer  │
              │                   ▼                        │
              │              execute(cmd) ──▶ store (RWMutex, TTLs)
              │                   │                        │
              │                   └──▶ aof.Log (append writes)
              │ janitor goroutine: removes expired keys    │
              └────────────────────────────────────────────┘
```

Four packages, each with one job:

| Package | Responsibility |
|---|---|
| `internal/resp` | Parse commands and write replies in RESP2 |
| `internal/store` | The keyspace: values, expiry, concurrency safety |
| `internal/aof` | Append write commands to a file; replay it on startup |
| `internal/server` | Accept connections, dispatch commands, shut down gracefully |

## The protocol: `internal/resp`

Redis clients send each command as an **array of bulk strings**, each prefixed with its length:

```text
*3\r\n$3\r\nSET\r\n$8\r\ngreeting\r\n$12\r\nhello gopher\r\n
```

Length prefixes make the protocol **binary safe**: a value can contain spaces, newlines or zero bytes.



Source: `projects/miniredis/internal/resp/resp.go`

```go
// Package resp reads and writes RESP2, the Redis serialization protocol.
//
// Clients send commands as arrays of bulk strings:
//
//	*2\r\n$3\r\nGET\r\n$4\r\nname\r\n     ->  ["GET", "name"]
//
// Servers reply with one of five types:
//
//	+OK\r\n            simple string
//	-ERR message\r\n   error
//	:42\r\n            integer
//	$5\r\nhello\r\n    bulk string ($-1\r\n is null)
//	*N\r\n...          array of N replies
package resp

import (
	"bufio"
	"errors"
	"fmt"
	"io"
	"strconv"
	"strings"
)

// ErrProtocol is wrapped by every error caused by malformed input.
var ErrProtocol = errors.New("protocol error")

// Limits that protect the server from huge or malicious requests.
const (
	maxArgs     = 1024
	maxBulkSize = 512 * 1024 * 1024 // Redis' own limit for a bulk string
	maxLineSize = 64 * 1024
)

// Reader parses commands from a client connection.
type Reader struct {
	br *bufio.Reader
}

// NewReader wraps r with buffering.
func NewReader(r io.Reader) *Reader { return &Reader{br: bufio.NewReaderSize(r, 16*1024)} }

// ReadCommand reads one command. It accepts the standard array form
// and the "inline" form (plain text like "PING\r\n") that telnet and
// redis-cli in some modes send. It returns io.EOF when the client
// disconnects cleanly between commands.
func (r *Reader) ReadCommand() ([]string, error) {
	line, err := r.readLine()
	if err != nil {
		return nil, err
	}
	if len(line) == 0 {
		return r.ReadCommand() // skip empty lines
	}
	if line[0] != '*' {
		return strings.Fields(line), nil // inline command
	}

	n, err := strconv.Atoi(line[1:])
	if err != nil || n < 0 || n > maxArgs {
		return nil, fmt.Errorf("%w: invalid array length %q", ErrProtocol, line)
	}
	args := make([]string, 0, n)
	for range n {
		arg, err := r.readBulk()
		if err != nil {
			return nil, err
		}
		args = append(args, arg)
	}
	return args, nil
}

func (r *Reader) readBulk() (string, error) {
	line, err := r.readLine()
	if err != nil {
		return "", noEOF(err)
	}
	if len(line) == 0 || line[0] != '$' {
		return "", fmt.Errorf("%w: expected bulk string, got %q", ErrProtocol, line)
	}
	size, err := strconv.Atoi(line[1:])
	if err != nil || size < 0 || size > maxBulkSize {
		return "", fmt.Errorf("%w: invalid bulk length %q", ErrProtocol, line)
	}
	buf := make([]byte, size+2) // payload plus \r\n
	if _, err := io.ReadFull(r.br, buf); err != nil {
		return "", noEOF(err)
	}
	if buf[size] != '\r' || buf[size+1] != '\n' {
		return "", fmt.Errorf("%w: bulk string not terminated by CRLF", ErrProtocol)
	}
	return string(buf[:size]), nil
}

// readLine reads up to \r\n (a bare \n is accepted for inline commands).
func (r *Reader) readLine() (string, error) {
	line, err := r.br.ReadSlice('\n')
	if errors.Is(err, bufio.ErrBufferFull) || len(line) > maxLineSize {
		return "", fmt.Errorf("%w: line too long", ErrProtocol)
	}
	if err != nil {
		if errors.Is(err, io.EOF) && len(line) > 0 {
			return "", io.ErrUnexpectedEOF
		}
		return "", err
	}
	return strings.TrimSuffix(strings.TrimSuffix(string(line), "\n"), "\r"), nil
}

// noEOF turns io.EOF in the middle of a command into ErrUnexpectedEOF.
func noEOF(err error) error {
	if errors.Is(err, io.EOF) {
		return io.ErrUnexpectedEOF
	}
	return err
}

// Writer writes replies. Call Flush after each reply (or batch).
type Writer struct {
	bw *bufio.Writer
}

// NewWriter wraps w with buffering.
func NewWriter(w io.Writer) *Writer { return &Writer{bw: bufio.NewWriter(w)} }

// Simple writes a simple string such as OK or PONG.
func (w *Writer) Simple(s string) { w.bw.WriteString("+" + s + "\r\n") }

// Error writes an error reply. By convention it starts with a code such as ERR.
func (w *Writer) Error(msg string) { w.bw.WriteString("-" + msg + "\r\n") }

// Int writes an integer reply.
func (w *Writer) Int(n int64) {
	w.bw.WriteByte(':')
	w.bw.WriteString(strconv.FormatInt(n, 10))
	w.bw.WriteString("\r\n")
}

// Bulk writes a bulk string reply.
func (w *Writer) Bulk(s string) {
	w.bw.WriteByte('$')
	w.bw.WriteString(strconv.Itoa(len(s)))
	w.bw.WriteString("\r\n")
	w.bw.WriteString(s)
	w.bw.WriteString("\r\n")
}

// Null writes the null bulk string, used for missing keys.
func (w *Writer) Null() { w.bw.WriteString("$-1\r\n") }

// Array writes an array of bulk strings, the format commands use.
func (w *Writer) Array(items []string) {
	w.bw.WriteByte('*')
	w.bw.WriteString(strconv.Itoa(len(items)))
	w.bw.WriteString("\r\n")
	for _, it := range items {
		w.Bulk(it)
	}
}

// Flush sends buffered data to the underlying writer.
func (w *Writer) Flush() error { return w.bw.Flush() }
```



Things to notice:

- `bufio.Reader.ReadSlice('\n')` reads a line without allocating, and `io.ReadFull` reads exactly `size+2` bytes for a bulk string.
- **Limits** on array length, bulk size and line length stop a malicious client from making the server allocate gigabytes.
- **Errors are classified**: `ErrProtocol` for bad input (the server replies with an error and closes), `io.EOF` for a clean disconnect between commands, and `io.ErrUnexpectedEOF` for a disconnect in the middle of one.
- The writer buffers replies, and the server calls `Flush` once per command.

The tests include a **fuzz test** (Module 9 explains fuzzing): `go test -fuzz=FuzzReadCommand` throws millions of random inputs at the parser to make sure it never panics or hangs.

## The keyspace: `internal/store`



Source: `projects/miniredis/internal/store/store.go`

```go
// Package store is the in-memory keyspace: string values with optional
// expiry, safe for concurrent use by many client connections.
package store

import (
	"context"
	"errors"
	"strconv"
	"sync"
	"time"
)

// ErrNotInteger is returned by Incr when the value is not an integer.
var ErrNotInteger = errors.New("value is not an integer or out of range")

type entry struct {
	value   string
	expires time.Time // zero means "never"
}

func (e entry) expired(now time.Time) bool {
	return !e.expires.IsZero() && !now.Before(e.expires)
}

// Store is a concurrency-safe map of string keys to string values.
type Store struct {
	mu   sync.RWMutex
	data map[string]entry
	now  func() time.Time
}

// New returns an empty store.
func New() *Store { return &Store{data: make(map[string]entry), now: time.Now} }

// Get returns the value of key. Expired keys are treated as missing
// (and removed lazily by later writes or by the janitor).
func (s *Store) Get(key string) (string, bool) {
	s.mu.RLock()
	defer s.mu.RUnlock()
	e, ok := s.data[key]
	if !ok || e.expired(s.now()) {
		return "", false
	}
	return e.value, true
}

// Set stores value under key. A ttl of 0 means no expiry.
func (s *Store) Set(key, value string, ttl time.Duration) {
	s.mu.Lock()
	defer s.mu.Unlock()
	e := entry{value: value}
	if ttl > 0 {
		e.expires = s.now().Add(ttl)
	}
	s.data[key] = e
}

// Del removes keys and returns how many existed.
func (s *Store) Del(keys ...string) int {
	s.mu.Lock()
	defer s.mu.Unlock()
	now := s.now()
	n := 0
	for _, k := range keys {
		if e, ok := s.data[k]; ok {
			if !e.expired(now) {
				n++
			}
			delete(s.data, k)
		}
	}
	return n
}

// Exists returns how many of keys exist (duplicates count each time, like Redis).
func (s *Store) Exists(keys ...string) int {
	s.mu.RLock()
	defer s.mu.RUnlock()
	now := s.now()
	n := 0
	for _, k := range keys {
		if e, ok := s.data[k]; ok && !e.expired(now) {
			n++
		}
	}
	return n
}

// Incr adds 1 to the integer value of key (missing keys start at 0) and
// returns the new value. The key keeps its expiry.
func (s *Store) Incr(key string) (int64, error) {
	s.mu.Lock() // the read-modify-write must be one critical section
	defer s.mu.Unlock()
	e, ok := s.data[key]
	if !ok || e.expired(s.now()) {
		e = entry{value: "0"}
	}
	n, err := strconv.ParseInt(e.value, 10, 64)
	if err != nil || n == 1<<63-1 {
		return 0, ErrNotInteger
	}
	n++
	e.value = strconv.FormatInt(n, 10)
	s.data[key] = e
	return n, nil
}

// Expire sets a ttl on an existing key and reports whether the key existed.
func (s *Store) Expire(key string, ttl time.Duration) bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	now := s.now()
	e, ok := s.data[key]
	if !ok || e.expired(now) {
		return false
	}
	e.expires = now.Add(ttl)
	s.data[key] = e
	return true
}

// TTL returns the remaining time to live. It returns -2 for a missing
// key and -1 for a key without expiry, matching Redis' TTL command.
func (s *Store) TTL(key string) time.Duration {
	s.mu.RLock()
	defer s.mu.RUnlock()
	now := s.now()
	e, ok := s.data[key]
	switch {
	case !ok || e.expired(now):
		return -2
	case e.expires.IsZero():
		return -1
	default:
		return e.expires.Sub(now)
	}
}

// Len returns the number of keys, including expired ones not yet removed.
func (s *Store) Len() int {
	s.mu.RLock()
	defer s.mu.RUnlock()
	return len(s.data)
}

// RemoveExpired deletes every expired key and returns how many it removed.
func (s *Store) RemoveExpired() int {
	s.mu.Lock()
	defer s.mu.Unlock()
	now := s.now()
	n := 0
	for k, e := range s.data {
		if e.expired(now) {
			delete(s.data, k)
			n++
		}
	}
	return n
}

// RunJanitor removes expired keys every interval until ctx is done.
// Without it, keys that expire and are never read again would stay in
// memory forever.
func (s *Store) RunJanitor(ctx context.Context, interval time.Duration) {
	t := time.NewTicker(interval)
	defer t.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-t.C:
			s.RemoveExpired()
		}
	}
}
```



- **One `sync.RWMutex`** guards the map. `GET`, `EXISTS` and `TTL` take the read lock, so many clients can read in parallel.
- **`INCR` is one critical section.** Reading, parsing, adding and writing back under one lock is what makes 1000 concurrent increments add up to exactly 1000 (the server test checks this). Doing it as `GET` then `SET` would lose updates.
- **Lazy expiry plus a janitor.** Reads treat expired keys as missing without deleting them (they only hold the read lock). `RunJanitor` periodically removes expired keys so memory is reclaimed even for keys nobody reads again. Redis uses the same two-part approach.
- **Injected clock** for deterministic expiry tests.

## Persistence: `internal/aof`



Source: `projects/miniredis/internal/aof/aof.go`

```go
// Package aof implements an append-only file: every write command is
// appended to a log, and on startup the log is replayed to rebuild the
// data. It is the simplest durable persistence there is, and the same
// idea Redis' AOF mode uses.
package aof

import (
	"bufio"
	"errors"
	"fmt"
	"io"
	"os"
	"sync"
	"time"

	"github.com/Priyadharshan0903/gopath-academy/projects/miniredis/internal/resp"
)

// Log appends commands to a file. It is safe for concurrent use.
type Log struct {
	mu   sync.Mutex
	f    *os.File
	w    *resp.Writer
	sync bool // fsync after every append (slow but safest)
}

// Open opens or creates the log at path for appending.
func Open(path string, syncEveryWrite bool) (*Log, error) {
	f, err := os.OpenFile(path, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0o644)
	if err != nil {
		return nil, fmt.Errorf("open aof: %w", err)
	}
	return &Log{f: f, w: resp.NewWriter(f), sync: syncEveryWrite}, nil
}

// Append writes one command to the log.
func (l *Log) Append(args []string) error {
	l.mu.Lock()
	defer l.mu.Unlock()
	l.w.Array(args)
	if err := l.w.Flush(); err != nil {
		return err
	}
	if l.sync {
		return l.f.Sync()
	}
	return nil
}

// Sync flushes the file to disk. Call it periodically when not syncing
// every write (Redis' default policy is once per second).
func (l *Log) Sync() error {
	l.mu.Lock()
	defer l.mu.Unlock()
	return l.f.Sync()
}

// SyncEvery calls Sync on an interval until stop is closed.
func (l *Log) SyncEvery(interval time.Duration, stop <-chan struct{}) {
	t := time.NewTicker(interval)
	defer t.Stop()
	for {
		select {
		case <-stop:
			return
		case <-t.C:
			l.Sync()
		}
	}
}

// Close syncs and closes the file.
func (l *Log) Close() error {
	l.mu.Lock()
	defer l.mu.Unlock()
	return errors.Join(l.f.Sync(), l.f.Close())
}

// Replay reads every command in the file at path and passes it to apply.
// A missing file is not an error. A truncated last command (the program
// crashed in the middle of a write) is ignored, like Redis does by default.
func Replay(path string, apply func(args []string) error) (int, error) {
	f, err := os.Open(path)
	if errors.Is(err, os.ErrNotExist) {
		return 0, nil
	}
	if err != nil {
		return 0, err
	}
	defer f.Close()

	r := resp.NewReader(bufio.NewReader(f))
	n := 0
	for {
		args, err := r.ReadCommand()
		if errors.Is(err, io.EOF) || errors.Is(err, io.ErrUnexpectedEOF) {
			return n, nil
		}
		if err != nil {
			return n, fmt.Errorf("replay aof command %d: %w", n+1, err)
		}
		if err := apply(args); err != nil {
			return n, fmt.Errorf("replay aof command %d: %w", n+1, err)
		}
		n++
	}
}
```



An **append-only file** records every write command in RESP format. On startup, replaying the file rebuilds the data. Design decisions:

- **Only successful writes are appended** (a `DEL` that deleted nothing is skipped).
- **fsync policy.** Calling `Sync` after every write is safest and slowest. The default here, like Redis' default, syncs once per second, so a crash can lose up to a second of writes.
- **Truncated tail tolerance.** If the process crashed in the middle of an append, the last command is incomplete. Replay stops cleanly at that point instead of refusing to start.

## The server: `internal/server`



Source: `projects/miniredis/internal/server/server.go`

```go
// Package server accepts TCP connections and executes Redis commands
// against a store, one goroutine per client.
package server

import (
	"context"
	"errors"
	"fmt"
	"io"
	"log/slog"
	"net"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/Priyadharshan0903/gopath-academy/projects/miniredis/internal/resp"
	"github.com/Priyadharshan0903/gopath-academy/projects/miniredis/internal/store"
)

// Appender persists write commands. *aof.Log satisfies it.
type Appender interface {
	Append(args []string) error
}

// Server is a tiny Redis-compatible server.
type Server struct {
	Store  *store.Store
	AOF    Appender     // optional
	Logger *slog.Logger // optional

	mu    sync.Mutex
	conns map[net.Conn]struct{}
	wg    sync.WaitGroup
}

// Serve accepts connections on ln until ctx is cancelled, then closes
// every client connection and waits for their goroutines to finish.
func (s *Server) Serve(ctx context.Context, ln net.Listener) error {
	if s.Logger == nil {
		s.Logger = slog.New(slog.DiscardHandler)
	}
	s.mu.Lock()
	s.conns = make(map[net.Conn]struct{})
	s.mu.Unlock()

	// Closing the listener is what unblocks Accept on shutdown.
	stop := context.AfterFunc(ctx, func() { ln.Close() })
	defer stop()

	for {
		conn, err := ln.Accept()
		if err != nil {
			if ctx.Err() != nil {
				break // shutting down
			}
			var ne net.Error
			if errors.As(err, &ne) && ne.Timeout() {
				time.Sleep(10 * time.Millisecond) // temporary: back off and retry
				continue
			}
			return err
		}
		s.track(conn, true)
		s.wg.Add(1)
		go func() {
			defer s.wg.Done()
			defer s.track(conn, false)
			s.handle(conn)
		}()
	}

	s.mu.Lock()
	for c := range s.conns {
		c.Close() // unblocks each handler's read
	}
	s.mu.Unlock()
	s.wg.Wait()
	return nil
}

func (s *Server) track(c net.Conn, add bool) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if add {
		s.conns[c] = struct{}{}
	} else {
		delete(s.conns, c)
		c.Close()
	}
}

// handle serves one client until it disconnects.
func (s *Server) handle(conn net.Conn) {
	defer func() {
		if r := recover(); r != nil { // a bug in one command must not crash the server
			s.Logger.Error("panic in connection handler", "remote", conn.RemoteAddr(), "panic", r)
		}
	}()
	r := resp.NewReader(conn)
	w := resp.NewWriter(conn)
	for {
		args, err := r.ReadCommand()
		if err != nil {
			if errors.Is(err, resp.ErrProtocol) {
				w.Error("ERR " + err.Error())
				w.Flush()
			}
			if !errors.Is(err, io.EOF) && !errors.Is(err, net.ErrClosed) {
				s.Logger.Debug("connection closed", "remote", conn.RemoteAddr(), "err", err)
			}
			return
		}
		if len(args) == 0 {
			continue
		}
		s.execute(args, w)
		if err := w.Flush(); err != nil {
			return
		}
	}
}

// execute runs one command and writes its reply.
func (s *Server) execute(args []string, w *resp.Writer) {
	cmd := strings.ToUpper(args[0])
	argc := len(args) - 1
	wrongArgs := func() { w.Error(fmt.Sprintf("ERR wrong number of arguments for '%s' command", strings.ToLower(cmd))) }

	switch cmd {
	case "PING":
		switch argc {
		case 0:
			w.Simple("PONG")
		case 1:
			w.Bulk(args[1])
		default:
			wrongArgs()
		}
	case "ECHO":
		if argc != 1 {
			wrongArgs()
			return
		}
		w.Bulk(args[1])
	case "GET":
		if argc != 1 {
			wrongArgs()
			return
		}
		if v, ok := s.Store.Get(args[1]); ok {
			w.Bulk(v)
		} else {
			w.Null()
		}
	case "SET":
		if argc != 2 && argc != 4 {
			wrongArgs()
			return
		}
		var ttl time.Duration
		if argc == 4 {
			if !strings.EqualFold(args[3], "EX") {
				w.Error("ERR syntax error")
				return
			}
			secs, err := strconv.Atoi(args[4])
			if err != nil || secs <= 0 {
				w.Error("ERR invalid expire time in 'set' command")
				return
			}
			ttl = time.Duration(secs) * time.Second
		}
		s.Store.Set(args[1], args[2], ttl)
		s.persist(args)
		w.Simple("OK")
	case "DEL":
		if argc < 1 {
			wrongArgs()
			return
		}
		n := s.Store.Del(args[1:]...)
		if n > 0 {
			s.persist(args)
		}
		w.Int(int64(n))
	case "EXISTS":
		if argc < 1 {
			wrongArgs()
			return
		}
		w.Int(int64(s.Store.Exists(args[1:]...)))
	case "INCR":
		if argc != 1 {
			wrongArgs()
			return
		}
		n, err := s.Store.Incr(args[1])
		if err != nil {
			w.Error("ERR " + err.Error())
			return
		}
		s.persist(args)
		w.Int(n)
	case "EXPIRE":
		if argc != 2 {
			wrongArgs()
			return
		}
		secs, err := strconv.Atoi(args[2])
		if err != nil {
			w.Error("ERR value is not an integer or out of range")
			return
		}
		if s.Store.Expire(args[1], time.Duration(secs)*time.Second) {
			s.persist(args)
			w.Int(1)
		} else {
			w.Int(0)
		}
	case "TTL":
		if argc != 1 {
			wrongArgs()
			return
		}
		ttl := s.Store.TTL(args[1])
		if ttl < 0 {
			w.Int(int64(ttl)) // -1 or -2
		} else {
			w.Int(int64((ttl + time.Second - 1) / time.Second)) // round up like Redis
		}
	case "DBSIZE":
		w.Int(int64(s.Store.Len()))
	case "COMMAND": // redis-cli asks for this on connect; an empty reply is fine
		w.Array(nil)
	default:
		w.Error(fmt.Sprintf("ERR unknown command '%s'", args[0]))
	}
}

func (s *Server) persist(args []string) {
	if s.AOF == nil {
		return
	}
	if err := s.AOF.Append(args); err != nil {
		s.Logger.Error("aof append failed", "err", err)
	}
}
```



- **One goroutine per connection** is the idiomatic Go server design. Goroutines are cheap, and blocking reads are simple to write; the runtime multiplexes them over a few threads with an efficient network poller underneath.
- **Graceful shutdown.** `context.AfterFunc` closes the listener when the context is cancelled, which makes `Accept` return. The server then closes every tracked client connection (unblocking their reads) and waits for their goroutines with a `WaitGroup`. The test `TestShutdownClosesClients` checks that idle clients cannot block shutdown.
- **Panic isolation.** A deferred `recover` in each connection handler means a bug triggered by one client's command does not crash the server for everyone (lesson 5.5).
- **Errors as replies.** Wrong argument counts and unknown commands get Redis-style `-ERR` replies, so real clients show sensible messages.

## The main program



Source: `projects/miniredis/cmd/miniredis/main.go`

```go
// Command miniredis is a small Redis-compatible server, built as the
// Module 8 project. It supports PING, ECHO, GET, SET [EX], DEL, EXISTS,
// INCR, EXPIRE, TTL and DBSIZE, persists writes to an append-only file,
// and works with redis-cli.
//
//	go run ./projects/miniredis/cmd/miniredis -addr :6380 -aof data.aof
//	redis-cli -p 6380 set greeting hello
package main

import (
	"context"
	"flag"
	"fmt"
	"log/slog"
	"net"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/Priyadharshan0903/gopath-academy/projects/miniredis/internal/aof"
	"github.com/Priyadharshan0903/gopath-academy/projects/miniredis/internal/server"
	"github.com/Priyadharshan0903/gopath-academy/projects/miniredis/internal/store"
)

func main() {
	if err := run(); err != nil {
		fmt.Fprintln(os.Stderr, "miniredis:", err)
		os.Exit(1)
	}
}

func run() error {
	addr := flag.String("addr", "127.0.0.1:6380", "listen address")
	aofPath := flag.String("aof", "", "append-only file (empty disables persistence)")
	fsyncAlways := flag.Bool("fsync-always", false, "fsync after every write instead of every second")
	flag.Parse()

	logger := slog.New(slog.NewTextHandler(os.Stderr, nil))
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()

	st := store.New()
	srv := &server.Server{Store: st, Logger: logger}

	if *aofPath != "" {
		// Replay into the store directly, so replayed commands are not re-appended.
		replayer := &server.Server{Store: st}
		n, err := aof.Replay(*aofPath, func(args []string) error {
			return replayer.Apply(args)
		})
		if err != nil {
			return err
		}
		logger.Info("aof replayed", "commands", n)

		log, err := aof.Open(*aofPath, *fsyncAlways)
		if err != nil {
			return err
		}
		defer log.Close()
		srv.AOF = log
		stopSync := make(chan struct{})
		defer close(stopSync)
		go log.SyncEvery(time.Second, stopSync)
	}

	go st.RunJanitor(ctx, 100*time.Millisecond)

	ln, err := net.Listen("tcp", *addr)
	if err != nil {
		return err
	}
	logger.Info("listening", "addr", ln.Addr().String())
	err = srv.Serve(ctx, ln)
	logger.Info("stopped")
	return err
}
```



On startup it replays the AOF into the store **through a server without an AOF attached**, so replayed commands are not appended to the file again. Then it starts the janitor and the once-per-second sync goroutine, and serves until SIGINT or SIGTERM.

## Testing

```bash
go test -race ./projects/miniredis/...
go test -fuzz=FuzzReadCommand -fuzztime=30s ./projects/miniredis/internal/resp
```

The server tests start a real server on a random local port and talk to it with a tiny RESP client, including 20 concurrent clients incrementing one counter, inline commands like you would type in `telnet`, and shutdown with idle connections. The `main` test simulates a restart by writing through one server and replaying into a fresh store.

## Stretch goals

1. **Absolute expiry in the AOF.** `SET k v EX 100` is replayed with a fresh 100 seconds. Rewrite it in the log as `SET k v` plus `PEXPIREAT k <unix-ms>` so restarts do not extend TTLs.
2. **AOF rewriting.** The log grows forever. Add a `BGREWRITEAOF` command that writes the current dataset to a new file and swaps it in atomically (lesson 8.5).
3. **More commands.** `MGET`, `MSET`, `KEYS pattern` (use `path.Match`), `APPEND`, `GETDEL`.
4. **Sharded locks.** Split the store into 16 maps, each with its own mutex, chosen by a hash of the key. Benchmark it against the single lock in Module 10.
5. **Pipelining.** Real clients often send many commands before reading replies. The server already handles it; measure the speedup with `redis-benchmark -p 6380 -P 16`.

## Module 8 recap

You can now:

- Build streaming programs from `io` and `bufio` pieces
- Encode and decode JSON correctly with `encoding/json`, and use `encoding/json/v2` on Go 1.27
- Handle time, durations and time zones without the classic bugs
- Log with structured `slog` records
- Work with files safely, embed assets and confine paths with `os.Root`
- Format and convert text efficiently
- Make HTTP requests that cannot hang or leak

Next is **Part 3: Quality, performance and internals**, starting with **[Module 9: Testing in depth](../09-testing/README.md)**.
