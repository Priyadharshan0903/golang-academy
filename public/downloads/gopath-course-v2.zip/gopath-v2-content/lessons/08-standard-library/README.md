# 8. Standard library deep dives

Go's standard library is large, consistent and production quality. Many Go services use few third party packages because the standard library already covers so much. This module goes deep on the packages you will use every week.

**Time:** about 4 to 5 hours, plus exercises and the project.

- [8.1 io: composing readers and writers](01-io.md)
- [8.2 encoding/json and encoding/json/v2](02-json.md)
- [8.3 time: durations, monotonic clock, time zones](03-time.md)
- [8.4 log/slog structured logging](04-slog.md)
- [8.5 os, filepath, io/fs and embed](05-files.md)
- [8.6 strings, bytes, strconv and fmt verbs](06-formatting.md)
- [8.7 net/http client done right](07-http-client.md)
- [8.8 Project: a mini Redis server](08-project-miniredis.md)
