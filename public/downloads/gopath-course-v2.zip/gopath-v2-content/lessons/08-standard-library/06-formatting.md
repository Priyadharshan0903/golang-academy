# 8.6 strings, bytes, strconv and fmt verbs

The fmt verbs you need, fast number and string conversion with strconv, the strings helpers that save you loops, aligned table output with text/tabwriter, and allocation-free formatting.

## What you will learn

- The `fmt` verbs, widths and flags you will use most
- `strconv` for conversion and quoting, including allocation-free `Append` functions
- `strings` helpers: `Cut`, `CutLast` (Go 1.27), `NewReplacer`, `EqualFold`, `Map`
- Aligned, column-based output with `text/tabwriter`
- `fmt.Appendf` for building output without extra allocations

## `fmt` verbs



Source: `examples/m08/formatting/formatting_test.go`

```go
func Example_verbs() {
	p := point{1, 2}
	fmt.Printf("%v | %+v | %#v | %T\n", p, p, p, p)

	fmt.Printf("%d | %5d | %-5d| %05d | %x | %b\n", 42, 42, 42, 42, 255, 5)
	fmt.Printf("%f | %.2f | %8.3f | %e | %g\n", 3.14159, 3.14159, 3.14159, 1234.5678, 0.000012)
	fmt.Printf("%s | %q | %10s| %-10s|\n", "go", "go", "right", "left")
	fmt.Printf("%t | %c | %U | %x\n", true, 'G', 'G', "hi")
	fmt.Printf("%*d | %v%%\n", 6, 7, 50) // width from an argument; %% is a literal percent

	// Output:
	// {1 2} | {X:1 Y:2} | formatting.point{X:1, Y:2} | formatting.point
	// 42 |    42 | 42   | 00042 | ff | 101
	// 3.141590 | 3.14 |    3.142 | 1.234568e+03 | 1.2e-05
	// go | "go" |      right| left      |
	// true | G | U+0047 | 6869
	//      7 | 50%
}
```

Local command:

```sh
go test -run Example_verbs -v ./examples/m08/formatting
```



| Verb | Meaning |
|---|---|
| `%v`, `%+v`, `%#v` | default format; with field names; as Go syntax |
| `%T` | the type |
| `%d`, `%x`, `%o`, `%b` | integer in decimal, hex, octal, binary |
| `%f`, `%.2f`, `%e`, `%g` | float: decimal, 2 decimals, scientific, compact |
| `%s`, `%q` | string; quoted and escaped |
| `%c`, `%U` | rune as character; as `U+XXXX` |
| `%t` | boolean |
| `%w` | error wrapping, only in `fmt.Errorf` (lesson 5.2) |
| `%%` | a literal percent sign |

Flags and widths go between `%` and the verb: `%5d` pads to 5 columns, `%-5d` left-aligns, `%05d` pads with zeros, `%8.3f` is width 8 with 3 decimals, and `%*d` takes the width from an argument.

`go vet` checks every `Printf`-style call: wrong verb for the type, missing or extra arguments. Keep it in CI.

## `strconv`



Source: `examples/m08/formatting/formatting_test.go`

```go
func Example_strconv() {
	fmt.Println(strconv.Quote("tab\there"), strconv.FormatInt(255, 2))

	f, _ := strconv.ParseFloat("2.5e3", 64)
	b, _ := strconv.ParseBool("true")
	fmt.Println(f, b)

	// Append functions build output without allocating intermediate strings.
	buf := []byte("id=")
	buf = strconv.AppendInt(buf, 42, 10)
	buf = append(buf, ';')
	fmt.Println(string(buf))

	// Output:
	// "tab\there" 11111111
	// 2500 true
	// id=42;
}
```

Local command:

```sh
go test -run Example_strconv -v ./examples/m08/formatting
```



- `Atoi`, `ParseInt`, `ParseFloat`, `ParseBool` parse text and return errors you must check (lesson 2.2).
- `Itoa`, `FormatInt(n, base)`, `FormatFloat` convert to text, faster than `fmt.Sprint`.
- `Quote` and `Unquote` handle Go-style quoted strings.
- `AppendInt`, `AppendFloat`, `AppendQuote` write into an existing `[]byte`. In hot paths (encoders, log formatters) they avoid allocating a string for every number.

## `strings` helpers



Source: `examples/m08/formatting/formatting_test.go`

```go
func Example_stringsHelpers() {
	r := strings.NewReplacer("<", "&lt;", ">", "&gt;") // many replacements in one pass
	fmt.Println(r.Replace("<b>bold</b>"))

	key, value, found := strings.Cut("timeout=30s", "=")
	fmt.Println(key, value, found)

	fmt.Println(strings.EqualFold("Straße", "STRASSE"), strings.EqualFold("Go", "GO"))
	fmt.Println(strings.Map(func(r rune) rune {
		if r == 'a' {
			return -1 // drop the rune
		}
		return r
	}, "banana"))

	// Output:
	// &lt;b&gt;bold&lt;/b&gt;
	// timeout 30s true
	// false true
	// bnn
}
```

Local command:

```sh
go test -run Example_stringsHelpers -v ./examples/m08/formatting
```



- `strings.Cut(s, sep)` splits around the **first** separator and reports whether it was found. It replaces most `Index` plus slicing code and many `SplitN(s, sep, 2)` calls.
- `strings.NewReplacer` performs many replacements in one pass, and is safe for concurrent use, so build it once.
- `strings.EqualFold` compares case-insensitively without allocating. It uses simple Unicode case folding, so `"Straße"` and `"STRASSE"` are not equal; full language-aware comparison needs `golang.org/x/text`.
- `strings.Map` transforms or drops each rune.

`strings.Title` is deprecated because it handles many languages incorrectly; use `golang.org/x/text/cases` instead.

### `strings.CutLast` (Go 1.27)



Source: `examples/m08/formatting/cutlast_test.go`

```go
func Example_cutLast() {
	// strings.CutLast (Go 1.27+) splits around the LAST separator.
	dir, file, ok := strings.CutLast("/var/log/app/server.log", "/")
	fmt.Println(dir, file, ok)

	host, port, _ := strings.CutLast("[::1]:8080", ":")
	fmt.Println(host, port)

	// Output:
	// /var/log/app server.log true
	// [::1] 8080
}
```

Local command:

```sh
go test -run Example_cutLast -v ./examples/m08/formatting
```



`CutLast` splits around the **last** separator: file extensions, the port in `host:port` (including IPv6 hosts with colons), the last path element. `bytes.CutLast` does the same for byte slices.

## Aligned output with `tabwriter`



Source: `examples/m08/formatting/formatting_test.go`

```go
func Example_tabwriter() {
	w := tabwriter.NewWriter(os.Stdout, 0, 0, 2, ' ', 0)
	fmt.Fprintln(w, "NAME\tSTATUS\tAGE")
	fmt.Fprintln(w, "api-7f9c\tRunning\t3d")
	fmt.Fprintln(w, "worker-1\tCrashLoopBackOff\t12m")
	w.Flush()

	// Output:
	// NAME      STATUS            AGE
	// api-7f9c  Running           3d
	// worker-1  CrashLoopBackOff  12m
}
```

Local command:

```sh
go test -run Example_tabwriter -v ./examples/m08/formatting
```



`text/tabwriter` turns tab-separated cells into aligned columns, the way `kubectl get pods` prints its tables. Write rows with `\t` between cells, then call `Flush`.

## Formatting without extra allocations



Source: `examples/m08/formatting/formatting_test.go`

```go
func Example_appendf() {
	// fmt.Appendf (Go 1.19+) formats into an existing byte slice.
	line := fmt.Appendf(nil, "%s=%d", "retries", 3)
	line = fmt.Append(line, " ok")
	fmt.Println(string(line))

	// Output:
	// retries=3 ok
}
```

Local command:

```sh
go test -run Example_appendf -v ./examples/m08/formatting
```



`fmt.Appendf`, `fmt.Append` and `fmt.Appendln` (Go 1.19) format into a byte slice you provide, instead of returning a new string. Reusing one buffer across many lines saves allocations. Like the `strconv.Append` functions, this matters only in hot paths; elsewhere, `Sprintf` is perfectly fine.

## Common mistakes

### `fmt.Sprintf("%d", n)` in hot loops

`strconv.Itoa(n)` is several times faster and allocates less. Measure before optimizing, but know the option exists.

### Building SQL or shell commands with `Sprintf`

String formatting is not escaping. Use query parameters (lesson 13.1) and `exec.Command` with separate arguments.

### Ignoring `go vet` format warnings

A mismatched verb prints garbage like `%!d(string=three)` in production logs.

## Key takeaways

- Learn `%v`, `%+v`, `%T`, `%q`, widths and precision; let `go vet` check format strings.
- Use `strconv` for fast conversions, and its `Append` functions in hot paths.
- `strings.Cut` and `CutLast` (Go 1.27) replace manual index arithmetic.
- `text/tabwriter` aligns columns; `fmt.Appendf` formats into reusable buffers.

## Further reading

- [Package fmt](https://pkg.go.dev/fmt), especially the printing verbs section
- [Package strconv](https://pkg.go.dev/strconv) and [strings](https://pkg.go.dev/strings)
- [Package text/tabwriter](https://pkg.go.dev/text/tabwriter)
