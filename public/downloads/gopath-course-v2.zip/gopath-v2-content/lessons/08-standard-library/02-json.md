# 8.2 encoding/json and encoding/json/v2

Encode and decode JSON with struct tags, stream with Encoder and Decoder, customize types, handle unknown and polymorphic data, and use the encoding/json/v2 API that became generally available in Go 1.27.

## What you will learn

- How struct fields and tags map to JSON
- Decoding into structs, and what happens with missing, extra or mistyped fields
- Strict decoding and streaming with `Decoder` and `Encoder`
- Custom encoding with `MarshalText` and `MarshalJSON`
- Delaying decoding with `json.RawMessage`, and the trouble with numbers in `any`
- `omitzero` (Go 1.24) versus `omitempty`
- The `encoding/json/v2` and `jsontext` packages (Go 1.27)

## The idea

`encoding/json` uses **reflection** to map Go values to JSON and back. Exported struct fields become JSON object members; **tags** control the names and options. There is no code generation and no schema: the struct is the schema.



> **What changed in Go 1.27.** The new packages `encoding/json/v2` and `encoding/json/jsontext` are now generally available, and the classic `encoding/json` package is now implemented **on top of v2**. Its behavior is preserved and you do not need to migrate, but **error message text may differ** from older releases. Never match on JSON error strings; check error types instead, as the examples do.



## Encoding



Source: `examples/m08/jsonenc/jsonenc_test.go`

```go
type Address struct {
	City string `json:"city"`
}

type User struct {
	ID        int       `json:"id"`
	Name      string    `json:"name"`
	Email     string    `json:"email,omitempty"` // left out when empty
	Address   *Address  `json:"address,omitempty"`
	CreatedAt time.Time `json:"created_at"`
	Password  string    `json:"-"` // never encoded
	internal  int       // unexported: invisible to encoding/json
}

func Example_marshal() {
	u := User{
		ID: 1, Name: "Ana",
		CreatedAt: time.Date(2026, 10, 16, 9, 30, 0, 0, time.UTC),
		Password:  "hunter2", internal: 42,
	}
	b, err := json.Marshal(u)
	fmt.Println(string(b), err)

	pretty, _ := json.MarshalIndent(Address{City: "Chennai"}, "", "  ")
	fmt.Println(string(pretty))

	// Output:
	// {"id":1,"name":"Ana","created_at":"2026-10-16T09:30:00Z"} <nil>
	// {
	//   "city": "Chennai"
	// }
}
```

Local command:

```sh
go test -run Example_marshal -v ./examples/m08/jsonenc
```



| Tag | Effect |
|---|---|
| `json:"name"` | Use `name` as the member name |
| `json:"name,omitempty"` | Leave out if the value is empty: `0`, `""`, `false`, `nil`, empty slice or map |
| `json:"name,omitzero"` | (Go 1.24+) Leave out if the value is the zero value, or its `IsZero()` method returns true |
| `json:"-"` | Never encode or decode this field |
| `json:"name,string"` | Encode a number or bool as a JSON string |

Unexported fields (`internal`) are invisible to the encoder. Pointer fields (`Address *Address`) encode as `null` or are omitted with `omitempty` when nil, which is the usual way to make a nested object optional. `time.Time` encodes as RFC 3339.

## Decoding



Source: `examples/m08/jsonenc/jsonenc_test.go`

```go
func Example_unmarshal() {
	data := []byte(`{"id": 7, "name": "Bo", "address": {"city": "Madurai"}, "extra": true}`)

	var u User
	if err := json.Unmarshal(data, &u); err != nil { // pass a POINTER
		fmt.Println(err)
		return
	}
	fmt.Println(u.ID, u.Name, u.Address.City) // "extra" is silently ignored

	var bad User
	err := json.Unmarshal([]byte(`{"id": "seven"}`), &bad)
	var typeErr *json.UnmarshalTypeError
	fmt.Println(errors.As(err, &typeErr), typeErr.Field)

	// Output:
	// 7 Bo Madurai
	// true id
}
```

Local command:

```sh
go test -run Example_unmarshal -v ./examples/m08/jsonenc
```



- Pass a **pointer**; `Unmarshal` fills the value it points to.
- Member names match field names **case-insensitively** in `encoding/json`.
- Members with no matching field (`extra`) are **ignored**.
- Fields missing from the JSON keep whatever value they had (usually the zero value). If you need to know whether a field was present, use a pointer field.
- A type mismatch returns a `*json.UnmarshalTypeError` with the field name. Inspect it with `errors.As`.

## Strict decoding



Source: `examples/m08/jsonenc/jsonenc_test.go`

```go
func Example_strictDecoding() {
	dec := json.NewDecoder(strings.NewReader(`{"id": 1, "nmae": "typo"}`))
	dec.DisallowUnknownFields() // reject fields the struct does not have

	var u User
	err := dec.Decode(&u)
	fmt.Println(err != nil)

	// Output:
	// true
}
```

Local command:

```sh
go test -run Example_strictDecoding -v ./examples/m08/jsonenc
```



For APIs and config files, silently ignoring unknown fields hides typos (`nmae`). `Decoder.DisallowUnknownFields()` turns them into errors.

## Streaming



Source: `examples/m08/jsonenc/jsonenc_test.go`

```go
func Example_streaming() {
	// Newline-delimited JSON (one object per line), common for logs and APIs.
	input := `{"id":1,"name":"a"}
{"id":2,"name":"b"}
{"id":3,"name":"c"}`
	dec := json.NewDecoder(strings.NewReader(input))
	sum := 0
	for dec.More() {
		var u User
		if err := dec.Decode(&u); err != nil {
			fmt.Println(err)
			return
		}
		sum += u.ID
	}
	fmt.Println(sum)

	enc := json.NewEncoder(os.Stdout) // writes one value per line
	enc.Encode(map[string]int{"total": sum})

	// Output:
	// 6
	// {"total":6}
}
```

Local command:

```sh
go test -run Example_streaming -v ./examples/m08/jsonenc
```



`json.NewDecoder(r)` reads values from any `io.Reader` one at a time, so it handles large inputs and streams of concatenated values (newline-delimited JSON). `json.NewEncoder(w)` writes values to any `io.Writer`. Use them directly on HTTP request and response bodies instead of reading the body into a byte slice first.

## Custom encoding



Source: `examples/m08/jsonenc/jsonenc_test.go`

```go
type Status int

const (
	StatusUnknown Status = iota
	StatusActive
	StatusSuspended
)

var statusNames = map[Status]string{StatusActive: "active", StatusSuspended: "suspended"}

// MarshalText makes Status encode as a string, in JSON and anywhere
// else that understands encoding.TextMarshaler (also as map keys).
func (s Status) MarshalText() ([]byte, error) {
	name, ok := statusNames[s]
	if !ok {
		return nil, fmt.Errorf("unknown status %d", int(s))
	}
	return []byte(name), nil
}

func (s *Status) UnmarshalText(b []byte) error {
	for k, v := range statusNames {
		if v == string(b) {
			*s = k
			return nil
		}
	}
	return fmt.Errorf("unknown status %q", b)
}

type Account struct {
	Status Status `json:"status"`
}

func Example_customEncoding() {
	b, _ := json.Marshal(Account{Status: StatusSuspended})
	fmt.Println(string(b))

	var a Account
	err := json.Unmarshal([]byte(`{"status":"active"}`), &a)
	fmt.Println(a.Status == StatusActive, err)

	// Output:
	// {"status":"suspended"}
	// true <nil>
}
```

Local command:

```sh
go test -run Example_customEncoding -v ./examples/m08/jsonenc
```



Implement `encoding.TextMarshaler` and `TextUnmarshaler` when a type has a natural text form (enums, IDs, IP addresses). JSON then encodes it as a string, it works as a **map key**, and other encoders (YAML, XML, flags) understand it too. Implement `json.Marshaler` / `json.Unmarshaler` (`MarshalJSON`, `UnmarshalJSON`) only when you need full control over the JSON structure.

Note the receivers: `MarshalText` on the value, `UnmarshalText` on the pointer, because unmarshaling must modify the value.

## Polymorphic data with `RawMessage`



Source: `examples/m08/jsonenc/jsonenc_test.go`

```go
type Event struct {
	Type    string          `json:"type"`
	Payload json.RawMessage `json:"payload"` // decoded later, once we know the type
}

type Login struct {
	User string `json:"user"`
}

type Purchase struct {
	Amount int `json:"amount"`
}

func Example_rawMessage() {
	stream := `[{"type":"login","payload":{"user":"ana"}},{"type":"purchase","payload":{"amount":499}}]`
	var events []Event
	json.Unmarshal([]byte(stream), &events)

	for _, e := range events {
		switch e.Type {
		case "login":
			var l Login
			json.Unmarshal(e.Payload, &l)
			fmt.Println("login by", l.User)
		case "purchase":
			var p Purchase
			json.Unmarshal(e.Payload, &p)
			fmt.Println("purchase of", p.Amount)
		}
	}

	// Output:
	// login by ana
	// purchase of 499
}
```

Local command:

```sh
go test -run Example_rawMessage -v ./examples/m08/jsonenc
```



`json.RawMessage` keeps a member's raw bytes undecoded. Decode the envelope first, look at the discriminator (`type`), then decode the payload into the right struct. This is the standard way to handle event streams and webhooks with several payload shapes.

## Numbers in `any`



Source: `examples/m08/jsonenc/jsonenc_test.go`

```go
func Example_numbersInAny() {
	var v map[string]any
	json.Unmarshal([]byte(`{"count": 3, "id": 12345678901234567890}`), &v)
	fmt.Printf("%T\n", v["count"]) // every JSON number becomes float64

	dec := json.NewDecoder(strings.NewReader(`{"id": 12345678901234567890}`))
	dec.UseNumber() // keep the exact text instead
	var exact map[string]any
	dec.Decode(&exact)
	fmt.Println(exact["id"])

	// Output:
	// float64
	// 12345678901234567890
}
```

Local command:

```sh
go test -run Example_numbersInAny -v ./examples/m08/jsonenc
```



Decoding into `any` turns **every** number into `float64`, which silently loses precision for integers above 2^53 (IDs from other systems are a common victim). Decode into typed struct fields, or call `Decoder.UseNumber()` to get `json.Number` values that keep the original text.

## `omitzero` vs `omitempty`



Source: `examples/m08/jsonenc/jsonenc_test.go`

```go
type Window struct {
	Start time.Time `json:"start,omitzero"` // Go 1.24+: omitted when Start.IsZero()
	End   time.Time `json:"end,omitempty"`  // omitempty never omits a struct
}

func Example_omitZero() {
	b, _ := json.Marshal(Window{})
	fmt.Println(string(b))

	// Output:
	// {"end":"0001-01-01T00:00:00Z"}
}
```

Local command:

```sh
go test -run Example_omitZero -v ./examples/m08/jsonenc
```



`omitempty` never omits a struct value, so an unset `time.Time` appears as `"0001-01-01T00:00:00Z"`. `omitzero` (Go 1.24+) omits zero values, and respects an `IsZero()` method, which is what you usually want for times and other structs.

## `encoding/json/v2` (Go 1.27)



> The examples below need **Go 1.27 or newer**; their file is gated with `//go:build go1.27`.



The v2 API takes **options** as extra arguments instead of requiring a `Decoder` for every setting, and has stricter, more predictable defaults:



Source: `examples/m08/jsonv2/jsonv2_test.go`

```go
type Item struct {
	Name  string   `json:"name"`
	Tags  []string `json:"tags"`
	Price int      `json:"price,omitzero"`
}

func Example_v2Defaults() {
	// Same struct tags, different defaults from v1:
	// nil slices encode as [] (not null), and keys come out as written.
	b, err := json.Marshal(Item{Name: "pen"})
	fmt.Println(string(b), err)

	// Unknown members are still accepted by default...
	var it Item
	fmt.Println(json.Unmarshal([]byte(`{"name":"pen","color":"blue"}`), &it))

	// ...but can be rejected with an option, without a Decoder.
	err = json.Unmarshal([]byte(`{"name":"pen","color":"blue"}`), &it, json.RejectUnknownMembers(true))
	fmt.Println(errors.Is(err, json.ErrUnknownName))

	// Output:
	// {"name":"pen","tags":[]} <nil>
	// <nil>
	// true
}
```

Local command:

```sh
go test -run Example_v2Defaults -v ./examples/m08/jsonv2
```





Source: `examples/m08/jsonv2/jsonv2_test.go`

```go
func Example_v2Strictness() {
	var v map[string]int

	// v1 silently kept the last duplicate key; v2 rejects duplicates.
	err := json.Unmarshal([]byte(`{"a":1,"a":2}`), &v)
	fmt.Println(err != nil)

	// Map output order is sorted with Deterministic, useful for golden tests.
	b, _ := json.Marshal(map[string]int{"b": 2, "a": 1, "c": 3}, json.Deterministic(true))
	fmt.Println(string(b))

	// Output:
	// true
	// {"a":1,"b":2,"c":3}
}
```

Local command:

```sh
go test -run Example_v2Strictness -v ./examples/m08/jsonv2
```



Differences from v1 worth knowing:

| | v1 (`encoding/json`) | v2 (`encoding/json/v2`) |
|---|---|---|
| nil slice or map | `null` | `[]` or `{}` |
| Member name matching | case-insensitive | case-sensitive (option `MatchCaseInsensitiveNames`) |
| Duplicate member names | last one wins | error |
| Invalid UTF-8 in strings | replaced silently | error |
| Unknown members | ignored (`DisallowUnknownFields` on a `Decoder`) | ignored (option `RejectUnknownMembers`) |
| Streaming | `NewEncoder`, `NewDecoder` | `MarshalWrite`, `UnmarshalRead`, or `jsontext` |

The low-level `jsontext` package reads and writes JSON tokens, always producing valid JSON:



Source: `examples/m08/jsonv2/jsonv2_test.go`

```go
func Example_jsontext() {
	// jsontext works at the token level: fast, streaming, always valid JSON.
	dec := jsontext.NewDecoder(bytes.NewReader([]byte(`{"items":[1,2,3],"ok":true}`)))
	count := 0
	for {
		tok, err := dec.ReadToken()
		if err != nil {
			break // io.EOF at the end of input
		}
		if tok.Kind() == '0' { // '0' is the kind for numbers
			count++
		}
	}
	fmt.Println("numbers:", count)

	v := jsontext.Value(`{"b": 1, "a": [1,  2]}`)
	v.Compact() // also: Indent, Canonicalize
	fmt.Println(string(v))

	// Output:
	// numbers: 3
	// {"b":1,"a":[1,2]}
}
```

Local command:

```sh
go test -run Example_jsontext -v ./examples/m08/jsonv2
```



**Which should you use?** For existing code, keep `encoding/json`: it is supported, and on Go 1.27 it already runs on the faster v2 engine (unmarshaling in particular is significantly faster). For new code on Go 1.27+, v2's stricter defaults and option-based API are a good choice. Check the duplicate-name and case-sensitivity differences before switching an existing API, since clients may depend on the old behavior.

## Common mistakes

### Unexported fields

`name string` is never encoded or decoded. Capitalize it and add a tag.

### Unmarshaling into a non-pointer

`json.Unmarshal(data, u)` instead of `&u` returns an `InvalidUnmarshalError` and changes nothing.

### Relying on case-insensitive matching

It works in v1 and fails in v2. Use exact names in tags and in JSON.

### Matching error strings

The text of JSON errors changed in Go 1.27. Use `errors.As` with `*json.UnmarshalTypeError`, `*json.SyntaxError` and friends.

### Large integers through `any`

Precision loss above 2^53. Use typed fields or `UseNumber`.

## Key takeaways

- Exported fields plus tags define the JSON shape; `-`, `omitempty`, `omitzero` and `string` are the main options.
- Decoding ignores unknown members unless you ask for strictness; type mismatches return typed errors.
- Use `Decoder` and `Encoder` to stream from and to readers and writers.
- Implement `MarshalText`/`UnmarshalText` for types with a text form; use `RawMessage` for polymorphic payloads.
- Go 1.27: `encoding/json/v2` and `jsontext` are available, and `encoding/json` runs on the v2 engine with the same behavior.

## Further reading

- [Package encoding/json](https://pkg.go.dev/encoding/json)
- [Package encoding/json/v2](https://pkg.go.dev/encoding/json/v2) and [encoding/json/jsontext](https://pkg.go.dev/encoding/json/jsontext)
- [Go 1.27 release notes](https://go.dev/doc/go1.27)
- [JSON and Go](https://go.dev/blog/json) on the Go blog
