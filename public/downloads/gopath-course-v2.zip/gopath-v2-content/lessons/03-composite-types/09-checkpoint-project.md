# 3.9 Checkpoint project: wordfreq

Build a command line tool that counts word frequencies across files or standard input, using maps, slices, sorting and bufio.

## What you will build

`wordfreq` reads text from files or standard input and prints the most frequent words:

```bash
go run ./projects/wordfreq/cmd/wordfreq -n 4 projects/wordfreq/internal/count/testdata/sample.txt
```

```text
      4  go
      3  is
      1  an
      1  and
```

It uses everything from this module: a map to count, slices and `slices.SortStableFunc` to rank, a struct for results, plus `bufio.Scanner` to read line by line (a preview of Module 8).

The code is in [`projects/wordfreq`](https://github.com/Priyadharshan0903/golang-academy/tree/master/content-source/gopath-academy/projects/wordfreq).

## The design




### Split the problem

Two pure functions do the real work, so they are easy to test:

- `count.Words(r io.Reader) (map[string]int, error)` turns text into counts.
- `count.Top(counts, n) []Entry` turns counts into a ranked list.

`main` only handles flags, files and printing.

### Count words



Source: `projects/wordfreq/internal/count/count.go`

```go
// Package count counts word frequencies in text.
package count

import (
	"bufio"
	"cmp"
	"io"
	"maps"
	"slices"
	"strings"
	"unicode"
)

// Entry is one word and how often it appeared.
type Entry struct {
	Word  string
	Count int
}

// Words reads all of r and returns how often each word appears.
//
// A word is a run of letters, combining marks, digits and apostrophes.
// Marks matter: vowel signs in scripts like Tamil or Hindi are marks,
// not letters, and treating them as separators would split words.
// Words are
// lowercased, and leading or trailing apostrophes are removed, so
// "Don't" counts as "don't" and 'quoted' counts as "quoted".
func Words(r io.Reader) (map[string]int, error) {
	counts := make(map[string]int)
	sc := bufio.NewScanner(r)
	sc.Buffer(make([]byte, 64*1024), 1024*1024) // allow long lines
	for sc.Scan() {
		for _, w := range split(sc.Text()) {
			counts[w]++
		}
	}
	return counts, sc.Err()
}

// split breaks one line into normalized words.
func split(line string) []string {
	fields := strings.FieldsFunc(line, func(r rune) bool {
		return !unicode.IsLetter(r) && !unicode.IsMark(r) && !unicode.IsDigit(r) && r != '\''
	})
	words := fields[:0] // filter in place, reusing fields' array
	for _, f := range fields {
		f = strings.Trim(f, "'")
		if f != "" {
			words = append(words, strings.ToLower(f))
		}
	}
	return words
}

// Top returns the n most frequent words, most frequent first. Words
// with equal counts are ordered alphabetically, so the result is
// deterministic even though map iteration order is not.
// If n <= 0 or n exceeds the number of words, all words are returned.
func Top(counts map[string]int, n int) []Entry {
	entries := make([]Entry, 0, len(counts))
	for _, w := range slices.Sorted(maps.Keys(counts)) {
		entries = append(entries, Entry{Word: w, Count: counts[w]})
	}
	slices.SortStableFunc(entries, func(a, b Entry) int {
		return cmp.Compare(b.Count, a.Count) // descending by count
	})
	if n > 0 && n < len(entries) {
		entries = entries[:n]
	}
	return entries
}
```



Things to notice:

- `bufio.Scanner` reads one line at a time, so even huge files use little memory. Its default limit is 64 KiB per line; `sc.Buffer` raises it.
- `strings.FieldsFunc` splits on every rune that is not part of a word.
- `words := fields[:0]` filters **in place**, the pattern from lesson 3.3.
- `Top` first sorts keys alphabetically, then does a **stable** sort by count. Stability keeps the alphabetical order among equal counts, which makes the output deterministic despite random map order.

### A bug the tests found

The first version only treated letters and digits as part of a word. A test with Tamil text failed: `வணக்கம்` was counted as two words.

In scripts such as Tamil, Hindi or Bengali, vowel signs and the virama are **combining marks** (`unicode.IsMark`), not letters. Treating them as separators breaks words apart. This is the grapheme lesson from 2.4 showing up in real code, and it is why the test file includes non-English input.

### Test it



Source: `projects/wordfreq/internal/count/count_test.go`

```go
package count

import (
	"maps"
	"os"
	"slices"
	"strings"
	"testing"
)

func TestWords(t *testing.T) {
	in := "The cat, the HAT; and 'the' bat!\nDon't stop. don't 42 times 42"
	got, err := Words(strings.NewReader(in))
	if err != nil {
		t.Fatal(err)
	}
	want := map[string]int{
		"the": 3, "cat": 1, "hat": 1, "and": 1, "bat": 1,
		"don't": 2, "stop": 1, "42": 2, "times": 1,
	}
	if !maps.Equal(got, want) {
		t.Errorf("Words() =\n%v\nwant\n%v", got, want)
	}
}

func TestWordsUnicode(t *testing.T) {
	got, err := Words(strings.NewReader("Café café CAFÉ, வணக்கம் வணக்கம்"))
	if err != nil {
		t.Fatal(err)
	}
	if got["café"] != 3 {
		t.Errorf("café counted %d times, want 3", got["café"])
	}
	if len(got) != 2 {
		t.Errorf("got %d distinct words, want 2: %v", len(got), got)
	}
}

func TestWordsEmpty(t *testing.T) {
	got, err := Words(strings.NewReader(""))
	if err != nil || len(got) != 0 {
		t.Errorf("Words(\"\") = %v, %v", got, err)
	}
}

func TestTop(t *testing.T) {
	counts := map[string]int{"b": 2, "a": 2, "c": 5, "d": 1}
	got := Top(counts, 3)
	want := []Entry{{"c", 5}, {"a", 2}, {"b", 2}}
	if !slices.Equal(got, want) {
		t.Errorf("Top(3) = %v, want %v", got, want)
	}
	if all := Top(counts, 0); len(all) != 4 {
		t.Errorf("Top(0) returned %d entries, want all 4", len(all))
	}
	if all := Top(counts, 99); len(all) != 4 {
		t.Errorf("Top(99) returned %d entries, want 4", len(all))
	}
}

func TestSampleFile(t *testing.T) {
	f, err := os.Open("testdata/sample.txt")
	if err != nil {
		t.Fatal(err)
	}
	defer f.Close()

	counts, err := Words(f)
	if err != nil {
		t.Fatal(err)
	}
	top := Top(counts, 2)
	want := []Entry{{"go", 4}, {"is", 3}}
	if !slices.Equal(top, want) {
		t.Errorf("Top(2) of sample = %v, want %v", top, want)
	}
}
```



### Wire up the command



Source: `projects/wordfreq/cmd/wordfreq/main.go`

```go
// Command wordfreq prints the most frequent words in text.
//
// Usage:
//
//	wordfreq [-n N] [file ...]
//
// With no files, wordfreq reads standard input.
package main

import (
	"flag"
	"fmt"
	"io"
	"os"

	"github.com/Priyadharshan0903/gopath-academy/projects/wordfreq/internal/count"
)

func main() {
	os.Exit(run(os.Args[1:], os.Stdin, os.Stdout, os.Stderr))
}

func run(args []string, stdin io.Reader, stdout, stderr io.Writer) int {
	fs := flag.NewFlagSet("wordfreq", flag.ContinueOnError)
	fs.SetOutput(stderr)
	n := fs.Int("n", 10, "number of words to show (0 for all)")
	if err := fs.Parse(args); err != nil {
		return 2
	}

	totals := make(map[string]int)
	add := func(r io.Reader) error {
		counts, err := count.Words(r)
		if err != nil {
			return err
		}
		for w, c := range counts {
			totals[w] += c
		}
		return nil
	}

	if fs.NArg() == 0 {
		if err := add(stdin); err != nil {
			fmt.Fprintln(stderr, "wordfreq:", err)
			return 1
		}
	}
	for _, name := range fs.Args() {
		if err := addFile(name, add); err != nil {
			fmt.Fprintln(stderr, "wordfreq:", err)
			return 1
		}
	}

	for _, e := range count.Top(totals, *n) {
		fmt.Fprintf(stdout, "%7d  %s\n", e.Count, e.Word)
	}
	return 0
}

// addFile opens one file and feeds it to add. It is a separate
// function so the deferred Close runs after each file, not at the end.
func addFile(name string, add func(io.Reader) error) error {
	f, err := os.Open(name)
	if err != nil {
		return err
	}
	defer f.Close()
	return add(f)
}
```



`addFile` is a separate function so that each file's `defer f.Close()` runs right after that file is processed, avoiding the `defer` in a loop trap from lesson 2.7.




## Try it

```bash
cd projects/wordfreq
go test ./...
cat ../../lessons/*/*.md | go run ./cmd/wordfreq -n 15
```

## Stretch goals

1. Add a `-min` flag to ignore words shorter than N runes (use `utf8.RuneCountInString`, not `len`).
2. Add a `-stop` flag with a file of stop words to ignore (a set from lesson 3.5).
3. Return an iterator from a new `count.WordsSeq(r io.Reader) iter.Seq[string]` and rebuild `Words` on top of it.
4. Print the output as JSON with a `-json` flag (a preview of lesson 8.2).

## Module 3 recap

You can now:

- Explain the difference between arrays and slices, and predict when slices share memory
- Avoid the common `append` and memory retention traps
- Use maps idiomatically for lookups, sets, counters and grouping
- Model data with named types, structs and tags
- Compose types with embedding, without mistaking it for inheritance
- Write and consume iterators

Next is **[Module 4: Methods, interfaces and generics](../04-methods-interfaces-generics/README.md)**, where these types get behavior.
