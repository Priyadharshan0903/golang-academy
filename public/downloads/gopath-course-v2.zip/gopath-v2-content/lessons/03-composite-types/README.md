# 3. Composite types

Slices, maps and structs are the data structures you will use in almost every Go program. They look familiar, but their **memory behavior** is different from lists, dictionaries and classes in other languages. This module explains what happens underneath, so the surprising cases stop being surprising.

**Time:** about 3 to 4 hours, plus exercises and the project.

- [3.1 Arrays and why you rarely use them directly](01-arrays.md)
- [3.2 Slices: length, capacity and the backing array](02-slices.md)
- [3.3 Slice gotchas: aliasing, append surprises, memory retention](03-slice-gotchas.md)
- [3.4 The slices and maps packages](04-slices-and-maps-packages.md)
- [3.5 Maps: usage, iteration order, concurrency warning](05-maps.md)
- [3.6 Named types, structs, tags and anonymous structs](06-structs.md)
- [3.7 Embedding and composition](07-embedding.md)
- [3.8 Iterators and range-over-func](08-iterators.md)
- [3.9 Checkpoint project: wordfreq](09-checkpoint-project.md)
