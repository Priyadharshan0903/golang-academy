# 3.1 Arrays and why you rarely use them directly

Go arrays have a fixed length that is part of their type and are copied by value. Learn where that is useful and why slices are the everyday choice.

## What you will learn

- How arrays are declared and why their length is part of the type
- Why assigning or passing an array copies all of it
- The few places arrays are the right tool
- How arrays relate to slices, which you will use instead most of the time

## The idea

A Go array is a **fixed-size sequence of elements of one type**. The size is part of the type: `[3]int` and `[4]int` are different, incompatible types.

Arrays are **values**, not references. Assigning an array to another variable, or passing it to a function, copies every element. This is the opposite of arrays in Java, Python or JavaScript, where the variable is a reference to shared data.



Source: `examples/m03/arrays/arrays_test.go`

```go
func Example_basics() {
	var scores [3]int // length is part of the type: [3]int
	scores[0] = 90
	fmt.Println(scores, len(scores))

	primes := [...]int{2, 3, 5, 7} // ... lets the compiler count
	fmt.Println(len(primes))

	// [3]int and [4]int are different types:
	// scores = primes would not compile.

	// Output:
	// [90 0 0] 3
	// 4
}
```

Local command:

```sh
go test -run Example_basics -v ./examples/m03/arrays
```



## Value semantics



Source: `examples/m03/arrays/arrays_test.go`

```go
func Example_valueSemantics() {
	a := [3]string{"x", "y", "z"}
	b := a // copies all three elements
	b[0] = "CHANGED"
	fmt.Println(a[0], b[0])

	// Arrays of comparable elements can be compared with ==.
	fmt.Println(a == [3]string{"x", "y", "z"})

	// Output:
	// x CHANGED
	// true
}
```

Local command:

```sh
go test -run Example_valueSemantics -v ./examples/m03/arrays
```



Copying is predictable and safe (no one else can change your copy), but for large arrays it is expensive. A function that takes a `[1_000_000]byte` copies a megabyte on every call.

Arrays whose element type is comparable can be compared with `==`, element by element.

## Where arrays are the right tool

You will rarely declare arrays in application code, but they do show up:

- **Fixed-size values with meaning**: a SHA-256 hash is `[32]byte` (`sha256.Sum256` returns exactly that), an IPv4 address fits in `[4]byte`, an RGB color in `[3]uint8`.
- **Map keys**: because arrays are comparable values, they work as keys where a slice cannot.
- **The backing store of a slice**: every slice points to an array underneath. That is the topic of the next lesson.



Source: `examples/m03/arrays/arrays_test.go`

```go
// Because arrays are comparable values, they make good map keys.
type point [2]int

func Example_asMapKey() {
	visited := map[point]bool{}
	visited[point{1, 2}] = true
	fmt.Println(visited[point{1, 2}], visited[point{2, 1}])

	// Output:
	// true false
}
```

Local command:

```sh
go test -run Example_asMapKey -v ./examples/m03/arrays
```



## Arrays vs slices at a glance

| | Array `[N]T` | Slice `[]T` |
|---|---|---|
| Length | Fixed, part of the type | Can grow with `append` |
| Assignment and passing | Copies all elements | Copies a small header; elements are shared |
| Comparable with `==` | Yes (if elements are) | No (only to `nil`) |
| Usable as a map key | Yes | No |
| Typical use | Hashes, fixed-size buffers, keys | Almost everything else |

## Common mistakes

### Expecting a function to modify an array argument

```go
func reset(a [3]int) { a[0] = 0 } // modifies a copy
```

Pass a pointer (`*[3]int`) or, much more commonly, use a slice.

### Confusing `[]int{1, 2}` and `[2]int{1, 2}`

The first is a slice literal, the second an array literal. A missing number or `...` between the brackets is the only difference, and they behave very differently.

### Ranging over a large array by value

`for i, v := range bigArray` evaluates `bigArray` once, which copies it. Range over a slice of it instead (`bigArray[:]`) or over a pointer to it.

## Key takeaways

- An array's length is part of its type, and it never changes.
- Arrays are values: assignment and function calls copy every element.
- Use arrays for fixed-size values like hashes and for comparable map keys.
- For general lists of data, use slices.

## Further reading

- [Array types](https://go.dev/ref/spec#Array_types) in the spec
- [Go Slices: usage and internals](https://go.dev/blog/slices-intro), which starts with arrays
