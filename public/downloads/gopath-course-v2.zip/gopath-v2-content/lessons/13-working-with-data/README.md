# 13. Working with data

Most services are, at their core, a careful layer over a database. This module covers the parts that decide whether that layer is correct under load: pools, parameters, transactions, locks, migrations and caches. It uses **PostgreSQL** and **Redis**, the most common pair in Go services, and every example runs against real servers.

The database examples live in the `examples/thirdparty` module (they need the pgx and go-redis libraries). They are skipped unless a database is available; the [setup takes two docker commands](https://github.com/Priyadharshan0903/golang-academy/tree/master/content-source/gopath-academy/examples/thirdparty#databases-module-13).

**Time:** about 5 to 6 hours, plus the exercise and projects.

- [13.1 database/sql and connection pooling](01-database-sql.md)
- [13.2 pgx and PostgreSQL](02-pgx.md)
- [13.3 Migrations](03-migrations.md)
- [13.4 Transactions and context](04-transactions.md)
- [13.5 Caching with Redis](05-caching-redis.md)
- [13.6 Exercise: a read-through cache](06-exercise.md)
- [13.7 Project milestone: the shortener on PostgreSQL](07-project-shortener-postgres.md)
- [13.8 Project: a PostgreSQL job queue](08-project-jobqueue.md)
