# 13.4 Transactions and context

Use transactions correctly from Go: a WithTx helper, the lost update problem and its fixes, row locks with FOR UPDATE, deadlocks and lock ordering, isolation levels and retries, and cancelling queries with context, all demonstrated against PostgreSQL.

## What you will learn

- A safe pattern for transactions in Go: commit on success, roll back on everything else
- The **lost update** problem, reproduced, and two ways to fix it
- Row locks with `SELECT ... FOR UPDATE`
- **Deadlocks**, reproduced, and the lock-ordering fix
- Isolation levels and retrying serialization failures
- How a context deadline cancels a running query

## The pattern

A transaction groups statements so they succeed or fail together. In Go, the shape is always the same:



Source: `examples/thirdparty/db/txdemo/txdemo.go`

```go
// WithTx runs fn in a transaction. It commits if fn returns nil and
// rolls back otherwise, including when fn panics.
func WithTx(ctx context.Context, pool *pgxpool.Pool, fn func(pgx.Tx) error) (err error) {
	tx, err := pool.Begin(ctx)
	if err != nil {
		return err
	}
	// Rollback after a successful Commit is a no-op, so this is safe to
	// defer unconditionally.
	defer tx.Rollback(context.WithoutCancel(ctx))

	if err := fn(tx); err != nil {
		return err
	}
	return tx.Commit(ctx)
}
```



- **`defer tx.Rollback(...)`** runs on every exit path: an error, an early return, a panic. After a successful `Commit` it does nothing, so it is safe to defer unconditionally.
- **`context.WithoutCancel`** for the rollback: if the request was cancelled, we still want the rollback to reach the database.
- The callback gets a `pgx.Tx` and runs every statement through it. A statement accidentally run on the pool instead of `tx` executes **outside** the transaction, a subtle bug.

pgx ships the same idea as `pgx.BeginFunc`, which the migrator in lesson 13.3 uses. The test confirms the rollback:



Source: `examples/thirdparty/db/txdemo/txdemo_test.go`

```go
func TestRollbackOnError(t *testing.T) {
	pool := setup(t)
	err := WithTx(t.Context(), pool, func(tx pgx.Tx) error {
		if _, err := tx.Exec(t.Context(), `UPDATE accounts SET balance = 0 WHERE id = 'alice'`); err != nil {
			return err
		}
		return errors.New("something failed after the update")
	})
	if err == nil || balance(t, pool, "alice") != 100 {
		t.Fatalf("err=%v balance=%d: the update should have been rolled back", err, balance(t, pool, "alice"))
	}
}
```



## The lost update

A transaction alone does not make read-then-write logic safe. This withdrawal reads the balance, computes, and writes the result:



Source: `examples/thirdparty/db/txdemo/txdemo.go`

```go
// WithdrawRacy reads the balance, then writes back a new value. Two of
// these running at the same time can both read 100 and both write 90:
// a lost update. pause widens the gap between read and write so the
// test can make the race happen reliably.
func WithdrawRacy(ctx context.Context, pool *pgxpool.Pool, id string, amount int64, pause func()) error {
	return WithTx(ctx, pool, func(tx pgx.Tx) error {
		var balance int64
		if err := tx.QueryRow(ctx, `SELECT balance FROM accounts WHERE id = $1`, id).Scan(&balance); err != nil {
			return err
		}
		pause()
		_, err := tx.Exec(ctx, `UPDATE accounts SET balance = $1 WHERE id = $2`, balance-amount, id)
		return err
	})
}

// WithdrawLocked does the same, but SELECT ... FOR UPDATE locks the
// row: a second transaction waits at its SELECT until the first commits,
// then reads the new balance.
func WithdrawLocked(ctx context.Context, pool *pgxpool.Pool, id string, amount int64, pause func()) error {
	return WithTx(ctx, pool, func(tx pgx.Tx) error {
		var balance int64
		if err := tx.QueryRow(ctx, `SELECT balance FROM accounts WHERE id = $1 FOR UPDATE`, id).Scan(&balance); err != nil {
			return err
		}
		pause()
		_, err := tx.Exec(ctx, `UPDATE accounts SET balance = $1 WHERE id = $2`, balance-amount, id)
		return err
	})
}
```



Two withdrawals of 10 from a balance of 100, at the same time:



Source: `examples/thirdparty/db/txdemo/txdemo_test.go`

```go
func TestLostUpdate(t *testing.T) {
	for _, tc := range []struct {
		name     string
		withdraw func(context.Context, *pgxpool.Pool, string, int64, func()) error
		want     int64
	}{
		{"racy", WithdrawRacy, 90},     // one withdrawal is lost
		{"locked", WithdrawLocked, 80}, // both count
	} {
		t.Run(tc.name, func(t *testing.T) {
			pool := setup(t)
			var wg sync.WaitGroup
			for range 2 {
				wg.Go(func() {
					pause := func() { time.Sleep(100 * time.Millisecond) }
					if err := tc.withdraw(t.Context(), pool, "alice", 10, pause); err != nil {
						t.Error(err)
					}
				})
			}
			wg.Wait()
			got := balance(t, pool, "alice")
			t.Logf("two withdrawals of 10 from 100 left %d", got)
			if got != tc.want {
				t.Fatalf("balance %d, want %d", got, tc.want)
			}
		})
	}
}
```

Local command:

```sh
cd examples/thirdparty && go test -run TestLostUpdate -v ./db/txdemo
```



```text
racy:   two withdrawals of 10 from 100 left 90
locked: two withdrawals of 10 from 100 left 80
```

In the racy version, both transactions read 100 and both write 90: one withdrawal vanished. PostgreSQL's default isolation level, **READ COMMITTED**, does not prevent this, and neither does a transaction by itself. (The test widens the gap between read and write with a pause, so the race happens every time instead of occasionally in production.)

Two fixes:

1. **Lock the row** with `SELECT ... FOR UPDATE`. The second transaction blocks at its `SELECT` until the first commits, then reads 90. That is `WithdrawLocked`, which leaves 80.
2. **Do the arithmetic in the database**: `UPDATE accounts SET balance = balance - $1 WHERE id = $2`. A single statement reads and writes atomically, with no window for a race. This is simpler and faster whenever the logic fits in SQL; the `Transfer` function below uses it, with `AND balance >= $1` to refuse overdrafts.

## Deadlocks

`TransferNaive` moves money with two atomic `UPDATE`s in one transaction. Now run transfers in **both** directions at once:



Source: `examples/thirdparty/db/txdemo/txdemo.go`

```go
var ErrInsufficientFunds = errors.New("insufficient funds")

// TransferNaive moves amount between accounts atomically: both updates
// happen, or neither does. Each UPDATE computes the new balance inside
// the database, so there is no read-then-write race. But it can
// deadlock: see TestDeadlock.
func TransferNaive(ctx context.Context, pool *pgxpool.Pool, from, to string, amount int64) error {
	return WithTx(ctx, pool, func(tx pgx.Tx) error {
		return move(ctx, tx, from, to, amount)
	})
}

// Transfer first locks both rows in a fixed order (by id), so two
// transfers in opposite directions can never wait for each other.
func Transfer(ctx context.Context, pool *pgxpool.Pool, from, to string, amount int64) error {
	return WithTx(ctx, pool, func(tx pgx.Tx) error {
		if _, err := tx.Exec(ctx,
			`SELECT id FROM accounts WHERE id = ANY($1) ORDER BY id FOR UPDATE`,
			[]string{from, to}); err != nil {
			return err
		}
		return move(ctx, tx, from, to, amount)
	})
}

func move(ctx context.Context, tx pgx.Tx, from, to string, amount int64) error {
	tag, err := tx.Exec(ctx,
		`UPDATE accounts SET balance = balance - $1 WHERE id = $2 AND balance >= $1`, amount, from)
	if err != nil {
		return err
	}
	if tag.RowsAffected() == 0 {
		return fmt.Errorf("transfer %d from %s: %w", amount, from, ErrInsufficientFunds)
	}
	_, err = tx.Exec(ctx, `UPDATE accounts SET balance = balance + $1 WHERE id = $2`, amount, to)
	return err
}
```





Source: `examples/thirdparty/db/txdemo/txdemo_test.go`

```go
// concurrentTransfers runs 20 transfers of 1, half in each direction,
// and counts the errors by SQLSTATE code.
func concurrentTransfers(t *testing.T, pool *pgxpool.Pool,
	transfer func(context.Context, *pgxpool.Pool, string, string, int64) error) map[string]int {
	var mu sync.Mutex
	codes := map[string]int{}
	var wg sync.WaitGroup
	for i := range 20 {
		wg.Go(func() {
			from, to := "alice", "bob"
			if i%2 == 0 {
				from, to = to, from
			}
			err := transfer(t.Context(), pool, from, to, 1)
			var pgErr *pgconn.PgError
			mu.Lock()
			defer mu.Unlock()
			switch {
			case errors.As(err, &pgErr):
				codes[pgErr.Code]++
			case errors.Is(err, ErrInsufficientFunds):
				codes["insufficient funds"]++
			case err != nil:
				t.Error(err)
			}
		})
	}
	wg.Wait()
	if total := balance(t, pool, "alice") + balance(t, pool, "bob"); total != 100 {
		t.Fatalf("total %d, want 100: money was created or destroyed", total)
	}
	return codes
}

func TestDeadlock(t *testing.T) {
	naive := concurrentTransfers(t, setup(t), TransferNaive)
	t.Logf("naive transfers, errors by code: %v (40P01 is deadlock_detected)", naive)

	ordered := concurrentTransfers(t, setup(t), Transfer)
	t.Logf("ordered locking, errors by code: %v", ordered)
	if ordered["40P01"] != 0 {
		t.Fatalf("ordered locking deadlocked %d times", ordered["40P01"])
	}
}
```

Local command:

```sh
cd examples/thirdparty && go test -run TestDeadlock -v ./db/txdemo
```



```text
naive transfers, errors by code: map[40P01:6 insufficient funds:4] (40P01 is deadlock_detected)
ordered locking, errors by code: map[]
```

A transfer from alice to bob locks alice's row, then bob's. A transfer from bob to alice locks bob's, then alice's. When they interleave, each holds the lock the other needs, forever. PostgreSQL detects the cycle (after `deadlock_timeout`, one second by default) and aborts one of the transactions with SQLSTATE **40P01**. The total money stays correct, because the aborted transaction rolls back, but requests fail.

The fix is the same as for code that takes several `sync.Mutex` locks (lesson 6.4): **acquire locks in a consistent order**. `Transfer` first locks both rows with `SELECT ... ORDER BY id FOR UPDATE`, so every transfer locks alice before bob regardless of direction, and no cycle can form. Zero deadlocks.

## Isolation levels and retries

PostgreSQL offers three isolation levels in practice:

| Level | Guarantees | Cost |
|---|---|---|
| READ COMMITTED (default) | each statement sees data committed before it started | lost updates possible, as shown |
| REPEATABLE READ | the whole transaction sees one snapshot; concurrent updates to the same row fail with **40001** | you must retry |
| SERIALIZABLE | the result equals some serial order of the transactions; conflicts fail with **40001** | you must retry, more often |

```go
tx, err := pool.BeginTx(ctx, pgx.TxOptions{IsoLevel: pgx.Serializable})
```

Higher levels replace "silently wrong" with "fails, please retry". Code using them needs a retry loop: run the whole transaction again, a few times with backoff, when the error code is `40001` (serialization_failure) or `40P01` (deadlock_detected). Never retry part of a transaction.

A practical approach: use READ COMMITTED with explicit locking (`FOR UPDATE`) or single-statement updates for the hot paths you understand, and SERIALIZABLE for complex invariants that are hard to protect by hand.

## Context cancels queries

Every pgx method takes a context. When the context ends, pgx asks the server to cancel the running query:



Source: `examples/thirdparty/db/txdemo/txdemo_test.go`

```go
func TestContextCancelsQuery(t *testing.T) {
	pool := setup(t)
	ctx, cancel := context.WithTimeout(t.Context(), 100*time.Millisecond)
	defer cancel()

	start := time.Now()
	_, err := pool.Exec(ctx, `SELECT pg_sleep(5)`)
	elapsed := time.Since(start)
	t.Logf("a 5 s query with a 100 ms deadline returned after %v: %v", elapsed.Round(10*time.Millisecond), err)
	if err == nil || elapsed > 2*time.Second {
		t.Fatal("the query should have been cancelled")
	}
	if !errors.Is(err, context.DeadlineExceeded) {
		t.Errorf("errors.Is(err, context.DeadlineExceeded) = false")
	}
}
```

Local command:

```sh
cd examples/thirdparty && go test -run TestContextCancelsQuery -v ./db/txdemo
```



```text
a 5 s query with a 100 ms deadline returned after 100ms: timeout: context deadline exceeded
```

This is why handlers pass `r.Context()` to every query: when a client disconnects or a deadline passes, the database stops working on a result nobody will read. The error wraps `context.DeadlineExceeded` (or `context.Canceled`), so `errors.Is` identifies it.

Keep transactions **short**. While a transaction is open it holds a connection and its locks; calling another service or waiting for user input inside one turns a slow dependency into blocked rows for everyone.

## Common mistakes

### Read, compute, write without a lock

Lost updates under concurrency. Use one `UPDATE ... SET x = x - $1`, or `FOR UPDATE`.

### Locking rows in different orders

Deadlocks. Lock in a consistent order, such as by primary key.

### Using the pool inside a transaction function

The statement runs outside the transaction. Use the `tx` you were given.

### Long transactions

Network calls inside a transaction hold locks and connections. Do them before or after.

### Retrying only the failed statement

After 40001 or 40P01 the whole transaction is aborted. Retry the whole function.

## Key takeaways

- Begin, `defer Rollback`, run everything on `tx`, `Commit`: or use a helper like `WithTx` or `pgx.BeginFunc`.
- READ COMMITTED allows lost updates: compute in a single `UPDATE`, or lock with `SELECT ... FOR UPDATE`.
- Lock rows in a consistent order to avoid deadlocks (40P01).
- REPEATABLE READ and SERIALIZABLE turn anomalies into 40001 errors, which require retrying the whole transaction.
- Contexts cancel running queries; pass the request context everywhere, and keep transactions short.

## Further reading

- [PostgreSQL: transaction isolation](https://www.postgresql.org/docs/current/transaction-iso.html)
- [PostgreSQL: explicit locking](https://www.postgresql.org/docs/current/explicit-locking.html)
