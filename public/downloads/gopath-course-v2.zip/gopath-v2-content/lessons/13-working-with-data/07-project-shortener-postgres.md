# 13.7 Project milestone: the shortener on PostgreSQL

Milestone 3 of the URL shortener: a PostgreSQL store with embedded migrations, an optional Redis cache, and one conformance test suite that every store implementation must pass.

## The milestone

| Milestone | After module | Adds | Status |
|---|---|---|---|
| 1. Core | 5. Errors | Domain types, errors, validation, `Service`, in-memory store | done |
| 2. HTTP API | 12. HTTP services | JSON API, redirects, middleware, metrics, shutdown | done |
| **3. Postgres** (this lesson) | 13. Working with data | PostgreSQL store, migrations, Redis cache | done |
| 4. Deploy | 15. Cloud native | Container image and Kubernetes manifests | next |

Links now survive restarts and can be shared by many replicas. The interesting part is what did **not** change: the `link` package and the whole HTTP layer are untouched. The `Store` interface from milestone 1 was designed for this moment.

```text
internal/link/linktest/   a conformance suite every Store must pass      (new)
internal/postgres/        Store on pgx, migrations embedded in the binary (new)
internal/cache/           a caching Store wrapping another Store          (new)
internal/pgtest/          a fresh schema per test                         (new)
cmd/shortener/            chooses the store from the configuration        (changed)
```

## Run it with a database

```bash
docker run -d --name gopath-pg -e POSTGRES_PASSWORD=pg -p 5432:5432 postgres:16
docker run -d --name gopath-redis -p 6379:6379 redis:7

cd projects/shortener
DATABASE_URL='postgres://postgres:pg@localhost:5432/postgres?sslmode=disable' \
REDIS_ADDR=localhost:6379 LOG_FORMAT=text go run ./cmd/shortener
```

On start-up it applies migrations and logs `migrations applied=[0001_create_links.sql]`; the second start logs `applied=[]`. Without `DATABASE_URL` it still runs in memory, with a warning.

## The Postgres store



Source: `projects/shortener/internal/postgres/store.go`

```go
// Package postgres is a link.Store backed by PostgreSQL, using pgx.
package postgres

import (
	"context"
	"errors"
	"fmt"

	"github.com/Priyadharshan0903/gopath-academy/projects/shortener/internal/link"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgconn"
	"github.com/jackc/pgx/v5/pgxpool"
)

// Store implements link.Store.
type Store struct {
	pool *pgxpool.Pool
}

// NewStore returns a Store using pool. Run Migrate first.
func NewStore(pool *pgxpool.Pool) *Store { return &Store{pool: pool} }

// Create inserts l. The primary key on code makes the database reject
// duplicates atomically; that error becomes link.ErrCodeTaken.
func (s *Store) Create(ctx context.Context, l link.Link) error {
	_, err := s.pool.Exec(ctx,
		`INSERT INTO links (code, url, created_at) VALUES ($1, $2, $3)`,
		l.Code, l.URL, l.CreatedAt)
	var pgErr *pgconn.PgError
	if errors.As(err, &pgErr) && pgErr.Code == "23505" { // unique_violation
		return link.ErrCodeTaken
	}
	if err != nil {
		return fmt.Errorf("insert link: %w", err)
	}
	return nil
}

// Get returns the link for code, or link.ErrNotFound.
func (s *Store) Get(ctx context.Context, code string) (link.Link, error) {
	var l link.Link
	err := s.pool.QueryRow(ctx,
		`SELECT code, url, created_at FROM links WHERE code = $1`, code,
	).Scan(&l.Code, &l.URL, &l.CreatedAt)
	if errors.Is(err, pgx.ErrNoRows) {
		return link.Link{}, link.ErrNotFound
	}
	if err != nil {
		return link.Link{}, fmt.Errorf("select link: %w", err)
	}
	l.CreatedAt = l.CreatedAt.UTC() // pgx returns timestamptz in the local time zone
	return l, nil
}

// Delete removes the link for code, or returns link.ErrNotFound.
func (s *Store) Delete(ctx context.Context, code string) error {
	tag, err := s.pool.Exec(ctx, `DELETE FROM links WHERE code = $1`, code)
	if err != nil {
		return fmt.Errorf("delete link: %w", err)
	}
	if tag.RowsAffected() == 0 {
		return link.ErrNotFound
	}
	return nil
}
```



Two translations make it a correct `link.Store`:

- **Unique violation (23505) becomes `link.ErrCodeTaken`.** The primary key on `code` makes the database decide, atomically, which of two concurrent requests for the same custom code wins. The service's retry loop for random codes (milestone 1) keeps working unchanged, because it only looks for `ErrCodeTaken`.
- **`pgx.ErrNoRows` becomes `link.ErrNotFound`**, which the HTTP layer already maps to 404.

And one normalization: pgx returns `timestamptz` values in the local time zone, so `Get` converts to UTC, as the in-memory store returns them.

Migrations are the ones from lesson 13.3, embedded in the binary and applied under an advisory lock.

## One test suite for every store

How do you know the Postgres store behaves like the memory store that all the HTTP tests used? Write the expectations once, as a **conformance suite**, and run it against every implementation:



Source: `projects/shortener/internal/link/linktest/linktest.go`

```go
// Package linktest is a conformance test suite for link.Store
// implementations. Every store (memory, Postgres, cached) runs the same
// tests, so they all behave the way link.Service expects.
package linktest

import (
	"context"
	"errors"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	"github.com/Priyadharshan0903/gopath-academy/projects/shortener/internal/link"
)

// Run runs the suite. newStore must return an empty store.
func Run(t *testing.T, newStore func(t *testing.T) link.Store) {
	t.Run("CreateThenGet", func(t *testing.T) {
		s := newStore(t)
		ctx := context.Background()
		want := link.Link{Code: "abc", URL: "https://go.dev", CreatedAt: time.Date(2026, 1, 2, 3, 4, 5, 6000, time.UTC)}
		if err := s.Create(ctx, want); err != nil {
			t.Fatal(err)
		}
		got, err := s.Get(ctx, "abc")
		if err != nil {
			t.Fatal(err)
		}
		// Stores may keep only microseconds (PostgreSQL does) and may
		// return another time zone; Equal compares instants.
		if got.Code != want.Code || got.URL != want.URL || !got.CreatedAt.Equal(want.CreatedAt) {
			t.Fatalf("Get = %+v, want %+v", got, want)
		}
		if got.CreatedAt.Location() != time.UTC {
			t.Errorf("CreatedAt should be in UTC, got %v", got.CreatedAt.Location())
		}
	})

	t.Run("GetMissing", func(t *testing.T) {
		_, err := newStore(t).Get(context.Background(), "nope")
		if !errors.Is(err, link.ErrNotFound) {
			t.Fatalf("err = %v, want ErrNotFound", err)
		}
	})

	t.Run("CreateDuplicate", func(t *testing.T) {
		s := newStore(t)
		ctx := context.Background()
		l := link.Link{Code: "dup", URL: "https://a.example", CreatedAt: time.Now().UTC()}
		if err := s.Create(ctx, l); err != nil {
			t.Fatal(err)
		}
		l.URL = "https://b.example"
		if err := s.Create(ctx, l); !errors.Is(err, link.ErrCodeTaken) {
			t.Fatalf("err = %v, want ErrCodeTaken", err)
		}
		got, _ := s.Get(ctx, "dup")
		if got.URL != "https://a.example" {
			t.Fatalf("the duplicate overwrote the original: %+v", got)
		}
	})

	t.Run("Delete", func(t *testing.T) {
		s := newStore(t)
		ctx := context.Background()
		l := link.Link{Code: "gone", URL: "https://go.dev", CreatedAt: time.Now().UTC()}
		if err := s.Create(ctx, l); err != nil {
			t.Fatal(err)
		}
		if _, err := s.Get(ctx, "gone"); err != nil { // with a cache, this fills it
			t.Fatal(err)
		}
		if err := s.Delete(ctx, "gone"); err != nil {
			t.Fatal(err)
		}
		if _, err := s.Get(ctx, "gone"); !errors.Is(err, link.ErrNotFound) {
			t.Fatalf("Get after Delete: err = %v, want ErrNotFound", err)
		}
		if err := s.Delete(ctx, "gone"); !errors.Is(err, link.ErrNotFound) {
			t.Fatalf("second Delete: err = %v, want ErrNotFound", err)
		}
		if err := s.Create(ctx, l); err != nil {
			t.Fatalf("the code should be free again after Delete: %v", err)
		}
	})

	t.Run("ConcurrentCreateSameCode", func(t *testing.T) {
		s := newStore(t)
		var ok, taken atomic.Int64
		var wg sync.WaitGroup
		for range 20 {
			wg.Go(func() {
				err := s.Create(context.Background(), link.Link{Code: "race", URL: "https://go.dev", CreatedAt: time.Now().UTC()})
				switch {
				case err == nil:
					ok.Add(1)
				case errors.Is(err, link.ErrCodeTaken):
					taken.Add(1)
				default:
					t.Error(err)
				}
			})
		}
		wg.Wait()
		if ok.Load() != 1 || taken.Load() != 19 {
			t.Fatalf("%d succeeded and %d got ErrCodeTaken, want 1 and 19", ok.Load(), taken.Load())
		}
	})
}
```



Each implementation needs only a few lines:

```go
func TestStoreContract(t *testing.T) {
	linktest.Run(t, func(t *testing.T) link.Store {
		pool := pgtest.Pool(t)          // a fresh, empty schema
		if _, err := postgres.Migrate(context.Background(), pool); err != nil {
			t.Fatal(err)
		}
		return postgres.NewStore(pool)
	})
}
```

The suite runs for `MemoryStore`, the Postgres store, and the cached store. It pins down details that are easy to get subtly different, such as returning `CreatedAt` in UTC even though pgx returns local time, and keeping only microseconds as PostgreSQL does. `ConcurrentCreateSameCode` checks that 20 simultaneous creates of one code produce exactly one success and 19 `ErrCodeTaken`, in memory (a mutex) and in Postgres (the primary key) alike.

This pattern, an exported test suite in a `...test` package, is how the standard library tests interfaces too: `testing/fstest.TestFS` checks any `fs.FS` implementation, and `golang.org/x/net/nettest` does the same for `net.Conn`.

## The cache is just another Store



Source: `projects/shortener/internal/cache/cache.go`

```go
// Package cache wraps a link.Store with a Redis cache (cache-aside,
// lesson 13.5). Links never change once created, which makes them
// ideal to cache: there is nothing to invalidate.
package cache

import (
	"context"
	"encoding/json"
	"errors"
	"log/slog"
	"time"

	"github.com/Priyadharshan0903/gopath-academy/projects/shortener/internal/link"
	"github.com/redis/go-redis/v9"
	"golang.org/x/sync/singleflight"
)

// Store is a link.Store that serves Get from Redis when it can.
type Store struct {
	next   link.Store
	rdb    *redis.Client
	ttl    time.Duration
	logger *slog.Logger
	group  singleflight.Group
}

// New wraps next. Entries expire after ttl.
func New(next link.Store, rdb *redis.Client, ttl time.Duration, logger *slog.Logger) *Store {
	return &Store{next: next, rdb: rdb, ttl: ttl, logger: logger}
}

func key(code string) string { return "shortener:link:" + code }

// Create writes to the underlying store only. The first Get fills the
// cache.
func (s *Store) Create(ctx context.Context, l link.Link) error {
	return s.next.Create(ctx, l)
}

// Delete removes the link from the underlying store, then from the
// cache. Deleting in this order means a concurrent Get can at worst
// re-cache the link just before it is deleted from the store; the
// cache entry is then removed right after.
func (s *Store) Delete(ctx context.Context, code string) error {
	if err := s.next.Delete(ctx, code); err != nil {
		return err
	}
	if err := s.rdb.Del(ctx, key(code)).Err(); err != nil {
		s.logger.Warn("cache delete failed", "code", code, "error", err)
	}
	return nil
}

// Get looks in Redis, then falls back to the underlying store. Redis
// errors are logged and otherwise ignored: the cache is an
// optimization, never a dependency.
func (s *Store) Get(ctx context.Context, code string) (link.Link, error) {
	b, err := s.rdb.Get(ctx, key(code)).Bytes()
	if err == nil {
		var l link.Link
		if err := json.Unmarshal(b, &l); err == nil {
			return l, nil
		}
		s.logger.Warn("corrupt cache entry", "code", code)
	} else if !errors.Is(err, redis.Nil) {
		s.logger.Warn("cache read failed", "code", code, "error", err)
	}

	// Concurrent misses for one code share a single store lookup.
	v, err, _ := s.group.Do(code, func() (any, error) {
		l, err := s.next.Get(context.WithoutCancel(ctx), code)
		if err != nil {
			return link.Link{}, err // misses are not cached
		}
		if b, err := json.Marshal(l); err == nil {
			if err := s.rdb.Set(ctx, key(code), b, s.ttl).Err(); err != nil {
				s.logger.Warn("cache write failed", "code", code, "error", err)
			}
		}
		return l, nil
	})
	return v.(link.Link), err
}
```



`cache.Store` wraps any `link.Store` and is itself a `link.Store`: the decorator pattern, through a one-method-plus-one interface. Links never change after creation, so there is no invalidation, only a TTL to bound memory. Misses are not cached, so a link created a moment after a failed lookup is found immediately. Redis errors fall back to the database (lesson 13.5).

## Choosing the store



Source: `projects/shortener/cmd/shortener/main.go`

```go
// openStore picks the storage from the configuration: PostgreSQL when
// DATABASE_URL is set (milestone 3), memory otherwise, with an optional
// Redis cache in front. The returned function releases connections.
func openStore(ctx context.Context, cfg config.Config, logger *slog.Logger) (link.Store, func(), error) {
	var closers []func()
	closeAll := func() {
		for _, c := range slices.Backward(closers) {
			c()
		}
	}

	var store link.Store
	if cfg.DatabaseURL == "" {
		logger.Warn("DATABASE_URL is not set: links are kept in memory and lost on restart")
		store = link.NewMemoryStore()
	} else {
		pool, err := pgxpool.New(ctx, cfg.DatabaseURL)
		if err != nil {
			return nil, nil, fmt.Errorf("database: %w", err)
		}
		closers = append(closers, pool.Close)
		pingCtx, cancel := context.WithTimeout(ctx, 10*time.Second)
		defer cancel()
		if err := pool.Ping(pingCtx); err != nil {
			closeAll()
			return nil, nil, fmt.Errorf("database: %w", err)
		}
		if cfg.Migrate {
			applied, err := postgres.Migrate(ctx, pool)
			if err != nil {
				closeAll()
				return nil, nil, fmt.Errorf("migrate: %w", err)
			}
			logger.Info("migrations", "applied", applied)
		}
		store = postgres.NewStore(pool)
	}

	if cfg.RedisAddr != "" {
		rdb := redis.NewClient(&redis.Options{Addr: cfg.RedisAddr})
		closers = append(closers, func() { rdb.Close() })
		pingCtx, cancel := context.WithTimeout(ctx, 2*time.Second)
		defer cancel()
		if err := rdb.Ping(pingCtx).Err(); err != nil {
			// Start anyway: the cache only makes things faster.
			logger.Warn("redis unavailable, continuing without a warm cache", "error", err)
		}
		store = cache.New(store, rdb, cfg.CacheTTL, logger)
	}
	return store, closeAll, nil
}
```



`openStore` builds the chain from configuration: memory or Postgres, optionally wrapped in the cache, and returns one function that closes everything in reverse order (`slices.Backward`, Go 1.23). The database URL is a secret, so it can come from `DATABASE_URL_FILE` (lesson 12.4) and is never logged. Note the different attitude to failures: an unreachable **database** stops start-up (the service cannot work), an unreachable **Redis** only produces a warning (the service works, just slower).

## Tests

```bash
export TEST_DATABASE_URL='postgres://postgres:pg@localhost:5432/postgres?sslmode=disable'
export TEST_REDIS_ADDR=localhost:6379
go test -race ./...
```

Without those variables, the database tests are skipped and the rest still run, so the project stays easy to work on without Docker. CI runs everything, with PostgreSQL 16 and Redis 7 as service containers. `TestRunWithPostgresAndRedis` runs the whole program, as `TestRun` does in memory, against both real servers.

## Your turn

1. Milestone 4 adds `Delete` to the `Store` interface. Before reading it, try it yourself: add the case to the conformance suite **first**, then implement it in each store. What must the cache do on delete, and in which order?
2. Count visits per link. Increment a column with `UPDATE links SET visits = visits + 1` (atomic, lesson 13.4); add the column with a new migration. Does doing this on every redirect undo the benefit of the cache? Consider enqueueing increments in batches (lesson 13.8).
3. Make readiness check the database with a short timeout. Then argue whether it should: what happens to all replicas when the database has a five second hiccup?
