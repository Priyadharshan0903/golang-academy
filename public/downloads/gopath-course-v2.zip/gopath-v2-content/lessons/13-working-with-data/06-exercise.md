# 13.6 Exercise: a read-through cache

Build an in-memory read-through cache with expiry, no caching of errors, and request coalescing, without holding a lock during loads; tested with a fake clock and the race detector.

## The task

Lesson 13.5 used Redis for storage and `singleflight` for coalescing. Here you build both ideas yourself, in memory and with only the standard library, which is the best way to understand what those packages do.



## Exercise: 13.6 Exercise: a read-through cache

Implement `Cache.Get` so that it follows the five rules in the comment on `Cache`: hits skip the loader, values expire after the TTL, errors are not cached, concurrent misses for one key share a single load, and a slow load never blocks other keys.

### Starter

```go
//go:build !solution

// Package readthrough practices the caching patterns of lesson 13.5
// without needing Redis: an in-memory read-through cache with expiry
// and request coalescing.
package readthrough

import (
	"context"
	"time"
)

// Loader fetches the value for key from the slow source of truth.
type Loader func(ctx context.Context, key string) (string, error)

// Cache sits in front of a Loader. It must:
//
//  1. return a cached value without calling the loader (a hit);
//  2. call the loader on a miss, and cache the value for ttl;
//  3. never cache errors: the next Get tries again;
//  4. call the loader only once when many goroutines miss the same key
//     at the same time; all of them get that one result;
//  5. not block Gets for other keys while a load is in progress.
//
// now is the clock; tests pass a fake one to control expiry.
type Cache struct {
	load Loader
	ttl  time.Duration
	now  func() time.Time
	// TODO: add the fields you need.
}

// New returns an empty cache.
func New(load Loader, ttl time.Duration, now func() time.Time) *Cache {
	return &Cache{load: load, ttl: ttl, now: now}
}

// Get returns the value for key.
func (c *Cache) Get(ctx context.Context, key string) (string, error) {
	// TODO: implement the five rules above. This placeholder never caches.
	return c.load(ctx, key)
}
```

```sh
cd exercises
go test ./m13/readthrough/
```

### Reference solution — try the exercise first

```go
//go:build solution

// Package readthrough practices the caching patterns of lesson 13.5
// without needing Redis: an in-memory read-through cache with expiry
// and request coalescing.
package readthrough

import (
	"context"
	"sync"
	"time"
)

// Loader fetches the value for key from the slow source of truth.
type Loader func(ctx context.Context, key string) (string, error)

type entry struct {
	value   string
	expires time.Time
}

// call is a load in progress. Goroutines that miss the same key wait on
// done and then read the shared result.
type call struct {
	done  chan struct{}
	value string
	err   error
}

// Cache sits in front of a Loader. See the starter for the rules.
type Cache struct {
	load Loader
	ttl  time.Duration
	now  func() time.Time

	mu       sync.Mutex // guards entries and inflight, never held during a load
	entries  map[string]entry
	inflight map[string]*call
}

// New returns an empty cache.
func New(load Loader, ttl time.Duration, now func() time.Time) *Cache {
	return &Cache{load: load, ttl: ttl, now: now, entries: map[string]entry{}, inflight: map[string]*call{}}
}

// Get returns the value for key.
func (c *Cache) Get(ctx context.Context, key string) (string, error) {
	c.mu.Lock()
	if e, ok := c.entries[key]; ok && c.now().Before(e.expires) {
		c.mu.Unlock()
		return e.value, nil // rule 1
	}
	if cl, ok := c.inflight[key]; ok {
		c.mu.Unlock()
		select { // rule 4: wait for the load already in progress
		case <-cl.done:
			return cl.value, cl.err
		case <-ctx.Done():
			return "", ctx.Err()
		}
	}
	cl := &call{done: make(chan struct{})}
	c.inflight[key] = cl
	c.mu.Unlock() // rule 5: do not hold the lock while loading

	cl.value, cl.err = c.load(ctx, key)

	c.mu.Lock()
	if cl.err == nil { // rule 3: only successes are cached
		c.entries[key] = entry{value: cl.value, expires: c.now().Add(c.ttl)} // rule 2
	}
	delete(c.inflight, key)
	c.mu.Unlock()
	close(cl.done)
	return cl.value, cl.err
}
```

```sh
go test -tags solution ./m13/readthrough/
```



```bash
cd exercises
go test -race ./m13/readthrough
```

The starter passes two of the four tests by accident (it never caches anything, so it cannot cache an error or block another key). Make all four pass, with `-race`.

## Hints



### Hint 1: the data

Two maps behind one `sync.Mutex`: `entries` (value and expiry time) and `inflight` (loads in progress). A load in progress is a small struct with a `done` channel and fields for the result.





### Hint 2: the lock

Rule 5 means you must **not** hold the mutex while calling the loader. Lock, look in both maps, register a new in-flight call if needed, unlock, load, then lock again to store the result and remove the in-flight entry.





### Hint 3: waking the waiters

Closing a channel wakes every goroutine blocked on receiving from it (lesson 6.2). Write the result into the call struct **before** closing `done`; the close makes the writes visible to the waiters (lesson 6.7). Waiters should also give up if their own context ends.





### Hint 4: the clock

Never call `time.Now()` directly; use the `now` function you were given, so the test's fake clock controls expiry.



The reference solution is in `exercises/m13/readthrough/solution.go`. Compare it with `singleflight`'s source: the core idea is the same.
