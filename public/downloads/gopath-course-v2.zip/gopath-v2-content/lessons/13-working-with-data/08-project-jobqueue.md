# 13.8 Project: a PostgreSQL job queue

Build a background job queue on PostgreSQL: transactional enqueue, workers that claim jobs with FOR UPDATE SKIP LOCKED, retries with exponential backoff, crash recovery through lock expiry, and graceful shutdown, all tested against a real database.

## The project

Sending an email, resizing an image, calling a slow partner API: work that should not happen while an HTTP client waits belongs in a **background job queue**. Producers record jobs; workers process them later, retrying failures.

You can use a dedicated broker (RabbitMQ, SQS, Kafka) for this, but many teams start with the PostgreSQL database they already run, and some never leave. This project builds such a queue in about 300 lines, comments included, using the patterns of this module and of Module 7. The code is in [`projects/jobqueue`](https://github.com/Priyadharshan0903/gopath-academy/tree/main/projects/jobqueue).

What it provides:

- Enqueue with a JSON payload, delay and retry limit, **optionally inside your own transaction**.
- Many workers, in one process or many, each job claimed by exactly one of them.
- Retries with exponential backoff and jitter, then `failed` with the last error.
- **Crash recovery**: if a worker dies mid-job, another picks the job up when its lock expires.
- Graceful shutdown that lets running jobs finish.

## The table



Source: `projects/jobqueue/schema.sql`

```sql
CREATE TABLE IF NOT EXISTS jobs (
    id           bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    queue        text        NOT NULL,
    payload      jsonb       NOT NULL,
    status       text        NOT NULL DEFAULT 'queued'
                 CHECK (status IN ('queued', 'running', 'done', 'failed')),
    attempts     int         NOT NULL DEFAULT 0,
    max_attempts int         NOT NULL DEFAULT 5,
    run_at       timestamptz NOT NULL DEFAULT now(),
    locked_until timestamptz,
    last_error   text,
    created_at   timestamptz NOT NULL DEFAULT now(),
    updated_at   timestamptz NOT NULL DEFAULT now()
);

-- Workers look for runnable jobs in one queue, oldest first. A partial
-- index keeps finished jobs out of it.
CREATE INDEX IF NOT EXISTS jobs_runnable ON jobs (queue, run_at, id)
    WHERE status IN ('queued', 'running');
```



A job moves through `queued` → `running` → `done`, or back to `queued` for a retry, or to `failed`. The partial index covers only jobs that can still run, so it stays small however many finished jobs the table keeps.

## Enqueue, in your transaction



Source: `projects/jobqueue/jobqueue.go`

```go
// EnqueueOptions control a single job.
type EnqueueOptions struct {
	Delay       time.Duration // run no earlier than this from now
	MaxAttempts int           // default 5
}

// Executor is satisfied by *pgxpool.Pool, *pgx.Conn and pgx.Tx.
type Executor interface {
	QueryRow(ctx context.Context, sql string, args ...any) pgx.Row
}

// Enqueue adds a job and returns its ID.
func (c *Client) Enqueue(ctx context.Context, queue string, payload any, opts EnqueueOptions) (int64, error) {
	return EnqueueWith(ctx, c.pool, queue, payload, opts)
}

// EnqueueWith adds a job using db, which can be a transaction: the job
// then exists only if the transaction commits. "Create the order and
// enqueue the confirmation email" becomes one atomic step, the main
// advantage of keeping a queue in the database you already use.
func EnqueueWith(ctx context.Context, db Executor, queue string, payload any, opts EnqueueOptions) (int64, error) {
	b, err := json.Marshal(payload)
	if err != nil {
		return 0, fmt.Errorf("encode payload: %w", err)
	}
	if opts.MaxAttempts <= 0 {
		opts.MaxAttempts = 5
	}
	var id int64
	err = db.QueryRow(ctx,
		`INSERT INTO jobs (queue, payload, max_attempts, run_at)
		 VALUES ($1, $2, $3, now() + make_interval(secs => $4))
		 RETURNING id`,
		queue, b, opts.MaxAttempts, opts.Delay.Seconds()).Scan(&id)
	return id, err
}
```



`EnqueueWith` accepts anything with a `QueryRow` method: the pool, a connection, or a **transaction**. This is the main reason to keep a queue in your own database. Consider "create an order, then queue the confirmation email": with an external broker, the order can commit while the enqueue fails, or the email can be sent for an order that was then rolled back. With the job in the same transaction as the order, both happen or neither does:



Source: `projects/jobqueue/jobqueue_test.go`

```go
func TestEnqueueInTransaction(t *testing.T) {
	c := newClient(t)
	ctx := t.Context()

	tx, _ := c.pool.Begin(ctx)
	EnqueueWith(ctx, tx, "q", "rolled back", EnqueueOptions{})
	tx.Rollback(ctx)

	tx, _ = c.pool.Begin(ctx)
	EnqueueWith(ctx, tx, "q", "committed", EnqueueOptions{})
	tx.Commit(ctx)

	counts, _ := c.Counts(ctx, "q")
	if counts["queued"] != 1 {
		t.Fatalf("counts = %v, want exactly the committed job", counts)
	}
}
```



## Claiming a job: SKIP LOCKED



Source: `projects/jobqueue/jobqueue.go`

```go
// claim locks the next runnable job in queue for visibility, or returns
// pgx.ErrNoRows if there is none. Runnable means queued and due, or
// running with an expired lock (its worker died).
//
// SKIP LOCKED is what makes this a queue: concurrent workers skip rows
// another transaction has locked, instead of waiting for them, so each
// job is claimed by exactly one worker.
func (c *Client) claim(ctx context.Context, queue string, visibility time.Duration) (Job, error) {
	var j Job
	var lastErr *string
	err := c.pool.QueryRow(ctx, `
		UPDATE jobs
		   SET status = 'running', attempts = attempts + 1,
		       locked_until = now() + make_interval(secs => $2), updated_at = now()
		 WHERE id = (
		       SELECT id FROM jobs
		        WHERE queue = $1
		          AND (status = 'queued' AND run_at <= now()
		               OR status = 'running' AND locked_until < now())
		        ORDER BY run_at, id
		        LIMIT 1
		          FOR UPDATE SKIP LOCKED)
		RETURNING id, queue, payload, attempts, max_attempts, last_error`,
		queue, visibility.Seconds(),
	).Scan(&j.ID, &j.Queue, &j.Payload, &j.Attempts, &j.MaxAttempts, &lastErr)
	if lastErr != nil {
		j.LastError = *lastErr
	}
	return j, err
}
```



The inner `SELECT` finds the oldest runnable job and locks it with `FOR UPDATE`. On its own, that would make concurrent workers **wait** for each other's locks, processing jobs one at a time. **`SKIP LOCKED`** tells PostgreSQL to skip rows that another transaction has locked and take the next one. Eight workers claiming at once get eight different jobs, without blocking.

The outer `UPDATE` marks the job `running`, counts the attempt, and sets `locked_until`: the job's **visibility timeout**. The same `WHERE` clause also accepts `running` jobs whose lock has expired. That single condition is the whole crash-recovery mechanism.



Source: `projects/jobqueue/jobqueue_test.go`

```go
func TestEveryJobProcessedOnce(t *testing.T) {
	c := newClient(t)
	const n = 200
	for i := range n {
		if _, err := c.Enqueue(t.Context(), "emails", map[string]int{"n": i}, EnqueueOptions{}); err != nil {
			t.Fatal(err)
		}
	}

	var mu sync.Mutex
	seen := map[int64]int{}
	stop := start(t, &Worker{Client: c, Queue: "emails", Concurrency: 8, Handler: func(ctx context.Context, j Job) error {
		mu.Lock()
		seen[j.ID]++
		mu.Unlock()
		return nil
	}})
	begin := time.Now()
	waitFor(t, c, "emails", func(m map[string]int) bool { return m["done"] == n })
	stop()

	t.Logf("8 workers processed %d jobs in %v", n, time.Since(begin).Round(time.Millisecond))
	if len(seen) != n {
		t.Fatalf("processed %d distinct jobs, want %d", len(seen), n)
	}
	for id, times := range seen {
		if times != 1 {
			t.Errorf("job %d processed %d times", id, times)
		}
	}
}
```

Local command:

```sh
cd projects/jobqueue && go test -run TestEveryJobProcessedOnce -v .
```



```text
8 workers processed 200 jobs in 159ms
```

Every job processed, each exactly once.

## Finishing, retrying, giving up



Source: `projects/jobqueue/jobqueue.go`

```go
// complete marks a job done. The attempts check makes sure we still own
// the job: if our lock expired and another worker claimed it, attempts
// has changed and this update does nothing.
func (c *Client) complete(ctx context.Context, j Job) error {
	_, err := c.pool.Exec(ctx,
		`UPDATE jobs SET status = 'done', locked_until = NULL, updated_at = now()
		  WHERE id = $1 AND attempts = $2`, j.ID, j.Attempts)
	return err
}

// fail records a failed attempt: retry after backoff, or give up.
func (c *Client) fail(ctx context.Context, j Job, cause error, backoff time.Duration) error {
	status := "queued"
	if j.Attempts >= j.MaxAttempts {
		status = "failed"
	}
	_, err := c.pool.Exec(ctx,
		`UPDATE jobs SET status = $3, last_error = $4, locked_until = NULL,
		        run_at = now() + make_interval(secs => $5), updated_at = now()
		  WHERE id = $1 AND attempts = $2`,
		j.ID, j.Attempts, status, cause.Error(), backoff.Seconds())
	return err
}
```



Both updates include `AND attempts = $2`. Suppose a job takes longer than its visibility timeout: its lock expires, another worker claims it (attempts goes from 1 to 2), and then the first worker finishes. Without the check, the first worker would mark a job done that the second is still running. With it, the stale update matches no row. This is **optimistic concurrency control**, with the attempt counter as the version number.

## The worker



Source: `projects/jobqueue/worker.go`

```go
// Run processes jobs until ctx is cancelled. It then stops claiming new
// jobs, waits for the jobs in progress to finish, and returns.
func (w *Worker) Run(ctx context.Context) error {
	w.defaults()
	var wg sync.WaitGroup
	for range w.Concurrency {
		wg.Go(func() { w.loop(ctx) })
	}
	wg.Wait()
	return nil
}

func (w *Worker) loop(ctx context.Context) {
	for ctx.Err() == nil {
		// The claim itself is not cancelled by shutdown: a claim that
		// commits after we gave up waiting would leave a job locked
		// until its visibility timeout.
		claimCtx, cancel := context.WithTimeout(context.WithoutCancel(ctx), 10*time.Second)
		j, err := w.Client.claim(claimCtx, w.Queue, w.Visibility)
		cancel()
		switch {
		case errors.Is(err, pgx.ErrNoRows):
			// Nothing to do: wait, with jitter so idle workers do not
			// poll in lockstep.
			sleep(ctx, w.PollInterval/2+rand.N(w.PollInterval))
		case err != nil:
			w.Logger.Error("claim failed", "queue", w.Queue, "error", err)
			sleep(ctx, w.PollInterval)
		default:
			w.process(j)
		}
	}
}

// process runs one job. It deliberately does not use the Run context:
// shutting down must let a running job finish. Its own deadline is the
// end of its lock, after which another worker may claim it.
func (w *Worker) process(j Job) {
	ctx, cancel := context.WithTimeout(context.Background(), w.Visibility)
	defer cancel()

	if j.Attempts > j.MaxAttempts { // a worker crashed during the last allowed attempt
		w.finish(j, w.Client.fail(ctx, j, errors.New("worker stopped during the final attempt"), 0))
		return
	}
	start := time.Now()
	err := safeCall(ctx, w.Handler, j)
	if err == nil {
		w.finish(j, w.Client.complete(ctx, j))
		w.Logger.Info("job done", "id", j.ID, "attempt", j.Attempts, "duration", time.Since(start))
		return
	}
	w.Logger.Warn("job failed", "id", j.ID, "attempt", j.Attempts, "max_attempts", j.MaxAttempts, "error", err)
	w.finish(j, w.Client.fail(ctx, j, err, w.Backoff(j.Attempts)))
}
```



The structure is a worker pool from lesson 7.2, with three production details:

- **Jitter** on the poll interval, so idle workers spread out instead of hitting the database in lockstep.
- **Panics become failures** (`safeCall`), so one bad payload cannot crash the process.
- **Two contexts.** The `Run` context means "stop taking new work". Each job gets its own context with the visibility timeout as its deadline: shutting down does not interrupt a running job, and a job cannot run past its lock without its handler being told.

## Crash recovery, tested



Source: `projects/jobqueue/jobqueue_test.go`

```go
func TestReclaimAfterCrash(t *testing.T) {
	c := newClient(t)
	id, _ := c.Enqueue(t.Context(), "q", "x", EnqueueOptions{})

	// A worker claims the job and then "crashes": it never reports back.
	if _, err := c.claim(t.Context(), "q", 200*time.Millisecond); err != nil {
		t.Fatal(err)
	}

	var gotAttempt atomic.Int64
	stop := start(t, &Worker{Client: c, Queue: "q", Handler: func(ctx context.Context, j Job) error {
		gotAttempt.Store(int64(j.Attempts))
		return nil
	}})
	defer stop()
	begin := time.Now()
	waitFor(t, c, "q", func(m map[string]int) bool { return m["done"] == 1 })
	t.Logf("job %d reclaimed after %v, on attempt %d", id, time.Since(begin).Round(10*time.Millisecond), gotAttempt.Load())
	if gotAttempt.Load() != 2 {
		t.Fatalf("attempt = %d, want 2", gotAttempt.Load())
	}
}
```

Local command:

```sh
cd projects/jobqueue && go test -run TestReclaimAfterCrash -v .
```



```text
job 1 reclaimed after 220ms, on attempt 2
```

The test claims a job and abandons it, like a worker killed by the OOM killer. A real worker picks it up once the 200 ms lock expires.

This is also the honest limit of the design: delivery is **at least once**. A worker that sends the email and then dies before marking the job done will cause a second email. Every queue that survives crashes has this property; the remedy is **idempotent handlers**, for example recording "email for order 42 sent" in the same database and checking it first.

## Graceful shutdown



Source: `projects/jobqueue/jobqueue_test.go`

```go
func TestShutdownWaitsForRunningJobs(t *testing.T) {
	c := newClient(t)
	c.Enqueue(t.Context(), "q", "slow", EnqueueOptions{})
	started := make(chan struct{})
	stop := start(t, &Worker{Client: c, Queue: "q", Handler: func(ctx context.Context, j Job) error {
		close(started)
		time.Sleep(300 * time.Millisecond)
		return nil
	}})

	<-started
	begin := time.Now()
	stop() // cancel while the job is running
	t.Logf("Run returned %v after cancel", time.Since(begin).Round(10*time.Millisecond))

	counts, _ := c.Counts(t.Context(), "q")
	if counts["done"] != 1 {
		t.Fatalf("counts = %v: the running job should have finished", counts)
	}
}
```



```text
Run returned 300ms after cancel
```

`Run` returns only after the running job completes. In Kubernetes, set `terminationGracePeriodSeconds` longer than your longest job, or a job will be killed mid-way and retried after its lock expires, which is safe, but slower.

## Try the demo

```bash
cd projects/jobqueue
DATABASE_URL='postgres://postgres:pg@localhost:5432/postgres?sslmode=disable' go run ./cmd/demo
```

It enqueues 20 fake emails for 4 workers; every fifth job fails once and is retried with backoff.

## When to use a dedicated broker instead

A PostgreSQL queue is a good fit for up to hundreds of jobs per second, when you value transactional enqueue and one less system to operate. Consider a broker when you need much higher throughput, fan-out of one message to many consumers, or long retention of event streams. Mature Go libraries built on the same Postgres ideas exist too, such as River (`github.com/riverqueue/river`).

## Your turn

1. Replace polling with **`LISTEN/NOTIFY`**: `Enqueue` runs `NOTIFY jobs`, and idle workers wait on `conn.WaitForNotification` with the poll interval as a fallback.
2. Add a **dead-letter** view: an admin endpoint listing `failed` jobs with their last error, and a way to re-queue one.
3. Export metrics (lesson 12.5): jobs processed and failed by queue, processing duration, and the queue depth from `Counts`.
4. Add **unique jobs**: a nullable `unique_key` column with a partial unique index on queued and running jobs, so "send welcome email to user 42" cannot be enqueued twice.
