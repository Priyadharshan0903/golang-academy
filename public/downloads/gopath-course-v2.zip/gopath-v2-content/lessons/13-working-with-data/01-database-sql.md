# 13.1 database/sql and connection pooling

How database/sql works: drivers, the connection pool and its settings, queries and rows, NULL values, sql.ErrNoRows, and why parameters prevent SQL injection, with a measured pool limit.

## What you will learn

- How `database/sql` and drivers fit together
- What `*sql.DB` really is: a **pool**, and how to size it
- Querying one row, many rows, and executing statements, correctly
- NULLs, `sql.ErrNoRows`, and closing rows
- How parameters prevent SQL injection, demonstrated

## The idea

`database/sql` is the standard library's interface to SQL databases. It contains **no driver**: it defines the API your code uses, and a driver package implements it for a specific database. You import the driver for its side effect of registering itself:

```go
import _ "github.com/jackc/pgx/v5/stdlib" // registers the driver name "pgx"
```

For PostgreSQL, **pgx** is the most widely used and most complete driver; its `stdlib` package provides the `database/sql` driver. (You will also meet the older `lib/pq` in existing code.) Lesson 13.2 shows pgx's own, richer API.

## sql.DB is a pool



Source: `examples/thirdparty/db/sqlbasics/users.go`

```go
// Open returns a *sql.DB, which is a pool of connections, not a single
// connection. It is safe for concurrent use and meant to live for the
// whole program.
func Open(ctx context.Context, url string) (*sql.DB, error) {
	db, err := sql.Open("pgx", url) // validates arguments only; does not connect
	if err != nil {
		return nil, err
	}
	db.SetMaxOpenConns(10)                  // never more than 10 connections at once
	db.SetMaxIdleConns(10)                  // keep up to 10 open between bursts
	db.SetConnMaxLifetime(30 * time.Minute) // recycle connections periodically
	db.SetConnMaxIdleTime(5 * time.Minute)  // close connections idle this long

	ctx, cancel := context.WithTimeout(ctx, 5*time.Second)
	defer cancel()
	if err := db.PingContext(ctx); err != nil { // the first real connection
		db.Close()
		return nil, fmt.Errorf("connect: %w", err)
	}
	return db, nil
}
```



`sql.Open` does not connect; it only checks its arguments. The `*sql.DB` it returns is a **pool of connections**, safe for concurrent use. Create one at start-up, share it everywhere, and close it at shutdown. Opening a `sql.DB` per request is a classic, expensive mistake.

Each query borrows a connection from the pool and returns it when done. The settings:

| Setting | Default | What to set |
|---|---|---|
| `SetMaxOpenConns` | unlimited | Always set it. The database has a connection limit (PostgreSQL's default is 100) shared by every instance of every service. 10 replicas × 25 connections is already 250. |
| `SetMaxIdleConns` | 2 | Usually equal to MaxOpenConns, so bursts do not open and close connections constantly. |
| `SetConnMaxLifetime` | forever | Minutes to an hour, so connections are recycled (helps with load balancers and failovers). |
| `SetConnMaxIdleTime` | forever | A few minutes, so idle capacity is released. |

### What happens when the pool is full

When all connections are busy, the next query **waits** for one to be returned. This test allows 2 connections and runs 6 queries that each take 200 ms:



Source: `examples/thirdparty/db/sqlbasics/users_test.go`

```go
func TestPoolLimit(t *testing.T) {
	db := setup(t)
	db.SetMaxOpenConns(2) // only two queries can run at once

	start := time.Now()
	var wg sync.WaitGroup
	for range 6 {
		wg.Go(func() {
			if _, err := db.ExecContext(t.Context(), `SELECT pg_sleep(0.2)`); err != nil {
				t.Error(err)
			}
		})
	}
	wg.Wait()
	elapsed := time.Since(start)
	s := db.Stats()

	t.Logf("6 queries of 200ms with 2 connections took %v; waited %d times for %v in total",
		elapsed.Round(10*time.Millisecond), s.WaitCount, s.WaitDuration.Round(10*time.Millisecond))
	if elapsed < 600*time.Millisecond || s.WaitCount < 4 {
		t.Fatalf("expected queuing: elapsed %v, waits %d", elapsed, s.WaitCount)
	}
}
```

Local command:

```sh
cd examples/thirdparty && go test -run TestPoolLimit -v ./db/sqlbasics
```



```text
6 queries of 200ms with 2 connections took 610ms; waited 4 times for 1.22s in total
```

Three rounds of two queries: 600 ms. `db.Stats()` shows the waiting directly. Export these stats as metrics (lesson 12.5): a growing `WaitCount` means the pool is too small, or queries are too slow, and requests are queuing. The wait respects the query's context, so a request deadline also bounds the time spent waiting for a connection.

## Queries



Source: `examples/thirdparty/db/sqlbasics/users.go`

```go
var ErrNotFound = errors.New("not found")

type User struct {
	ID       int64
	Name     string
	Email    string
	Nickname sql.Null[string] // a nullable column (sql.Null[T] is Go 1.22+)
}

func CreateSchema(ctx context.Context, db *sql.DB) error {
	_, err := db.ExecContext(ctx, `
		CREATE TABLE users (
			id       bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
			name     text NOT NULL,
			email    text NOT NULL UNIQUE,
			nickname text
		)`)
	return err
}

// Insert adds a user and returns its new ID. Values are passed as
// parameters ($1, $2, $3), never formatted into the SQL string.
func Insert(ctx context.Context, db *sql.DB, u User) (int64, error) {
	var id int64
	err := db.QueryRowContext(ctx,
		`INSERT INTO users (name, email, nickname) VALUES ($1, $2, $3) RETURNING id`,
		u.Name, u.Email, u.Nickname,
	).Scan(&id)
	return id, err
}

// Get returns one user, or ErrNotFound.
func Get(ctx context.Context, db *sql.DB, id int64) (User, error) {
	var u User
	err := db.QueryRowContext(ctx,
		`SELECT id, name, email, nickname FROM users WHERE id = $1`, id,
	).Scan(&u.ID, &u.Name, &u.Email, &u.Nickname)
	if errors.Is(err, sql.ErrNoRows) {
		return User{}, fmt.Errorf("user %d: %w", id, ErrNotFound)
	}
	return u, err
}

// List returns all users ordered by name.
func List(ctx context.Context, db *sql.DB) ([]User, error) {
	rows, err := db.QueryContext(ctx, `SELECT id, name, email, nickname FROM users ORDER BY name`)
	if err != nil {
		return nil, err
	}
	defer rows.Close() // returns the connection to the pool

	var users []User
	for rows.Next() {
		var u User
		if err := rows.Scan(&u.ID, &u.Name, &u.Email, &u.Nickname); err != nil {
			return nil, err
		}
		users = append(users, u)
	}
	return users, rows.Err() // an error that ended the loop early
}
```



The three methods, always the `Context` variants so that cancellation and deadlines apply:

- **`QueryRowContext(...).Scan(...)`** for exactly one row. If there is none, `Scan` returns **`sql.ErrNoRows`**; translate it into your own "not found" error, so callers do not depend on `database/sql`.
- **`QueryContext`** for many rows. Three rules: `defer rows.Close()` immediately (an unclosed `Rows` keeps its connection out of the pool, a pool leak), check `rows.Scan`'s error, and check **`rows.Err()`** after the loop, because a network error mid-result just ends the loop.
- **`ExecContext`** for statements that return no rows. Its `Result` has `RowsAffected`.

**NULL** needs a type that can represent it. `string` cannot be NULL, so scanning a NULL into it fails. Use `sql.Null[string]` (Go 1.22), which has `V` and `Valid`, or a pointer (`*string`). Better still, avoid nullable columns that do not need to be.

PostgreSQL uses `$1, $2, ...` placeholders; MySQL and SQLite use `?`. `RETURNING id` gets the generated ID in the same round trip.

## SQL injection

Never build SQL by formatting values into the string:



Source: `examples/thirdparty/db/sqlbasics/users.go`

```go
// FindByNameUnsafe builds SQL with string formatting. Never do this.
func FindByNameUnsafe(ctx context.Context, db *sql.DB, name string) (int, error) {
	var n int
	err := db.QueryRowContext(ctx,
		fmt.Sprintf(`SELECT count(*) FROM users WHERE name = '%s'`, name)).Scan(&n)
	return n, err
}

// FindByName passes name as a parameter: the database never parses it
// as SQL, whatever it contains.
func FindByName(ctx context.Context, db *sql.DB, name string) (int, error) {
	var n int
	err := db.QueryRowContext(ctx, `SELECT count(*) FROM users WHERE name = $1`, name).Scan(&n)
	return n, err
}
```





Source: `examples/thirdparty/db/sqlbasics/users_test.go`

```go
func TestInjection(t *testing.T) {
	db := setup(t)
	ctx := t.Context()
	Insert(ctx, db, User{Name: "Ada", Email: "ada@example.com"})
	Insert(ctx, db, User{Name: "Alan", Email: "alan@example.com"})

	evil := `nobody' OR '1'='1`
	unsafe, _ := FindByNameUnsafe(ctx, db, evil)
	safe, _ := FindByName(ctx, db, evil)
	t.Logf("unsafe query matched %d users, safe query matched %d", unsafe, safe)
	if unsafe != 2 || safe != 0 {
		t.Fatalf("unsafe=%d safe=%d", unsafe, safe)
	}
}
```



```text
unsafe query matched 2 users, safe query matched 0
```

The input `nobody' OR '1'='1` closes the string literal and adds a condition that is always true, so the unsafe query matches every user. With a parameter, the value is sent **separately** from the SQL text, and the database never parses it as SQL: it simply looks for a user with that strange name. Parameters work for values only; if you must vary an identifier (a column to sort by), choose it from a fixed allowlist in code.

## Common mistakes

### A new sql.DB per request

Create one pool at start-up and share it.

### No MaxOpenConns

Under load, every instance opens connections until the database refuses them, failing every service that uses it.

### Forgetting rows.Close or rows.Err

The first leaks connections until the pool is exhausted; the second silently returns partial results.

### Formatting values into SQL

Use parameters, always.

## Key takeaways

- `database/sql` is an interface; import a driver such as `github.com/jackc/pgx/v5/stdlib`.
- `*sql.DB` is a concurrency-safe pool: one per database per program, with `SetMaxOpenConns` and friends set deliberately.
- When the pool is full, queries wait; `db.Stats()` shows it.
- Use the `Context` methods; map `sql.ErrNoRows` to your own error; always `rows.Close()` and check `rows.Err()`.
- Pass values as parameters (`$1`), never with string formatting.

## Further reading

- [Go database/sql tutorial](https://go.dev/doc/database/) on go.dev
- [Managing connections](https://go.dev/doc/database/manage-connections)
- [pgx documentation](https://pkg.go.dev/github.com/jackc/pgx/v5)
