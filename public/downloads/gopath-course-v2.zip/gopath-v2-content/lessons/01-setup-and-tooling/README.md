# 1. Setup and tooling

By the end of this module you will have a working Go setup, understand how Go code is organized into modules and packages, and know the tools you will use every day. You finish by building a small but properly structured command line tool.

**Time:** about 2 hours, plus exercises.

- [1.1 Why Go, and when not to use it](01-why-go.md)
- [1.2 Installing Go and setting up your editor](02-installing-go.md)
- [1.3 Your first program, line by line](03-first-program.md)
- [1.4 Go modules: go.mod, go.sum and dependencies](04-modules.md)
- [1.5 Packages, visibility and project layout](05-packages-and-layout.md)
- [1.6 The go command toolbox](06-go-command.md)
- [1.7 Formatting, vetting and linting](07-formatting-and-linting.md)
- [1.8 Checkpoint project: the greet CLI](08-checkpoint-project.md)
