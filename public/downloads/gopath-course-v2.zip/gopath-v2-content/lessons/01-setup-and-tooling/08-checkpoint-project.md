# 1.8 Checkpoint project: the greet CLI

Build a small, properly structured command line tool with flags, tests, version stamping and cross-compiled releases.

## What you will build

A command line tool called `greet`:

```bash
greet -name Ana -times 2 -shout
```

```text
HELLO, ANA!
HELLO, ANA!
```

It is deliberately small, so you can focus on structure and tooling instead of logic. By the end you will have used everything from this module: a module, several packages, `internal/`, `cmd/`, flags, tests, `-ldflags` version stamping and cross-compiling.

The finished code is in [`projects/greet`](https://github.com/Priyadharshan0903/gopath-academy/tree/main/projects/greet). Try building it yourself first, using the steps below, and compare afterwards.

## The plan




### Lay out the project

Use the layout from lesson 1.5: one binary in `cmd/greet`, the logic in `internal/greeter`, build metadata in `internal/version`.

### Write the logic as a plain function

The greeting logic has no idea it is part of a CLI. It takes options and returns a string, which makes it trivial to test.



Source: `projects/greet/internal/greeter/greeter.go`

```go
// Package greeter contains the logic of the greet command.
//
// It lives under internal/, so only code inside projects/greet can
// import it. That keeps it free to change without breaking anyone.
package greeter

import "strings"

// Options controls how a greeting is rendered.
type Options struct {
	Name  string
	Shout bool
	Times int
}

// Render returns the greeting described by opts. An empty Name becomes
// "Gopher" and a Times value below 1 is treated as 1.
func Render(opts Options) string {
	name := strings.TrimSpace(opts.Name)
	if name == "" {
		name = "Gopher"
	}
	times := max(opts.Times, 1)

	lines := make([]string, times)
	for i := range lines {
		lines[i] = "Hello, " + name + "!"
	}
	out := strings.Join(lines, "\n")
	if opts.Shout {
		out = strings.ToUpper(out)
	}
	return out
}
```



`max` is a built-in function since Go 1.21, so `max(opts.Times, 1)` clamps the value without an `if`.

### Test it with a table



Source: `projects/greet/internal/greeter/greeter_test.go`

```go
package greeter

import "testing"

func TestRender(t *testing.T) {
	tests := []struct {
		name string
		opts Options
		want string
	}{
		{"defaults", Options{}, "Hello, Gopher!"},
		{"name", Options{Name: "Ana"}, "Hello, Ana!"},
		{"trim", Options{Name: "  Ana "}, "Hello, Ana!"},
		{"times", Options{Name: "Go", Times: 2}, "Hello, Go!\nHello, Go!"},
		{"negative times", Options{Name: "Go", Times: -5}, "Hello, Go!"},
		{"shout", Options{Name: "Go", Shout: true}, "HELLO, GO!"},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := Render(tt.opts); got != tt.want {
				t.Errorf("Render(%+v) = %q, want %q", tt.opts, got, tt.want)
			}
		})
	}
}
```

Local command:

```sh
go test ./projects/greet/...
```



This is a **table-driven test**: a slice of cases and one loop. It is the most common testing style in Go, and Module 9 covers it in depth.

### Keep `main` thin, and testable

`main` should only connect the program to the real world. Everything else goes in a `run` function that takes its arguments and output streams as parameters and returns an exit code.



Source: `projects/greet/cmd/greet/main.go`

```go
// Command greet prints a friendly greeting.
//
// Usage:
//
//	greet [-name NAME] [-shout] [-times N] [-version]
package main

import (
	"flag"
	"fmt"
	"io"
	"os"

	"github.com/Priyadharshan0903/gopath-academy/projects/greet/internal/greeter"
	"github.com/Priyadharshan0903/gopath-academy/projects/greet/internal/version"
)

func main() {
	os.Exit(run(os.Args[1:], os.Stdout, os.Stderr))
}

// run holds the whole program. main only connects it to the real
// process (arguments, output streams, exit code), which makes run
// easy to test.
func run(args []string, stdout, stderr io.Writer) int {
	fs := flag.NewFlagSet("greet", flag.ContinueOnError)
	fs.SetOutput(stderr)

	var opts greeter.Options
	fs.StringVar(&opts.Name, "name", "Gopher", "who to greet")
	fs.BoolVar(&opts.Shout, "shout", false, "print in uppercase")
	fs.IntVar(&opts.Times, "times", 1, "how many times to greet")
	showVersion := fs.Bool("version", false, "print version and exit")

	if err := fs.Parse(args); err != nil {
		return 2 // the flag package already printed the problem
	}
	if *showVersion {
		fmt.Fprintln(stdout, version.String())
		return 0
	}
	if opts.Times < 1 {
		fmt.Fprintln(stderr, "greet: -times must be at least 1")
		return 2
	}
	fmt.Fprintln(stdout, greeter.Render(opts))
	return 0
}
```



A few details worth noticing:

- `flag.NewFlagSet(..., flag.ContinueOnError)` returns errors instead of calling `os.Exit` itself, so `run` stays in control.
- `fs.SetOutput(stderr)` sends usage and error messages to the stream we pass in, not straight to the terminal.
- Exit code `2` for bad usage and `0` for success follow Unix conventions (and match what the `flag` package does by default).

### Test the whole program

Because `run` takes plain values, testing the full CLI needs no subprocesses:



Source: `projects/greet/cmd/greet/main_test.go`

```go
package main

import (
	"bytes"
	"strings"
	"testing"
)

func TestRun(t *testing.T) {
	tests := []struct {
		name     string
		args     []string
		wantCode int
		wantOut  string
		wantErr  string
	}{
		{"default", nil, 0, "Hello, Gopher!\n", ""},
		{"flags", []string{"-name", "Ana", "-times", "2"}, 0, "Hello, Ana!\nHello, Ana!\n", ""},
		{"version", []string{"-version"}, 0, "greet dev (commit none, built unknown)\n", ""},
		{"bad times", []string{"-times", "0"}, 2, "", "-times must be at least 1"},
		{"unknown flag", []string{"-nope"}, 2, "", "flag provided but not defined"},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			var stdout, stderr bytes.Buffer
			code := run(tt.args, &stdout, &stderr)
			if code != tt.wantCode {
				t.Errorf("exit code = %d, want %d", code, tt.wantCode)
			}
			if got := stdout.String(); got != tt.wantOut {
				t.Errorf("stdout = %q, want %q", got, tt.wantOut)
			}
			if !strings.Contains(stderr.String(), tt.wantErr) {
				t.Errorf("stderr = %q, want it to contain %q", stderr.String(), tt.wantErr)
			}
		})
	}
}
```



### Stamp the version



Source: `projects/greet/internal/version/version.go`

```go
// Package version holds build metadata that is injected at build time.
//
// Build with:
//
//	go build -ldflags "-X github.com/Priyadharshan0903/gopath-academy/projects/greet/internal/version.Version=v0.1.0" ./cmd/greet
//
// The Makefile does this for you.
package version

import "fmt"

// These must be variables (not constants) for -ldflags -X to work.
var (
	Version = "dev"
	Commit  = "none"
	Date    = "unknown"
)

// String returns a single line describing this build.
func String() string {
	return fmt.Sprintf("greet %s (commit %s, built %s)", Version, Commit, Date)
}
```



### Automate builds with a Makefile



Source: `projects/greet/Makefile`

```
# Build the greet CLI with version information stamped in.
#
#   make build       build for this machine into ./bin
#   make release     cross-compile for Linux, macOS and Windows into ./dist
#   make test        run the tests

PKG      := github.com/Priyadharshan0903/gopath-academy/projects/greet
VERSION  ?= $(shell git describe --tags --always --dirty 2>/dev/null || echo dev)
COMMIT   ?= $(shell git rev-parse --short HEAD 2>/dev/null || echo none)
DATE     ?= $(shell date -u +%Y-%m-%dT%H:%M:%SZ)

LDFLAGS := -s -w \
	-X $(PKG)/internal/version.Version=$(VERSION) \
	-X $(PKG)/internal/version.Commit=$(COMMIT) \
	-X $(PKG)/internal/version.Date=$(DATE)

PLATFORMS := linux/amd64 linux/arm64 darwin/arm64 windows/amd64

.PHONY: build release test clean

build:
	go build -trimpath -ldflags "$(LDFLAGS)" -o bin/greet ./cmd/greet

release:
	@for p in $(PLATFORMS); do \
		os=$${p%/*}; arch=$${p#*/}; ext=; \
		[ "$$os" = windows ] && ext=.exe; \
		echo "building $$os/$$arch"; \
		CGO_ENABLED=0 GOOS=$$os GOARCH=$$arch \
			go build -trimpath -ldflags "$(LDFLAGS)" \
			-o dist/greet-$$os-$$arch$$ext ./cmd/greet || exit 1; \
	done

test:
	go test ./...

clean:
	rm -rf bin dist
```



```bash
cd projects/greet
make build
./bin/greet -version
```

```text
greet v0.1.0-3-g3f9c2ab (commit 3f9c2ab, built 2026-10-16T09:27:51Z)
```

Your version, commit and date will differ. Then cross-compile for four platforms in one command:

```bash
make release
ls dist
```

```text
greet-darwin-arm64  greet-linux-amd64  greet-linux-arm64  greet-windows-amd64.exe
```




## Exercise

The project uses `internal/greeter` with a slightly different API from the one below. This exercise asks you to write the parsing half yourself, in a form that is easy to test.



## Exercise: 1.8 Checkpoint project: the greet CLI

Implement `Parse(args []string) (Config, error)` and `Render(cfg Config) string`. Use a `flag.FlagSet` with `flag.ContinueOnError`, validate that `-times` is at least 1, and return `ErrInvalidTimes` when it is not. The starter file contains detailed requirements.

### Starter

```go
//go:build !solution

// Package cli parses command line arguments for a tiny greeter.
//
// Keeping parsing in a function that takes []string (instead of reading
// os.Args directly) makes it easy to test. main would call
// cli.Parse(os.Args[1:]).
package cli

import (
	"errors"
	"flag"
	"io"
)

// Config holds the parsed options.
type Config struct {
	Name  string // -name, default "Gopher"
	Shout bool   // -shout, default false
	Times int    // -times, default 1, must be >= 1
}

// ErrInvalidTimes is returned when -times is less than 1.
var ErrInvalidTimes = errors.New("times must be at least 1")

// Parse parses args (without the program name) into a Config.
//
// Requirements:
//   - Use flag.NewFlagSet("greet", flag.ContinueOnError), not the global
//     flag package functions, so tests do not share state.
//   - Call fs.SetOutput(io.Discard) so errors are returned, not printed.
//   - Return ErrInvalidTimes if -times < 1.
//   - Return the flag package's error for unknown flags.
func Parse(args []string) (Config, error) {
	fs := flag.NewFlagSet("greet", flag.ContinueOnError)
	fs.SetOutput(io.Discard)
	// TODO: define the three flags, parse args, validate, return.
	_ = fs
	return Config{}, nil
}

// Render returns the greeting text for cfg: "Hello, <Name>!" repeated
// Times times, one per line, with no trailing newline. If Shout is true
// the whole text is uppercase.
//
// Hint: strings.Repeat, strings.Join and strings.ToUpper are useful.
func Render(cfg Config) string {
	// TODO: implement me.
	return ""
}
```

```sh
cd exercises
go test ./m01/cli/
```

### Reference solution — try the exercise first

```go
//go:build solution

// Package cli parses command line arguments for a tiny greeter.
package cli

import (
	"errors"
	"flag"
	"io"
	"strings"
)

// Config holds the parsed options.
type Config struct {
	Name  string
	Shout bool
	Times int
}

// ErrInvalidTimes is returned when -times is less than 1.
var ErrInvalidTimes = errors.New("times must be at least 1")

// Parse parses args (without the program name) into a Config.
func Parse(args []string) (Config, error) {
	fs := flag.NewFlagSet("greet", flag.ContinueOnError)
	fs.SetOutput(io.Discard)

	var cfg Config
	fs.StringVar(&cfg.Name, "name", "Gopher", "who to greet")
	fs.BoolVar(&cfg.Shout, "shout", false, "print in uppercase")
	fs.IntVar(&cfg.Times, "times", 1, "how many times to greet")

	if err := fs.Parse(args); err != nil {
		return Config{}, err
	}
	if cfg.Times < 1 {
		return Config{}, ErrInvalidTimes
	}
	return cfg, nil
}

// Render returns the greeting text for cfg.
func Render(cfg Config) string {
	lines := make([]string, cfg.Times)
	for i := range lines {
		lines[i] = "Hello, " + cfg.Name + "!"
	}
	out := strings.Join(lines, "\n")
	if cfg.Shout {
		out = strings.ToUpper(out)
	}
	return out
}
```

```sh
go test -tags solution ./m01/cli/
```



## Stretch goals

Once the tests pass, try these on your own copy of the project:

1. Add a `-lang` flag supporting `en`, `ta` and `hi` greetings. Return an error for unknown languages.
2. Read a default name from the `GREET_NAME` environment variable when `-name` is not given. Write a test for it using `t.Setenv`.
3. Install your build with `go install ./cmd/greet` and run `go version -m $(which greet)` to see the build info.

## Module 1 recap

You can now:

- Install Go, manage toolchains and set up your editor
- Create modules, add dependencies, and read `go.mod` and `go.sum`
- Organize code into packages with clear visibility and good names
- Build, cross-compile and stamp versions into binaries
- Keep code formatted, vetted and linted

Next up is **[Module 2: Language basics](../02-language-basics/README.md)**, where we go through Go's types, control flow, functions and pointers in detail.

## Further reading

- [Package flag](https://pkg.go.dev/flag)
- [Tutorial: Add a test](https://go.dev/doc/tutorial/add-a-test)
- [Organizing a Go module: commands](https://go.dev/doc/modules/layout#package-or-command-with-supporting-packages)
