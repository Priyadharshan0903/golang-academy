# 15. Go for cloud native

Kubernetes, Docker, containerd, Prometheus, etcd, Helm, Argo CD: the cloud native world is largely written in Go. This module covers both directions of that relationship: **running Go in Kubernetes** well, and **writing Go that drives Kubernetes**.

Everything here was run on a real cluster (k3s, Kubernetes 1.37) while the lessons were written: the images were built with the Dockerfiles shown, the manifests were applied, rolling updates were measured under load, and the operator created and deleted real short links. The output you see is from those runs.

**Time:** about 5 to 6 hours, plus the exercise and the project. You need Docker and a local cluster (kind, k3d, k3s or Docker Desktop) to follow along.

- [15.1 Containerizing Go](01-containers.md)
- [15.2 Go in Kubernetes: probes, signals and graceful shutdown](02-go-in-kubernetes.md)
- [15.3 client-go basics](03-client-go.md)
- [15.4 Writing a Kubernetes controller with controller-runtime](04-controller.md)
- [15.5 Operators in practice](05-operators-in-practice.md)
- [15.6 Exercise: drain gracefully](06-exercise.md)
- [15.7 Project milestone: the shortener on Kubernetes](07-project-shortener-k8s.md)
