# 15.6 Exercise: drain gracefully

Implement the shutdown sequence that took a rolling update from 59 failed requests to zero: flip readiness, keep serving for a delay, then shut down with a timeout.

## The task

Lesson 15.2 measured what happens when a service stops the moment it gets SIGTERM: 59 failed requests in one rolling update. Here you write the function that prevents it.



## Exercise: 15.6 Exercise: drain gracefully

Implement `Serve` in `starter.go`: serve until the context is cancelled, then mark the service not ready, keep serving for `opts.Delay`, and shut down with `srv.Shutdown`, giving in-flight requests up to `opts.Timeout`.

### Starter

```go
//go:build !solution

// Package drain practices the shutdown sequence of a service running in
// Kubernetes (lesson 15.2).
package drain

import (
	"context"
	"net"
	"net/http"
	"sync/atomic"
	"time"
)

// Options configure Serve.
type Options struct {
	// Delay is how long to keep serving after ctx is cancelled, while
	// reporting not ready, so load balancers stop sending new traffic.
	Delay time.Duration
	// Timeout bounds how long Shutdown waits for in-flight requests.
	Timeout time.Duration
}

// Ready reports whether the service should receive traffic. Serve sets
// it to true when it starts serving and to false as soon as ctx is
// cancelled. A /readyz handler would read it.
type Ready = atomic.Bool

// Serve serves srv on ln until ctx is cancelled, then shuts down
// gracefully:
//
//  1. set ready to true once serving;
//  2. when ctx is cancelled, set ready to false immediately;
//  3. keep serving normally for opts.Delay;
//  4. call srv.Shutdown with a context that times out after
//     opts.Timeout, so in-flight requests can finish;
//  5. return nil after a clean shutdown, or the error from Serve or
//     Shutdown (never http.ErrServerClosed).
func Serve(ctx context.Context, srv *http.Server, ln net.Listener, ready *Ready, opts Options) error {
	// TODO: implement the five steps above.
	return srv.Serve(ln)
}
```

```sh
cd exercises
go test ./m15/drain/
```

### Reference solution — try the exercise first

```go
//go:build solution

// Package drain practices the shutdown sequence of a service running in
// Kubernetes (lesson 15.2).
package drain

import (
	"context"
	"errors"
	"net"
	"net/http"
	"sync/atomic"
	"time"
)

// Options configure Serve. See the starter for details.
type Options struct {
	Delay   time.Duration
	Timeout time.Duration
}

// Ready reports whether the service should receive traffic.
type Ready = atomic.Bool

// Serve serves srv on ln until ctx is cancelled, then shuts down
// gracefully. See the starter for the specification.
func Serve(ctx context.Context, srv *http.Server, ln net.Listener, ready *Ready, opts Options) error {
	serveErr := make(chan error, 1)
	go func() { serveErr <- srv.Serve(ln) }()
	ready.Store(true)

	select {
	case err := <-serveErr: // the server failed on its own
		ready.Store(false)
		return err
	case <-ctx.Done():
	}

	ready.Store(false) // step 2: stop attracting new traffic
	t := time.NewTimer(opts.Delay)
	select { // step 3: keep serving, unless the server dies meanwhile
	case <-t.C:
	case err := <-serveErr:
		return err
	}

	shutdownCtx, cancel := context.WithTimeout(context.Background(), opts.Timeout)
	defer cancel()
	err := srv.Shutdown(shutdownCtx) // step 4
	if serr := <-serveErr; !errors.Is(serr, http.ErrServerClosed) {
		return errors.Join(err, serr)
	}
	return err // step 5: nil, or context.DeadlineExceeded if requests ran too long
}
```

```sh
go test -tags solution ./m15/drain/
```



```bash
cd exercises
go test -race ./m15/drain
```

The tests run a real HTTP server and check that:

- readiness turns false **immediately** on cancel, while requests are **still served** during the delay;
- a request in flight when shutdown starts **completes**;
- a request that hangs does not hang `Serve`: it returns `context.DeadlineExceeded` after the timeout.

## Hints



### Hint 1: two things to wait for

Run `srv.Serve(ln)` in a goroutine that sends its result on a buffered channel. Then `select` on that channel (the server failed on its own) and on `ctx.Done()` (time to shut down).





### Hint 2: the delay

Use a `select` on a timer and the serve channel, not `time.Sleep`, so a server that dies during the delay is reported at once.





### Hint 3: the return value

After `Shutdown`, `Serve` returns `http.ErrServerClosed`: that is success, not an error. Receive it from the channel so the goroutine does not leak, and return what `Shutdown` returned.



The reference solution is in `exercises/m15/drain/solution.go`. Compare it with the shortener's `run` in `projects/shortener/cmd/shortener/main.go`, which does the same for two servers at once.
