# 6.2 Channels: unbuffered, buffered, direction

Send and receive values between goroutines, the difference between unbuffered and buffered channels, closing and ranging, direction types and ownership rules.

## What you will learn

- How channels pass values **and** synchronize goroutines
- The difference between unbuffered and buffered channels
- How closing works, and how `range` and comma-ok receives detect it
- How direction types (`chan<-`, `<-chan`) enforce who sends and who receives
- The ownership rules that keep channel code correct

## The idea

A **channel** is a typed pipe between goroutines. One goroutine sends a value with `ch <- v`; another receives it with `v := <-ch`.

Channels do two jobs at once: they **move data**, and they **synchronize**, because sends and receives block until the other side is ready (or the buffer has room). Go's motto captures the design: *Do not communicate by sharing memory; instead, share memory by communicating.*

## Unbuffered channels



Source: `examples/m06/channels/channels_test.go`

```go
func Example_unbuffered() {
	ch := make(chan string) // unbuffered: a send waits for a receiver

	go func() {
		ch <- "ping" // blocks until main is ready to receive
	}()

	msg := <-ch // blocks until the goroutine sends
	fmt.Println(msg)

	// Output:
	// ping
}
```

Local command:

```sh
go test -run Example_unbuffered -v ./examples/m06/channels
```



`make(chan string)` creates an **unbuffered** channel. A send blocks until a receiver takes the value, and a receive blocks until a sender provides one. The two goroutines meet at that moment, like a hand-off. This makes unbuffered channels a strong synchronization tool: when the send completes, you **know** the receiver has the value.

## Buffered channels



Source: `examples/m06/channels/channels_test.go`

```go
func Example_buffered() {
	ch := make(chan int, 2) // room for 2 values without a receiver

	ch <- 1 // does not block
	ch <- 2 // does not block
	fmt.Println(len(ch), cap(ch))
	// A third send would block until someone receives.

	fmt.Println(<-ch, <-ch)

	// Output:
	// 2 2
	// 1 2
}
```

Local command:

```sh
go test -run Example_buffered -v ./examples/m06/channels
```



`make(chan int, n)` creates a channel with a buffer of `n` values. Sends block only when the buffer is full; receives block only when it is empty. `len(ch)` and `cap(ch)` report the current number of buffered values and the capacity.

Use a buffer when you know how many values will be sent and want the sender not to wait (for example, a result channel with one slot per worker), or to absorb short bursts. Do **not** add a buffer to "fix" a deadlock; that usually just moves it.

## Closing and ranging



Source: `examples/m06/channels/channels_test.go`

```go
func produce(n int) <-chan int {
	out := make(chan int)
	go func() {
		defer close(out) // the sender closes, telling receivers "no more values"
		for i := range n {
			out <- i * i
		}
	}()
	return out
}

func Example_closeAndRange() {
	for v := range produce(4) { // range stops when the channel is closed
		fmt.Println(v)
	}

	ch := make(chan int, 1)
	ch <- 7
	close(ch)
	v, ok := <-ch
	fmt.Println(v, ok) // buffered values are still delivered after close
	v, ok = <-ch
	fmt.Println(v, ok) // then receives return the zero value and false

	// Output:
	// 0
	// 1
	// 4
	// 9
	// 7 true
	// 0 false
}
```

Local command:

```sh
go test -run Example_closeAndRange -v ./examples/m06/channels
```



- `close(ch)` signals "no more values will be sent".
- `for v := range ch` receives until the channel is closed **and** drained.
- After close, buffered values are still delivered. Then every receive returns the zero value immediately, and the comma-ok form `v, ok := <-ch` reports `ok == false`.
- Closing is optional. You only need to close when receivers need to know that the stream ended (for example, to stop a `range`).

The generator pattern in `produce` is idiomatic: a function creates a channel, starts a goroutine that sends and then closes it, and returns the channel as **receive-only**.

## Direction types



Source: `examples/m06/channels/channels_test.go`

```go
// Direction types document and enforce who sends and who receives.
func sendOnly(out chan<- string)       { out <- "hello" }
func recvOnly(in <-chan string) string { return <-in }

func Example_directions() {
	ch := make(chan string, 1) // bidirectional
	sendOnly(ch)               // converts to chan<- string automatically
	fmt.Println(recvOnly(ch))  // converts to <-chan string
	// Inside sendOnly, <-out would not compile.

	// Output:
	// hello
}
```

Local command:

```sh
go test -run Example_directions -v ./examples/m06/channels
```



- `chan<- T` can only send.
- `<-chan T` can only receive.
- A normal `chan T` converts to either automatically.

Use direction types in function signatures. They document intent and turn mistakes (receiving on an output channel, closing an input channel) into compile errors.

## Closing as a broadcast



Source: `examples/m06/channels/channels_test.go`

```go
func Example_doneSignal() {
	done := make(chan struct{}) // struct{}: the event matters, not a value
	var wg sync.WaitGroup

	for i := range 3 {
		wg.Add(1)
		go func() {
			defer wg.Done()
			<-done // every waiter is released by one close
			_ = i
		}()
	}
	close(done) // broadcast: closing wakes ALL receivers
	wg.Wait()
	fmt.Println("all released")

	// Output:
	// all released
}
```

Local command:

```sh
go test -run Example_doneSignal -v ./examples/m06/channels
```



A receive on a closed channel succeeds immediately, so **closing a channel wakes every goroutine waiting on it**. `chan struct{}` is the conventional type for pure signals, because the values carry no data. `context.Context`'s `Done()` channel (lesson 7.1) works exactly this way.

## The rules of channel ownership

| Operation | nil channel | closed channel |
|---|---|---|
| send `ch <- v` | blocks forever | **panics** |
| receive `<-ch` | blocks forever | returns zero value, `ok == false` |
| `close(ch)` | **panics** | **panics** |

From that table follow the rules:

1. **Only the sender closes**, and only when it is the last sender. A receiver closing a channel can make the sender panic.
2. **Close at most once.** With several senders, use a `sync.WaitGroup` and close from a separate goroutine after all senders finish (exactly what `Merge` in the exercise does).
3. **The function that creates a channel usually owns it**: it sends, closes, and hands out the receive-only end.

## Common mistakes

### Deadlock: nobody on the other side

```go
ch := make(chan int)
ch <- 1 // fatal error: all goroutines are asleep - deadlock!
```

The runtime detects when every goroutine is blocked and crashes with this message. In a larger program, a missing receiver usually shows up as a goroutine that never ends instead.

### Closing from the receiving side

Leads to `panic: send on closed channel` in a sender. Signal the sender to stop (with a separate done channel or a context) instead.

### Forgetting to close, so `range` never ends

A `for v := range ch` loop waits forever if the sender returns without closing. Use `defer close(out)` at the top of the sending goroutine.

### Using channels where a mutex is simpler

Protecting a counter or a map with a channel-based "server goroutine" is valid but often more complex than a `sync.Mutex`. Use channels to pass ownership of data or signal events; use mutexes to guard shared state (lesson 6.4).

## Exercise



## Exercise: 6.2 Channels: unbuffered, buffered, direction

Implement `Generate`, `Square` and `Merge`. Each function creates and closes its own output channel, and every goroutine must exit when its input is drained. The last test counts goroutines before and after running 50 pipelines, so a missing `close` or a stuck goroutine will fail it. Run with `go test -race`.

### Starter

```go
//go:build !solution

// Package pipeline practices channels: generators, stages that read
// from one channel and write to another, and merging channels.
//
// Rules for every function here: the function that creates a channel
// is the one that closes it, and every goroutine you start must exit
// once its input is exhausted.
package pipeline

// Generate returns a channel that yields nums in order, then closes.
func Generate(nums ...int) <-chan int {
	// TODO: implement me.
	out := make(chan int)
	close(out)
	return out
}

// Square reads every value from in and sends its square on the
// returned channel, which is closed after in is closed and drained.
func Square(in <-chan int) <-chan int {
	// TODO: implement me.
	out := make(chan int)
	close(out)
	return out
}

// Merge sends every value from all input channels on one output
// channel (in any order) and closes it once ALL inputs are closed.
//
// Hint: one goroutine per input, plus a sync.WaitGroup and one more
// goroutine that closes the output after Wait returns.
func Merge(chans ...<-chan int) <-chan int {
	// TODO: implement me.
	out := make(chan int)
	close(out)
	return out
}
```

```sh
cd exercises
go test ./m06/pipeline/
```

### Reference solution — try the exercise first

```go
//go:build solution

// Package pipeline practices channels: generators, stages and merging.
package pipeline

import "sync"

// Generate returns a channel that yields nums in order, then closes.
func Generate(nums ...int) <-chan int {
	out := make(chan int)
	go func() {
		defer close(out)
		for _, n := range nums {
			out <- n
		}
	}()
	return out
}

// Square sends the square of every value read from in.
func Square(in <-chan int) <-chan int {
	out := make(chan int)
	go func() {
		defer close(out)
		for n := range in {
			out <- n * n
		}
	}()
	return out
}

// Merge fans in several channels into one.
func Merge(chans ...<-chan int) <-chan int {
	out := make(chan int)
	var wg sync.WaitGroup
	for _, c := range chans {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for v := range c {
				out <- v
			}
		}()
	}
	go func() {
		wg.Wait()
		close(out)
	}()
	return out
}
```

```sh
go test -tags solution ./m06/pipeline/
```



## Key takeaways

- Channels move values and synchronize goroutines.
- Unbuffered channels hand off directly; buffered channels decouple sender and receiver up to the buffer size.
- `close` signals the end of a stream; `range` and comma-ok receives detect it; closing wakes all receivers.
- Use direction types in signatures.
- The sender closes, exactly once; sending on or closing a closed channel panics.

## Further reading

- [Effective Go: Channels](https://go.dev/doc/effective_go#channels)
- [Share Memory By Communicating](https://go.dev/blog/codelab-share) on the Go blog
- [Channel types](https://go.dev/ref/spec#Channel_types) and [Close](https://go.dev/ref/spec#Close) in the spec
