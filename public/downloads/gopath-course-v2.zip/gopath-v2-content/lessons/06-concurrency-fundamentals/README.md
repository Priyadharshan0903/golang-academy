# 6. Concurrency fundamentals

Concurrency is where Go stands out, and also where the hardest bugs live. This module builds the foundations carefully: what goroutines cost, how channels synchronize, when a mutex is the better tool, how to find data races, and what the memory model actually guarantees.

**Time:** about 4 hours, plus exercises. Run every example and exercise in this module with `-race`.

- [6.1 Goroutines and the cost model](01-goroutines.md)
- [6.2 Channels: unbuffered, buffered, direction](02-channels.md)
- [6.3 select, timeouts and time.After pitfalls](03-select-and-timeouts.md)
- [6.4 sync.WaitGroup, WaitGroup.Go, Mutex, RWMutex and Once](04-sync-package.md)
- [6.5 sync/atomic and atomic types](05-atomics.md)
- [6.6 The race detector](06-race-detector.md)
- [6.7 The Go memory model, in plain words](07-memory-model.md)
