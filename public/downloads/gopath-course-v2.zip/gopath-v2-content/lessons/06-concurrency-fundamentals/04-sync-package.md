# 6.4 sync.WaitGroup, WaitGroup.Go, Mutex, RWMutex and Once

Guard shared state with Mutex and RWMutex, wait for goroutines with WaitGroup and WaitGroup.Go, and initialize lazily with Once, OnceValue and OnceFunc.

## What you will learn

- How to protect shared state with `sync.Mutex`
- When `sync.RWMutex` helps, and when it does not
- `sync.WaitGroup`, and the shorter `WaitGroup.Go` (Go 1.25+)
- Lazy, thread-safe initialization with `sync.Once`, `OnceValue` and `OnceFunc`
- When to choose a mutex over a channel

## The idea

Channels are great for passing data between goroutines. But many programs simply have **shared state** (a cache, a counter, a connection pool) that several goroutines read and modify. For that, the `sync` package's mutual exclusion locks are simpler and faster.

The rule is short: **if more than one goroutine accesses a variable and at least one of them writes, every access must be synchronized.**

## `sync.Mutex`



Source: `examples/m06/syncprims/syncprims_test.go`

```go
// Inventory is safe for concurrent use. The mutex guards items;
// every method that touches items locks it first.
type Inventory struct {
	mu    sync.Mutex
	items map[string]int
}

func NewInventory() *Inventory { return &Inventory{items: map[string]int{}} }

func (inv *Inventory) Add(name string, n int) {
	inv.mu.Lock()
	defer inv.mu.Unlock()
	inv.items[name] += n
}

func (inv *Inventory) Count(name string) int {
	inv.mu.Lock()
	defer inv.mu.Unlock()
	return inv.items[name]
}

func Example_mutex() {
	inv := NewInventory()
	var wg sync.WaitGroup
	for range 100 {
		wg.Add(1)
		go func() {
			defer wg.Done()
			inv.Add("widget", 1)
		}()
	}
	wg.Wait()
	fmt.Println(inv.Count("widget"))

	// Output:
	// 100
}
```

Local command:

```sh
go test -race -run Example_mutex -v ./examples/m06/syncprims
```



- `Lock` blocks until the mutex is free; `Unlock` releases it.
- `defer mu.Unlock()` right after `Lock` guarantees the unlock even on early returns or panics.
- Put the mutex **next to the data it protects**, in the same struct, and make the fields unexported so the only way to reach them is through methods that lock.
- The zero value of a `Mutex` is an unlocked mutex. Never copy a mutex after first use; `go vet` reports copies (lesson 4.1).

Keep critical sections short: lock, touch the data, unlock. Do not hold a lock while doing I/O or calling unknown code, or every other goroutine waits behind you.

## `sync.RWMutex`



Source: `examples/m06/syncprims/syncprims_test.go`

```go
// Cache allows many concurrent readers, or one writer.
type Cache struct {
	mu   sync.RWMutex
	data map[string]string
}

func (c *Cache) Get(k string) (string, bool) {
	c.mu.RLock() // shared lock: readers do not block each other
	defer c.mu.RUnlock()
	v, ok := c.data[k]
	return v, ok
}

func (c *Cache) Set(k, v string) {
	c.mu.Lock() // exclusive lock: waits for all readers to finish
	defer c.mu.Unlock()
	if c.data == nil {
		c.data = map[string]string{}
	}
	c.data[k] = v
}

func Example_rwMutex() {
	var c Cache // zero value is usable: Set creates the map lazily
	c.Set("region", "ap-south-1")

	var wg sync.WaitGroup
	hits := make([]bool, 50)
	for i := range hits {
		wg.Add(1)
		go func() {
			defer wg.Done()
			_, hits[i] = c.Get("region")
		}()
	}
	wg.Wait()
	fmt.Println(hits[0], hits[49])

	// Output:
	// true true
}
```

Local command:

```sh
go test -race -run Example_rwMutex -v ./examples/m06/syncprims
```



An `RWMutex` allows **many readers at once** (`RLock`), or **one writer** (`Lock`). It helps when reads vastly outnumber writes **and** the read sections do noticeable work. For tiny critical sections it can be slower than a plain `Mutex`, because the bookkeeping costs more. Start with `Mutex`; switch to `RWMutex` when a benchmark (Module 10) shows lock contention on reads.

## `sync.WaitGroup`

You have used it since lesson 6.1. The full pattern for collecting results:



Source: `examples/m06/syncprims/syncprims_test.go`

```go
func Example_collectWithMutex() {
	var (
		mu      sync.Mutex
		wg      sync.WaitGroup
		squares []int
	)
	for i := 1; i <= 5; i++ {
		wg.Add(1) // Add BEFORE starting the goroutine, never inside it
		go func() {
			defer wg.Done()
			sq := i * i
			mu.Lock()
			squares = append(squares, sq)
			mu.Unlock()
		}()
	}
	wg.Wait()
	sort.Ints(squares) // goroutines finish in any order
	fmt.Println(squares)

	// Output:
	// [1 4 9 16 25]
}
```

Local command:

```sh
go test -race -run Example_collectWithMutex -v ./examples/m06/syncprims
```



`Add` must happen **before** the goroutine starts, so that `Wait` cannot return early.

### `WaitGroup.Go` (Go 1.25+)

Go 1.25 added a method that does the `Add`, `go` and `Done` for you:



Source: `examples/m06/syncprims/wggo_test.go`

```go
func Example_waitGroupGo() {
	var wg sync.WaitGroup
	results := make([]int, 4)
	for i := range results {
		// WaitGroup.Go (Go 1.25+) calls Add(1), starts the goroutine,
		// and calls Done when the function returns.
		wg.Go(func() {
			results[i] = i * 10
		})
	}
	wg.Wait()
	fmt.Println(results)

	// Output:
	// [0 10 20 30]
}
```

Local command:

```sh
go test -race -run Example_waitGroupGo -v ./examples/m06/syncprims
```



It removes the two most common `WaitGroup` mistakes (forgetting `Done`, calling `Add` inside the goroutine). Prefer it in modules targeting Go 1.25 or later.

## `sync.Once`, `OnceValue`, `OnceFunc`

`sync.Once` runs a function exactly once, even if many goroutines call it at the same time, and makes everyone wait until it has finished. Go 1.21 added helpers that are more convenient:



Source: `examples/m06/syncprims/syncprims_test.go`

```go
type Config struct{ Env string }

var (
	loadCount int
	getConfig = sync.OnceValue(func() *Config { // Go 1.21+
		loadCount++ // runs exactly once, even with concurrent callers
		return &Config{Env: "production"}
	})
)

func Example_onceValue() {
	var wg sync.WaitGroup
	envs := make([]string, 20)
	for i := range envs {
		wg.Add(1)
		go func() {
			defer wg.Done()
			envs[i] = getConfig().Env
		}()
	}
	wg.Wait()
	sort.Strings(envs)
	fmt.Println(envs[0], loadCount)

	// Output:
	// production 1
}
```

Local command:

```sh
go test -race -run Example_onceValue -v ./examples/m06/syncprims
```



- `sync.OnceFunc(f)` returns a function that calls `f` only the first time.
- `sync.OnceValue(f)` also caches `f`'s result.
- `sync.OnceValues(f)` caches a `(value, error)` pair.

Use them for lazy initialization of expensive, shared things: parsed templates, compiled regular expressions, a client created on first use.

## Mutex or channel?

| Situation | Prefer |
|---|---|
| Several goroutines read and update shared state (cache, counter, registry) | Mutex |
| Passing ownership of data from one goroutine to another | Channel |
| Distributing work to workers, collecting results | Channel |
| Signaling an event to many goroutines (shutdown) | Close a channel, or `context` |
| A simple counter or flag | `sync/atomic` (lesson 6.5) |

The Go wiki puts it well: use whichever is most expressive and simple for the problem. Mixing both in one design is common and fine.

## Other tools in `sync`

- `sync.Map`: a concurrent map optimized for two specific cases (keys written once and read many times, or goroutines working on disjoint keys). For everything else, a `map` plus a `Mutex` is simpler and often faster.
- `sync.Pool`: reuses temporary objects to reduce garbage collection pressure (lesson 10.6).
- `sync.Cond`: waits for a condition; rarely needed, as channels usually express the same thing more clearly.

## Common mistakes

### Forgetting to unlock on an early return

Without `defer`, any `return` or panic between `Lock` and `Unlock` leaves the mutex locked forever. Use `defer mu.Unlock()`.

### Copying a struct that contains a mutex

Passing it by value creates a second, independent lock, so the "protected" data is no longer protected. Use pointer receivers and `go vet`.

### Locking in the wrong order

Goroutine A locks `x` then `y`; goroutine B locks `y` then `x`. Each waits for the other forever. Always acquire multiple locks in the same order, or redesign to need only one.

### Returning internal maps or slices from locked methods

The caller then uses them **without** the lock. Return copies (as `Snapshot` does in the exercise).

## Exercise



## Exercise: 6.4 sync.WaitGroup, WaitGroup.Go, Mutex, RWMutex and Once

Implement `Sum`, which splits a slice across worker goroutines, and `Tally`, a concurrency-safe counter whose zero value works and whose `Snapshot` returns a copy. Run the tests with `go test -race`; the race detector must stay silent.

### Starter

```go
//go:build !solution

// Package parallel practices goroutines with sync.WaitGroup, sync.Mutex
// and sync/atomic. Run the tests with -race.
package parallel

// Sum adds up nums using the given number of goroutines. Each worker
// sums one contiguous part of the slice; the partial results are then
// combined. workers is at least 1 and may be larger than len(nums).
func Sum(nums []int, workers int) int {
	// TODO: implement me.
	return 0
}

// Tally is a concurrency-safe word counter.
// Its zero value must be ready to use.
type Tally struct {
	// TODO: add a mutex and a map.
}

// Add increments the count for word.
func (t *Tally) Add(word string) {
	// TODO: implement me.
}

// Count returns the count for word.
func (t *Tally) Count(word string) int {
	// TODO: implement me.
	return 0
}

// Snapshot returns a copy of all counts. Changing the returned map
// must not affect the Tally.
func (t *Tally) Snapshot() map[string]int {
	// TODO: implement me.
	return nil
}
```

```sh
cd exercises
go test ./m06/parallel/
```

### Reference solution — try the exercise first

```go
//go:build solution

// Package parallel practices goroutines with sync.WaitGroup, sync.Mutex
// and sync/atomic.
package parallel

import (
	"maps"
	"sync"
)

// Sum adds up nums using the given number of goroutines.
func Sum(nums []int, workers int) int {
	workers = max(1, min(workers, len(nums)))
	partial := make([]int, workers) // one slot per worker: no lock needed
	chunk := (len(nums) + workers - 1) / workers

	var wg sync.WaitGroup
	for w := range workers {
		start := w * chunk
		end := min(start+chunk, len(nums))
		if start >= end {
			continue
		}
		wg.Add(1)
		go func() {
			defer wg.Done()
			for _, n := range nums[start:end] {
				partial[w] += n
			}
		}()
	}
	wg.Wait()

	total := 0
	for _, p := range partial {
		total += p
	}
	return total
}

// Tally is a concurrency-safe word counter.
type Tally struct {
	mu     sync.Mutex
	counts map[string]int
}

// Add increments the count for word.
func (t *Tally) Add(word string) {
	t.mu.Lock()
	defer t.mu.Unlock()
	if t.counts == nil {
		t.counts = make(map[string]int)
	}
	t.counts[word]++
}

// Count returns the count for word.
func (t *Tally) Count(word string) int {
	t.mu.Lock()
	defer t.mu.Unlock()
	return t.counts[word]
}

// Snapshot returns a copy of all counts.
func (t *Tally) Snapshot() map[string]int {
	t.mu.Lock()
	defer t.mu.Unlock()
	out := maps.Clone(t.counts)
	if out == nil {
		out = map[string]int{}
	}
	return out
}
```

```sh
go test -tags solution ./m06/parallel/
```



## Key takeaways

- Synchronize every access to a variable that is shared and written.
- `Mutex` with `defer Unlock`, kept next to the data it guards, is the default tool for shared state.
- `RWMutex` pays off only when reads dominate and are not trivial.
- `WaitGroup` waits for goroutines; `WaitGroup.Go` (Go 1.25+) removes common mistakes.
- `OnceValue` and friends give thread-safe lazy initialization.

## Further reading

- [Package sync](https://pkg.go.dev/sync)
- [Go wiki: Use a sync.Mutex or a channel?](https://go.dev/wiki/MutexOrChannel)
- [Go 1.25 release notes: WaitGroup.Go](https://go.dev/doc/go1.25)
