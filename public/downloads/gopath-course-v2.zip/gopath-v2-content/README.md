# GoPath V2 learner pack

Start with [the curriculum index](INDEX.md). This pack includes 116 lessons, 27 exercises, 9 case studies, and 8 projects. Markdown is readable without React, Node.js, Vinext, or Hugo.

## Requirements and commands

The imported course targets Go 1.27; compatibility checks were originally scoped to Go 1.26.5. Read each lesson's Go-version notes and build tags. The root and nested modules preserve their original go.mod and go.sum files. Database, Redis, third-party, and Kubernetes examples require their documented services or dependencies.

Run an example using its displayed local command. Exercise tests deliberately fail for unfinished starters. From exercises/, run `go test -tags solution ./...` to check reference solutions. For the word-frequency checkpoint, exported lesson text lives under lessons/, not site/content/.

## Learning assets and answers

The deploy/server and deploy/k8s directories are teaching examples referenced in the Kubernetes lesson. Website publishing Dockerfiles, CI, Hugo templates, and internal plans are excluded. Reference solutions are included and labeled; attempt the exercise before opening them. Code embeds and course callouts have been converted into ordinary Markdown.

## Attribution

Adapted from GoPath Academy by Priyadharshan Senthil and contributors: https://github.com/Priyadharshan0903/golang-academy. Written content and adaptations retain CC BY-SA 4.0; code retains MIT. See LICENSE and LICENSE-CONTENT.md. Changes include Markdown export, resolved source embeds, local links, and export-specific commands.
