# GoPath V2 learning materials

- [1. Setup and tooling](lessons/01-setup-and-tooling/README.md)
- [2. Language basics](lessons/02-language-basics/README.md)
- [3. Composite types](lessons/03-composite-types/README.md)
- [4. Methods, interfaces and generics](lessons/04-methods-interfaces-generics/README.md)
- [5. Errors](lessons/05-errors/README.md)
- [6. Concurrency fundamentals](lessons/06-concurrency-fundamentals/README.md)
- [7. Concurrency patterns and context](lessons/07-concurrency-patterns/README.md)
- [8. Standard library deep dives](lessons/08-standard-library/README.md)
- [9. Testing in depth](lessons/09-testing/README.md)
- [10. Profiling and performance](lessons/10-performance/README.md)
- [11. Runtime internals](lessons/11-runtime-internals/README.md)
- [12. Building HTTP services](lessons/12-http-services/README.md)
- [13. Working with data](lessons/13-working-with-data/README.md)
- [14. CLIs and tooling](lessons/14-clis-and-tooling/README.md)
- [15. Go for cloud native](lessons/15-cloud-native/README.md)

## Case studies

- [Kubernetes and Docker: why cloud native was written in Go](case-studies/kubernetes-and-docker.md)
- [dl.google.com: replacing a C++ download server with Go](case-studies/dl-google-com.md)
- [Cloudflare: early production Go at the edge](case-studies/cloudflare.md)
- [Dropbox: moving performance-critical backends from Python to Go](case-studies/dropbox.md)
- [Uber: 170,000 queries per second with a geofence service](case-studies/uber-geofence.md)
- [Uber: what the race detector found in 46 million lines of Go](case-studies/uber-data-races.md)
- [Twitch: a 10 GiB memory ballast, and why GOMEMLIMIT replaced it](case-studies/twitch.md)
- [Discord: when Go's garbage collector was the wrong fit](case-studies/discord.md)
- [Monzo: a bank built as Go microservices on Kubernetes](case-studies/monzo.md)

## Projects

- [Concurrent web crawler](projects/crawler/README.md)
- [Greet CLI](projects/greet/README.md)
- [PostgreSQL job queue](projects/jobqueue/README.md)
- [Mini Redis server](projects/miniredis/README.md)
- [Token-bucket rate limiter](projects/ratelimit/README.md)
- [URL shortener](projects/shortener/README.md)
- [ShortLink Kubernetes operator](projects/shortlink-operator/README.md)
- [Word frequency counter](projects/wordfreq/README.md)
